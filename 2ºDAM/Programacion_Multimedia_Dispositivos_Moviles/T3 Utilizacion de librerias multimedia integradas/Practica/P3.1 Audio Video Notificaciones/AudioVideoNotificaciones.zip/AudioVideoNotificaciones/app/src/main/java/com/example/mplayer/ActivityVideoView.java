package com.example.mplayer;

import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityVideoView extends AppCompatActivity {
    private VideoView videoView;
    private MediaController mediaController;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.videoview_xml);

        //se instancia el objeto VideoView
        videoView=findViewById(R.id.videoView);
        //se fija la ruta donde está ubicado el vídeo a visualizar
        videoView.setVideoPath("android.resource://"+getPackageName()+"/"+R.raw.video);
        //se instancia el objeto MediaController
        mediaController=new MediaController(this);
        //se fija el ancho al mediaController
        mediaController.setAnchorView(videoView);
        //se fija el MediaController en el VideoView
        videoView.setMediaController(mediaController);
    }
}
