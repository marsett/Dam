package com.example.mplayer;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class ActivityNotificaciones extends AppCompatActivity {
    private Button notifyBtn;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notificaciones_xml);

        //condicional el cual dice que si la versión del SDK es mayor o igual a la de la primera versión de Android
        //se crea una instancia de NotificationChannel, llamándose a crear la notificación con un objeto de la clase
        //NotificationManager
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            NotificationChannel channel=new NotificationChannel("notification","Mi primera notificación", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager=getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
        notifyBtn=findViewById(R.id.notify_btn);
        //se establece el escuchador del botón que generará la notificación
        notifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //al clicar, se crea el builder con el channelId del condicional anterior
                NotificationCompat.Builder builder=new NotificationCompat.Builder(ActivityNotificaciones.this,"notification");
                //se fija el Título y Texto de la notificación, además del Icono
                builder.setContentTitle("Mi Primera Notificación");
                builder.setContentText("Esta es la descripción de la notificación");
                builder.setSmallIcon(R.drawable.message);
                builder.setAutoCancel(true);
                //se da permisos para mandar notificaciones
                NotificationManagerCompat managerCompat=NotificationManagerCompat.from(ActivityNotificaciones.this);
                managerCompat.notify(1,builder.build());
            }
        });
    }
}
