package com.example.mplayer;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityMediaPlayer extends AppCompatActivity {
    //crear objeto MediaPlayer
    MediaPlayer mediaPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mediaplayer_xml);
        //inicializar el objeto a null
        mediaPlayer = null;
    }
    public void audio(View view) {
        switch (view.getId()){
            //en el caso del primer botón 'Reproducir'
            case R.id.button:
                // Check if mediaPlayer is null. If true, we'll instantiate the MediaPlayer object
                //comprobar si el objeto MediaPlayer es null: si lo es, se instancia el objeto MediaPlayer
                if(mediaPlayer == null){
                    mediaPlayer = MediaPlayer.create(this, R.raw.audio);
                }
                // Then, register OnCompletionListener that calls a user supplied callback method onCompletion() when
                // looping mode was set to false to indicate playback is completed.
                //entonces, se llama al escuchador del MediaPlayer, en cuyo método se llamará al método pararAudio
                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        // Here, call a method to release the MediaPlayer object and to set it to null.
                        pararAudio();
                    }
                });
                //se llama al método start()
                mediaPlayer.start();
                break;
            //en el caso del segundo botón Pausar
            case R.id.button2:
                //si el objeto MediaPlayer no es null, se llama al método pause para pausar el audio
                if(mediaPlayer != null) {
                    mediaPlayer.pause();
                }
                break;
            //en el caso del tercer botón Parar
            case R.id.button3:
                //si el objeto MediaPlayer no es null, se llama al método stop para parar el audio, además de llamar al método creado
                if(mediaPlayer != null){
                    mediaPlayer.stop();
                    pararAudio();
                }
                break;
        }
    }
    private void pararAudio() {
        //se pone a null el objeto MediaPlayer
        mediaPlayer.release();
        mediaPlayer = null;
    }
    //llama al método pararAudio sobrescibiendo el método onStop
    @Override
    protected void onStop() {
        super.onStop();
        pararAudio();
    }
}