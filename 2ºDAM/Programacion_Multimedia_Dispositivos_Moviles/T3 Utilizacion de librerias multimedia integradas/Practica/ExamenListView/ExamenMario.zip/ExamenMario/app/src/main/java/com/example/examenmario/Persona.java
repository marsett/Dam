package com.example.examenmario;

public class Persona {
    //se crean las variables que aparecerán en el ListView
    private String nombre, email, telefono;
    //private boolean socio;
    private int imagen;
    //se crea un constructor vacío y otro con las variables parametrizadas
    public Persona(){}
    public Persona(String nombre, String email, String telefono, int imagen){
        this.nombre=nombre;
        this.email=email;
        this.telefono=telefono;
        this.imagen=imagen;
    }
    //se crean los getters y setters de todas las variables
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public int getImagen() {return imagen;}
    public void setImagen(int imagen) {this.imagen = imagen;}
}
