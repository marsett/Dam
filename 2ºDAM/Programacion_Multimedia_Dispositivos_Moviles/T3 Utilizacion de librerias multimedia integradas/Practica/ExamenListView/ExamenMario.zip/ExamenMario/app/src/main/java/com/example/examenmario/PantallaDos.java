package com.example.examenmario;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class PantallaDos extends AppCompatActivity {
    //se crean las variables a usar en el programa
    ListView listView;
    List<Persona> mLista=new ArrayList<>();
    ListAdapter mAdapter;
    private Bundle datos;
    private Button btAnterior;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.segunda_pantalla);
        //se asocia el componente al del xml
        btAnterior=(Button)findViewById(R.id.btAnterior);
        //al presionar el botón, se accede al Activity anterior
        btAnterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PantallaDos.super.onBackPressed();
            }
        });
        //se recoge la información del anterior activity con el Bundle
        datos=getIntent().getExtras();
        //se establece en variables la información recogida
        String nUno=datos.getString("datosnUno");
        String nDos=datos.getString("datosnDos");
        String nTres=datos.getString("datosnTres");
        String nCuatro=datos.getString("datosnCuatro");
        String nCinco=datos.getString("datosnCinco");
        String nSeis=datos.getString("datosnSeis");
        String eUno=datos.getString("datoseUno");
        String eDos=datos.getString("datoseDos");
        String eTres=datos.getString("datoseTres");
        String eCuatro=datos.getString("datoseCuatro");
        String eCinco=datos.getString("datoseCinco");
        String eSeis=datos.getString("datoseSeis");
        String tUno=datos.getString("datostUno");
        String tDos=datos.getString("datostDos");
        String tTres=datos.getString("datostTres");
        String tCuatro=datos.getString("datostCuatro");
        String tCinco=datos.getString("datostCinco");
        String tSeis=datos.getString("datostSeis");

        String sw1=datos.getString("sw1");
        String sw2=datos.getString("sw2");
        String sw3=datos.getString("sw3");
        String sw4=datos.getString("sw4");
        String sw5=datos.getString("sw5");
        String sw6=datos.getString("sw6");
        //se asocia el listView
        listView=findViewById(R.id.listView);
        //dependiendo de si está seleccionado o no los switchs, se añaden al List la información recogida en variables
        //además de la imagen del socio en verde (como que está seleccionado) o rojo (si no lo está)
        if(sw1.equals("si")) {
            mLista.add(new Persona(nUno, eUno, tUno, R.drawable.verde));
        }else if(sw1.equals("no")){
            mLista.add(new Persona(nUno, eUno, tUno, R.drawable.rojo));
        }
        if(sw2.equals("si")) {
            mLista.add(new Persona(nDos, eDos, tDos, R.drawable.verde));
        }else if(sw2.equals("no")){
            mLista.add(new Persona(nDos, eDos, tDos, R.drawable.rojo));
        }
        if(sw3.equals("si")) {
            mLista.add(new Persona(nTres, eTres, tTres, R.drawable.verde));
        }else if(sw3.equals("no")){
            mLista.add(new Persona(nTres, eTres, tTres, R.drawable.rojo));
        }
        if(sw4.equals("si")) {
            mLista.add(new Persona(nCuatro, eCuatro, tCuatro, R.drawable.verde));
        }else if(sw4.equals("no")){
            mLista.add(new Persona(nCuatro, eCuatro, tCuatro, R.drawable.rojo));
        }
        if(sw5.equals("si")) {
            mLista.add(new Persona(nCinco, eCinco, tCinco, R.drawable.verde));
        }else if(sw5.equals("no")){
            mLista.add(new Persona(nCinco, eCinco, tCinco, R.drawable.rojo));
        }
        if(sw1.equals("si")) {
            mLista.add(new Persona(nSeis, eSeis, tSeis, R.drawable.verde));
        }else if(sw1.equals("no")){
            mLista.add(new Persona(nSeis, eSeis, tSeis, R.drawable.rojo));
        }
        //se inicializa el ListAdapter, estableciendo el xml creado como la forma en que se va a ver el ListView predefinido en segunda_pantalla.xml
        mAdapter=new ListAdapter(PantallaDos.this,R.layout.item_row,mLista);
        //se fija el adaptador en el listView
        listView.setAdapter(mAdapter);
    }
}
