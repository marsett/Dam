package com.example.examenmario;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ListAdapter extends ArrayAdapter<Persona> {
    //se crean las variables a usar en la clase
    private List<Persona> mList;
    private Context mContext;
    private int resourceLayout;
    //se parametrizan las variables en el constructor
    public ListAdapter(@NonNull Context context, int resource, List<Persona> objects) {
        super(context, resource, objects);
        this.mList=objects;
        this.mContext=context;
        this.resourceLayout=resource;
    }
    //se sobrescribe el método getView
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        View view=convertView;
        if(view==null){
            view= LayoutInflater.from(mContext).inflate(resourceLayout,null);
        }
        //se crea un objeto persona, el cual cogerá cada posición del List creado
        Persona persona=mList.get(position);
        //se fija la información de cada TextView cogiendo la información de cada getter
        TextView textoNombre=view.findViewById(R.id.txtNombre);
        textoNombre.setText(persona.getNombre());
        TextView textoEmail=view.findViewById(R.id.txtEmail);
        textoEmail.setText(persona.getEmail());
        TextView textoTelefono=view.findViewById(R.id.txtTelefono);
        textoTelefono.setText(persona.getTelefono());
        ImageView imagenSocio=view.findViewById(R.id.ImageView);
        imagenSocio.setImageResource(persona.getImagen());
        //devuelve el método el objeto View creado
        return view;
    }
}
