package com.example.examenmario;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //se crean las variables a utilizar en el programa
    private Button btValidar, btFin;
    private EditText nombreUno, nombreDos, nombreTres, nombreCuatro, nombreCinco, nombreSeis,
            emailUno, emailDos, emailTres, emailCuatro, emailCinco, emailSeis,
            telefonoUno, telefonoDos, telefonoTres, telefonoCuatro, telefonoCinco, telefonoSeis;
    private Switch switchUno, switchDos, switchTres, switchCuatro, switchCinco, switchSeis;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //a las variables creadas se les asocia el elemento del xml concreto
        nombreUno=(EditText)findViewById(R.id.etNombreUno);
        nombreDos=(EditText)findViewById(R.id.etNombreDos);
        nombreTres=(EditText)findViewById(R.id.etNombreTres);
        nombreCuatro=(EditText)findViewById(R.id.etNombreCuatro);
        nombreCinco=(EditText)findViewById(R.id.etNombreCinco);
        nombreSeis=(EditText)findViewById(R.id.etNombreSeis);

        emailUno=(EditText)findViewById(R.id.etEmailUno);
        emailDos=(EditText)findViewById(R.id.etEmailDos);
        emailTres=(EditText)findViewById(R.id.etEmailTres);
        emailCuatro=(EditText)findViewById(R.id.etEmailCuatro);
        emailCinco=(EditText)findViewById(R.id.etEmailCinco);
        emailSeis=(EditText)findViewById(R.id.etEmailSeis);

        telefonoUno=(EditText)findViewById(R.id.etTelefonoUno);
        telefonoDos=(EditText)findViewById(R.id.etTelefonoDos);
        telefonoTres=(EditText)findViewById(R.id.etTelefonoTres);
        telefonoCuatro=(EditText)findViewById(R.id.etTelefonoCuatro);
        telefonoCinco=(EditText)findViewById(R.id.etTelefonoCinco);
        telefonoSeis=(EditText)findViewById(R.id.etTelefonoSeis);

        switchUno=(Switch)findViewById(R.id.switchUno);
        switchDos=(Switch)findViewById(R.id.switchDos);
        switchTres=(Switch)findViewById(R.id.switchTres);
        switchCuatro=(Switch)findViewById(R.id.switchCuatro);
        switchCinco=(Switch)findViewById(R.id.switchCinco);
        switchSeis=(Switch)findViewById(R.id.switchSeis);

        btValidar=(Button)findViewById(R.id.btValidar);
        btFin=(Button)findViewById(R.id.btFin);

        //al clicar en el botón Validar, ocurrirá lo siguiente
        btValidar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    //se crea el constructor del Diálogo con el contexto de la clase
                    AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                    //se fija el título del diálogo, además del mensaje y los botones a clicar
                    builder.setTitle("VALIDACIÓN");
                    builder.setMessage("¿Desea validar la información?");
                    builder.setCancelable(false);
                    //al clicar en el botón positivo
                    builder.setPositiveButton("SÍ", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            //se recoge la información puesta hasta el momento de clicar en el botón para abrir el diálogo
                            String nUno=nombreUno.getText().toString();
                            String nDos=nombreDos.getText().toString();
                            String nTres=nombreTres.getText().toString();
                            String nCuatro=nombreCuatro.getText().toString();
                            String nCinco=nombreCinco.getText().toString();
                            String nSeis=nombreSeis.getText().toString();
                            String eUno=emailUno.getText().toString();
                            String eDos=emailDos.getText().toString();
                            String eTres=emailTres.getText().toString();
                            String eCuatro=emailCuatro.getText().toString();
                            String eCinco=emailCinco.getText().toString();
                            String eSeis=emailSeis.getText().toString();
                            String tUno=telefonoUno.getText().toString();
                            String tDos=telefonoDos.getText().toString();
                            String tTres=telefonoTres.getText().toString();
                            String tCuatro=telefonoCuatro.getText().toString();
                            String tCinco=telefonoCinco.getText().toString();
                            String tSeis=telefonoSeis.getText().toString();
                            //se crea el Intent, con el cual se mandará la información a la pantalla del ListView
                            Intent abrirActivityDos=new Intent(MainActivity.this,PantallaDos.class);
                            //si está clicado el switch o no, se guarda en una variable si es así
                            //con putExtra, se manda la información al otro activity, estableciendo un nombre
                            String clicado;
                            if(switchUno.isChecked()){
                                clicado="si";
                            }else{
                                clicado="no";
                            }
                            abrirActivityDos.putExtra("sw1", clicado);
                            if(switchDos.isChecked()){
                                clicado="si";
                            }else{
                                clicado="no";
                            }
                            abrirActivityDos.putExtra("sw2", clicado);
                            if(switchTres.isChecked()){
                                clicado="si";
                            }else{
                                clicado="no";
                            }
                            abrirActivityDos.putExtra("sw3", clicado);
                            if(switchCuatro.isChecked()){
                                clicado="si";
                            }else{
                                clicado="no";
                            }
                            abrirActivityDos.putExtra("sw4", clicado);
                            if(switchCinco.isChecked()){
                                clicado="si";
                            }else{
                                clicado="no";
                            }
                            abrirActivityDos.putExtra("sw5", clicado);
                            if(switchSeis.isChecked()){
                                clicado="si";
                            }else{
                                clicado="no";
                            }
                            abrirActivityDos.putExtra("sw6", clicado);

                            abrirActivityDos.putExtra("datosnUno",nUno);
                            abrirActivityDos.putExtra("datosnDos",nDos);
                            abrirActivityDos.putExtra("datosnTres",nTres);
                            abrirActivityDos.putExtra("datosnCuatro",nCuatro);
                            abrirActivityDos.putExtra("datosnCinco",nCinco);
                            abrirActivityDos.putExtra("datosnSeis",nSeis);
                            abrirActivityDos.putExtra("datoseUno",eUno);
                            abrirActivityDos.putExtra("datoseDos",eDos);
                            abrirActivityDos.putExtra("datoseTres",eTres);
                            abrirActivityDos.putExtra("datoseCuatro",eCuatro);
                            abrirActivityDos.putExtra("datoseCinco",eCinco);
                            abrirActivityDos.putExtra("datoseSeis",eSeis);
                            abrirActivityDos.putExtra("datostUno",tUno);
                            abrirActivityDos.putExtra("datostDos",tDos);
                            abrirActivityDos.putExtra("datostTres",tTres);
                            abrirActivityDos.putExtra("datostCuatro",tCuatro);
                            abrirActivityDos.putExtra("datostCinco",tCinco);
                            abrirActivityDos.putExtra("datostSeis",tSeis);
                            //se abre el activity siguiente
                            startActivity(abrirActivityDos);
                        }
                    });
                    //al pulsar CANCELAR, simplemente se cierra el diálogo y se puede seguir manipulando los EditText y Switch
                    builder.setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(getApplicationContext(),"Has pulsado CANCELAR",Toast.LENGTH_SHORT).show();
                        }
                    });
                    //se muestra el diálogo
                    builder.show();
            }
        });
        //si se clica en el botón FIN, muestra el Toast de despedida y cierra la aplicación fulminantemente
        btFin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Cerrando aplicación...",Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }


















}