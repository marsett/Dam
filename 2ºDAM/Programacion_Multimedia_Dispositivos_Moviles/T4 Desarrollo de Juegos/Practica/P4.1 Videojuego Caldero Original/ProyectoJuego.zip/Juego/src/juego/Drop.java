package juego;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Drop extends Game {
	//se crean las variables necesarias a utilizar en la clase
	OrthographicCamera camara;
	SpriteBatch spriteBatch;
	BitmapFont fuente;
	int gotasRecogidas;
	//se crea un método el cual se invoca al momento de ejecutar la aplicación
	@Override
	public void create() {
		//se inicializan las variables, fijando la pantalla, la fuente de las letras y el spriteBatch
		spriteBatch = new SpriteBatch();
		fuente = new BitmapFont();
		setScreen(new MainMenuScreen(this));
	}
	//método sobrescrito que se invoca cuada vez que toca renderizar, actualizándose la lógica del juego
	@Override
	public void render() {
		super.render();
	}
	//método sobrescrito que coloca el spriteBatch y la fuente de las letras
	@Override
	public void dispose() {
		spriteBatch.dispose();
		fuente.dispose();
	}
}