package juego;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.OrthographicCamera;

//pantalla de incio que muestra el menú del juego
public class MainMenuScreen implements Screen {
	//se crean las variables a utilizar en la clase
	//se crea un objeto de la clase Drop
	final Drop juego;
	OrthographicCamera camara;
	//se parametriza el objeto
	public MainMenuScreen(Drop juego) {
		this.juego = juego;
		camara = new OrthographicCamera();
		camara.setToOrtho(false, 1024, 768);
	}
	//método que tiene el objetivo de renderizar
	@Override
	public void render(float delta) {
		//se establecen los colores exactos del menú
		Gdx.gl.glClearColor(0, 0, 0.2f, 1);
		Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT);
		//se actualiza la cámara
		camara.update();
		juego.spriteBatch.setProjectionMatrix(camara.combined);
		//se muestra el menú de inicio
		juego.spriteBatch.begin();
		juego.fuente.draw(juego.spriteBatch, "Bienvenido a Drop!!!!", 100, 150);
		juego.fuente.draw(juego.spriteBatch, "Pulsa para empezar", 100, 130);
		juego.fuente.draw(juego.spriteBatch, "Pulsa 'ESCAPE' para SALIR", 100, 110);
		juego.spriteBatch.end();
		//si el usuario toca la pantalla, se inicia la partida
		if (Gdx.input.isTouched()) {
			juego.setScreen(new GameScreen(juego));
			dispose();
		}
		if (Gdx.input.isKeyPressed(Keys.ESCAPE)) {
			dispose();
			System.exit(0);
		}
	}
	//métodos implementados por la interfaz Screen
	@Override
	public void resize(int width, int height) {
	}
	@Override
	public void show() {
	}
	@Override
	public void hide() {
	}
	@Override
	public void pause() {
	}
	@Override
	public void resume() {
	}
	@Override
	public void dispose() {
	}
}