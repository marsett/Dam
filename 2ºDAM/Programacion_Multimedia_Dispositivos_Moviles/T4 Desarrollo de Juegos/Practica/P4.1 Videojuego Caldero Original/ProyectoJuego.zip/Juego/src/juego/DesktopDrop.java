package juego;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;

//clase principal que, al ser ejecutada, muestra el juego disponible para ser utilizado
public class DesktopDrop {
	public static void main(String[] args) {
		//se crea un objeto el cual configura el juego
		LwjglApplicationConfiguration configuracion = new LwjglApplicationConfiguration();
		//se llama a la clase System para fijar la propiedad que permite utilizar el software OpenGL (líos de licencias)
		System.setProperty("org.lwjgl.opengl.Display.allowSoftwareOpenGL", "true");
		//se configura el título y las dimensiones de la pantalla
		configuracion.title = "Drop";
		configuracion.width = 1024;
		configuracion.height = 768;
		//se instancia una nueva configuración, llamando a otra clase
		new LwjglApplication(new Drop(), configuracion);
	}
}