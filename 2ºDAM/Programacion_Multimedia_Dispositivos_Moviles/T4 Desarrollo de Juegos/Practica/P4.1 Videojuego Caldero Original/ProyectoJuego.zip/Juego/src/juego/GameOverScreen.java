package juego;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.Stage;

//esta clase presenta cómo se ve la pantalla al finalizar el usuario la partida
public class GameOverScreen implements Screen {
	//se crean las variables a utilizar en la clase
	//se crea un objeto d ela clase Drop
	final Drop juego;
	Stage menu;
	OrthographicCamera camara;
	//en el constructor se parametriza el objeto Drop, además de inicializar la cámara
	public GameOverScreen(Drop juego) {
		this.juego = juego;
		camara = new OrthographicCamera();
		camara.setToOrtho(false, 1024, 768);
	}
	//se sobrescribe el método de renderizado
	@Override
	public void render(float delta) {
		//se establecen los colores exactos del juego
		Gdx.gl.glClearColor(0, 0.3f, 0.6f, 1);
		Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT);
		//se actualiza la cámara, además de fijar cuál será su proyección
		camara.update();
		juego.spriteBatch.setProjectionMatrix(camara.combined);
		//se muestra el menú de inicio
		juego.spriteBatch.begin();
		//se establecen los mensajes al terminar el juego y, si se quiere salir o volver a jugar, la tecla la cual clicar
		juego.fuente.draw(juego.spriteBatch, "Fin del juego!!!!", 100, 150);
		juego.fuente.draw(juego.spriteBatch, "Tu puntuación: " + juego.gotasRecogidas, 100, 130);
		juego.fuente.draw(juego.spriteBatch, "Si quieres jugar otra partida pulsa la tecla 'N'", 100, 110);
		juego.fuente.draw(juego.spriteBatch, "Pulsa 'ESCAPE' para SALIR", 100, 90);
		juego.spriteBatch.end();
		//si el usuario toca la pantalla, se inicia la partida
		if (Gdx.input.isKeyPressed(Keys.N)) {
			//al empezar una nueva partida, no debe de haber gotas recogidas
			juego.gotasRecogidas = 0;
			//se fija la pantalla llamando a otra clase
			juego.setScreen(new GameScreen(juego));
		}
		//al pulsar la tecla ESCAPE, se permite salir del juego
		else if (Gdx.input.isKeyPressed(Keys.ESCAPE)) {
			dispose();
			System.exit(0);
		}
	}
	//diferentes métodos auto-implementados debido a la interfaz Screen
	@Override
	public void resize(int width, int height) {
	}
	@Override
	public void show() {
	}
	@Override
	public void hide() {
	}
	@Override
	public void pause() {
	}
	@Override
	public void resume() {
	}
	@Override
	public void dispose() {
		juego.dispose();
	}
}