package juego;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;

public class DesktopDrop {
	public static void main(String[] args) {
		LwjglApplicationConfiguration configuracion = new LwjglApplicationConfiguration();
		//se ha modificado el título de la ventana
		configuracion.title = "Caldero Modificado";
		configuracion.width = 1024;
		configuracion.height = 768;
		new LwjglApplication(new Drop(), configuracion);
	}
}
