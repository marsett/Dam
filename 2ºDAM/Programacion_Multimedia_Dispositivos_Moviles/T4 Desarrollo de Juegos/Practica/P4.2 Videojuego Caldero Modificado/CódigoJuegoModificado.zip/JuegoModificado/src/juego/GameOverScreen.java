package juego;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.Stage;

public class GameOverScreen implements Screen {
	final Drop juego;
	Stage menu;
	OrthographicCamera camara;
	public GameOverScreen(Drop juego) {
		this.juego = juego;
		camara = new OrthographicCamera();
		camara.setToOrtho(false, 1024, 768);
	}
	@Override
	public void render(float delta) {
		//MODIFICACIÓN 1 --> cambiar el color de fondo de la pantalla final del juego 
		Gdx.gl.glClearColor(0,255,0,0.8f);
		Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT);
		camara.update();
		juego.spriteBatch.setProjectionMatrix(camara.combined);
		juego.spriteBatch.begin();
		juego.fuente.draw(juego.spriteBatch, "Fin del juego!!!!", 100, 150);
		juego.fuente.draw(juego.spriteBatch, "Tu puntuación: " + juego.gotasRecogidas, 100, 130);
		juego.fuente.draw(juego.spriteBatch, "Si quieres jugar otra partida pulsa la tecla 'C'", 100, 110);
		juego.fuente.draw(juego.spriteBatch, "Pulsa 'ESCAPE' para SALIR", 100, 90);
		juego.spriteBatch.end();
		//MODIFICACIÓN 2 --> se ha cambiado la tecla con la que empezar una nueva partida
		if (Gdx.input.isKeyPressed(Keys.C)) {
			juego.gotasRecogidas = 0;
			juego.setScreen(new GameScreen(juego));
		}
		else if (Gdx.input.isKeyPressed(Keys.ESCAPE)) {
			dispose();
			System.exit(0);
		}
	}
	@Override
	public void resize(int width, int height) {
	}
	@Override
	public void show() {
	}

	@Override
	public void hide() {
	}
	@Override
	public void pause() {
	}
	@Override
	public void resume() {
	}
	@Override
	public void dispose() {
		juego.dispose();
	}
}