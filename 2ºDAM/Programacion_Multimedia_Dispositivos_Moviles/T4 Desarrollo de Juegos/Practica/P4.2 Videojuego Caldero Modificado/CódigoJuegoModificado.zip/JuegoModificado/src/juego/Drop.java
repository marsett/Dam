package juego;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Drop extends Game {
	OrthographicCamera camara;
	SpriteBatch spriteBatch;
	BitmapFont fuente;
	int gotasRecogidas;
	@Override
	public void create() {
		spriteBatch = new SpriteBatch();
		fuente = new BitmapFont();
		setScreen(new MainMenuScreen(this));
	}
	@Override
	public void render() {
		super.render();
	}
	@Override
	public void dispose() {
		spriteBatch.dispose();
		fuente.dispose();
	}
}