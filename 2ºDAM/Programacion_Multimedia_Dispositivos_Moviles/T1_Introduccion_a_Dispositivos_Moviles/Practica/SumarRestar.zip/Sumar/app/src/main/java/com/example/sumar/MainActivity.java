package com.example.sumar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    EditText etResultado, etResultado2;
    TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etResultado = findViewById(R.id.PonerNum1);
        etResultado2 = findViewById(R.id.PonerNum2);
        tvResultado = findViewById(R.id.PonerResultado);
    }

    public void sumar(View view){
        float num1, num2, suma;
        num1=Float.parseFloat(etResultado.getText().toString());
        num2=Float.parseFloat(etResultado2.getText().toString());

        suma=num1+num2;
        tvResultado.setText(suma+"");
    }

    public void restar(View view){
        float num1, num2, resta;
        num1=Float.parseFloat(etResultado.getText().toString());
        num2=Float.parseFloat(etResultado2.getText().toString());

        resta=num1-num2;
        tvResultado.setText(resta+"");
    }

}