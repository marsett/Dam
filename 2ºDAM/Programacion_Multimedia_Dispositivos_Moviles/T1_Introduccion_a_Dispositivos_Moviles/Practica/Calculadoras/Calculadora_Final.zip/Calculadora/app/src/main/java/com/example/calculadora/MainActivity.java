package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.*;
public class MainActivity extends AppCompatActivity {

    TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResultado = findViewById(R.id.tvResultado);
        tvResultado.setText("0");
    }

    public void LimpiarResultado(View view) {
        tvResultado.setText("0");
    }

    public void pulsaNumero(View v) {
        if (tvResultado.getText() == "0")
            tvResultado.setText("");
        Button bt = (Button) v;
        String boton = (String) bt.getText();
        tvResultado.setText(tvResultado.getText() + boton);
    }

    public void Resultado(View view) {
        String valores = (String) tvResultado.getText();
        List<String> numeros = new ArrayList<String>();
        String numero = "";
        int indice = valores.length();
        for (int i = 0; i < indice; i++) {
            char c = valores.charAt(i);
            if (c == '.') {
                numero += String.valueOf(c);
            }
            else {
                numero += Character.getNumericValue(c);
                int n = Character.getNumericValue(c); //Si no es numerico retorna -1
                if ((n == -1) || (i == (indice - 1))) {
                    if ((n == -1)) {
                        numero = numero.substring(0, numero.length() - 2);
                    }
                    numeros.add(numero);
                    numeros.add(String.valueOf(c));
                    numero = "";
                }
            }
        }
        numeros.remove(numeros.size() - 1);
        Log.d("", numeros.toString());

        resultado((ArrayList) numeros);
    }

    private void resultado(ArrayList numeros) {
        Float acumulador = 0f;
        Float num1 = 0f;
        Float num2 = 0f;
        String signo = "";
        for (int i = 1; i < numeros.size(); i += 2) {
            if (i == 1) {
                num1 = Float.parseFloat((String) numeros.get(i - 1));
            }
            else {
                num1 = Float.parseFloat((String) numeros.get(i + 1));
            }
            num2 = Float.parseFloat((String) numeros.get(i + 1));
            signo = (String) numeros.get(i);
            switch (signo) {
                case "+":
                    if (i == 1) {
                        acumulador += (num1 + num2);
                    } else {
                        acumulador += num1;
                    }
                    break;
                case "-":
                    if (i == 1) {
                        acumulador += (num1 - num2);
                    } else {
                        acumulador += num1;
                    }
                    break;
                case "*":
                    if (i == 1) {
                        acumulador += (num1 * num2);
                    } else {
                        acumulador += num1;
                    }
                    break;
                case "/":
                    if (i == 1) {
                        acumulador += (num1 / num2);
                    } else {
                        acumulador += num1;
                    }
                    break;
                case "%":
                    if (i == 1) {
                        acumulador += ((num1 * num2)/100);
                    } else {
                        acumulador += num1;
                    }
                    break;
            }

            num2 = acumulador;

            Log.d("VALORES: ", String.valueOf(i));
            Log.d("ACUMULADOR: ", String.valueOf(acumulador));
        }
        tvResultado.setText(acumulador + "");
    }

}