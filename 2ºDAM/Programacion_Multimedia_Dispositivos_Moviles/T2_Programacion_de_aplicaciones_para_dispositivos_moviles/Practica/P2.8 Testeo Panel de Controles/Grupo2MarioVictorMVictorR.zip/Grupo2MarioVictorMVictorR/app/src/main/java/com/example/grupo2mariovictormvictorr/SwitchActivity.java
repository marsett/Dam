package com.example.grupo2mariovictormvictorr;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class SwitchActivity extends AppCompatActivity {
    //definimos las variables
    private Switch switchView;
    private TextView statusTV;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.switch_xml);

        // inicializamos las variables
        switchView = findViewById(R.id.idSwitch);
        statusTV = findViewById(R.id.textView2);

        //si el switch esta marcado ponla un texto y si no lo esta pone el otro texto
        if (switchView.isChecked()) {
            statusTV.setText("El Switch esta activado");
        } else {
            statusTV.setText("El Switch no esta activado");
        }

        //aqui indicamos el escuchador del detector de cambios de verificacion para el switch
        switchView.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //si el switch esta marcado ponla un texto y si no lo esta pone el otro texto y cambia el color
                if (isChecked) {
                    statusTV.setText("El Switch esta activado");
                    statusTV.setTextColor(Color.parseColor("#28B463"));
                } else {
                    statusTV.setText("El Switch no esta activado");
                    statusTV.setTextColor(Color.parseColor("#CB4335"));
                }
            }
        });
    }
}
