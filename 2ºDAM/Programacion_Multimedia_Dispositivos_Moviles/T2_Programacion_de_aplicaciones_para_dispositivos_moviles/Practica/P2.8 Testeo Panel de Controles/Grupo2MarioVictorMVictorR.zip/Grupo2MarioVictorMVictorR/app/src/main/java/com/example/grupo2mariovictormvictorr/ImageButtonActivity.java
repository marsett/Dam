package com.example.grupo2mariovictormvictorr;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ImageButtonActivity extends AppCompatActivity {
    //se crea una variable de tipo ImageButton
    private ImageButton ibOracle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.imagebutton);

        //se enlaza este componente con el id del xml enlazado
        ibOracle=(ImageButton) findViewById(R.id.ibOracle);
        //al clicar en este componente, aparece un Toast que afirma la acción que se está realizando
        //se crea un Intent, el cual hace que se pueda salir de la aplicación y abrir la página web
        //en el navegador predeterminado
        ibOracle.setOnClickListener(view ->{
            Toast.makeText(ImageButtonActivity.this,"Entrando en la página de Oracle...",Toast.LENGTH_SHORT).show();
            String url="https://docs.oracle.com/en/java/javase/18/docs/api/index.html";
            Intent intent=new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        });


    }
}
