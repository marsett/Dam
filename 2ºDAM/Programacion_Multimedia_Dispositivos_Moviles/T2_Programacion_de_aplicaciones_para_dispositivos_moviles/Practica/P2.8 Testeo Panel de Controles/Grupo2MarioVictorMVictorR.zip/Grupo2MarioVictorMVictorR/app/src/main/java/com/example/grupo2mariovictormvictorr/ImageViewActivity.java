package com.example.grupo2mariovictormvictorr;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ImageViewActivity extends AppCompatActivity {
    private ImageView descarga;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.imageview);

        descarga=(ImageView)findViewById(R.id.imageView);
        descarga.setImageResource(R.drawable.descarga);
    }
}
