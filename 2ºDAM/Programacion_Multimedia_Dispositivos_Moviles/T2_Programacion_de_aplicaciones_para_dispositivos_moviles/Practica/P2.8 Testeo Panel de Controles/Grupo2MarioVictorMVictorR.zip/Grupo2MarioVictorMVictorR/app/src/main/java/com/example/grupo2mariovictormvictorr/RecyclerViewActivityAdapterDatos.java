package com.example.grupo2mariovictormvictorr;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerViewActivityAdapterDatos extends RecyclerView.Adapter<RecyclerViewActivityAdapterDatos.ViewHolderDatos> {

    ArrayList<String> listaDatos;

    public RecyclerViewActivityAdapterDatos(ArrayList<String> listaDatos) {
        this.listaDatos = listaDatos;
    }

    //Enlaza al adaptador con el archivo item_list
    public ViewHolderDatos onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_adapter_datos, null, false);
        return new ViewHolderDatos(view);
    }

    //Establece la comunicación entre el adaptador y la clase viewHolderDatos, para poder agregar los datos a la lista
    public void onBindViewHolder(ViewHolderDatos holder, int position) {
        holder.asignarDatos(listaDatos.get(position));
    }

    //Devuelve el tamaño de la lista de datos
    public int getItemCount() {
        return listaDatos.size();
    }

    public class ViewHolderDatos extends RecyclerView.ViewHolder {

        TextView dato;

        public ViewHolderDatos(View itemView) {
            super(itemView);
            dato = itemView.findViewById(R.id.idDato);
        }

        public void asignarDatos(String datos) {
            dato.setText(datos);
        }
    }
}
