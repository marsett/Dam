package com.example.grupo2mariovictormvictorr;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerViewActivity extends AppCompatActivity {
    ArrayList<String> listaDatos;
    RecyclerView recyclerView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recyclerview_activity);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        //ArrayList para añadir los datos al adaptador y establecer la cantidad de ellos
        listaDatos = new ArrayList<>();
        for(int i = 1; i<=50;i++) {
            listaDatos.add("Dato " + i);
        }

        RecyclerViewActivityAdapterDatos adapter = new RecyclerViewActivityAdapterDatos(listaDatos);
        recyclerView.setAdapter(adapter);

    }
}
