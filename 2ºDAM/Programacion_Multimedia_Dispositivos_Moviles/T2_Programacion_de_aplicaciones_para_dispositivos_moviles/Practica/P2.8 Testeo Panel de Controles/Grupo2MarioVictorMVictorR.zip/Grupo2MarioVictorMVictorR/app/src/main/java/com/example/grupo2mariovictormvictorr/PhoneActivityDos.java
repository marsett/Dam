package com.example.grupo2mariovictormvictorr;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PhoneActivityDos extends AppCompatActivity {
    //se crean las variables a utilizar en el programa
    private TextView muestraTelefono;
    private Bundle datos;
    private Button btAnterior;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.phone_dos);

        //se recogen los datos del anterior activity a través del bundle
        datos=getIntent().getExtras();

        //se enlaza el componente con el id del componente del xml
        muestraTelefono=(TextView) findViewById(R.id.tvMuestraTelefono);

        //se recoge la información del EditText de tipo Phone del anterior activity
        String telefono=datos.getString("numero");
        //se fija esta información en el TextView
        muestraTelefono.setText(telefono);

        btAnterior=(Button)findViewById(R.id.btAnterior);
        //este botón permite volver al primer activity, con el objetivo de posibilitar la actualización del dato
        btAnterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PhoneActivityDos.super.onBackPressed();
            }
        });
    }
}
