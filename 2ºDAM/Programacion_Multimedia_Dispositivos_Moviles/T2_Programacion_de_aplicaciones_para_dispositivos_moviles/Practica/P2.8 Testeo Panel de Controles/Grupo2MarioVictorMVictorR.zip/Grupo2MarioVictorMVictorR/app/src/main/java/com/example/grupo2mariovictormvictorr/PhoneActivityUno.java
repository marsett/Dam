package com.example.grupo2mariovictormvictorr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class PhoneActivityUno extends AppCompatActivity {
    //se crean las variables a utilizar en el programa
    private EditText etPhone;
    private Button btMostrar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.phone_uno);

        //se enlazan los componentes con el id del componente concreto del xml
        etPhone=(EditText) findViewById(R.id.etPhone);
        btMostrar=(Button) findViewById(R.id.btMostrar);

        //al insertar texto en el EditText de tipo Phone, cada vez que se inserte 1 carácter, aparecerá un Toast
        //cada vez que se termine de escribir un carácter, un contador marcará el número de caracteres totales
        etPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                Toast.makeText(PhoneActivityUno.this, "Has añadido 1 caracter", Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }
            @Override
            public void afterTextChanged(Editable s) {
                TextView contador = (TextView) findViewById(R.id.texto_contador);
                String tamanoString = String.valueOf(s.length());
                contador.setText(tamanoString);
            }
        });
        //al clicar el botón, se llama a otro Activity
        btMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String numero=etPhone.getText().toString();
                Intent abrirActivityDos=new Intent(PhoneActivityUno.this, PhoneActivityDos.class);
                abrirActivityDos.putExtra("numero",numero);
                startActivity(abrirActivityDos);
            }
        });
    }
}