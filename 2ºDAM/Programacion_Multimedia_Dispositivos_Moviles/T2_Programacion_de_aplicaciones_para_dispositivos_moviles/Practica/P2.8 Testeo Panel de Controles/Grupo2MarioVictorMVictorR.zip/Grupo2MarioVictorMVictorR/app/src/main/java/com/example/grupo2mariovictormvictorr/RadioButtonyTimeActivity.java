package com.example.grupo2mariovictormvictorr;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class RadioButtonyTimeActivity extends AppCompatActivity {
    private RadioButton radioButton1, radioButton2;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.radiobutton_time);

        radioButton1 = findViewById(R.id.rb1);
        radioButton1 = findViewById(R.id.rb2);
    }
    //Al pulsar alguno de los RadioButton saltara un mensaje informado de cual es el que está seleccionado
    public void validar(View view) {

        String seleccionado = "";

        if(radioButton1.isChecked()) {
            seleccionado = "Has seleccionado la opcion 1";
        } else if(radioButton2.isChecked()) {
            seleccionado = "Has seleccionado la opcion 2";
        }
        Toast.makeText(RadioButtonyTimeActivity.this, seleccionado, Toast.LENGTH_SHORT).show();
    }

    //Al pulsar el botón, si la opción 1 no está selecciona, se seleccionara
    public void toggle(View view) {
        radioButton1.toggle();
    }
}
