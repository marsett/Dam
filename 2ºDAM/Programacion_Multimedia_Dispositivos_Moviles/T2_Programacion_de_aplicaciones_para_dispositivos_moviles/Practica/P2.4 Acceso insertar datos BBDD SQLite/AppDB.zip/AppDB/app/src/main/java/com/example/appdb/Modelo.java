package com.example.appdb;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class Modelo {
    //dentro del siguiente metodo del tipo SQLiteDatabase, se crea la conexion y un objeto de la clase SQLiteDatabase, el cual
    //es igual a la conexion, que llama a un metodo que hace que la database solo escriba
    public SQLiteDatabase getConn(Context context){
        ConexionSQLite conn=new ConexionSQLite(context, "dbusuarios", null, 1);
        SQLiteDatabase db=conn.getWritableDatabase();
        return db;
    }
    //en este metodo se insertan los usuarios: se crea una consulta sql string, que inserta los usuarios;finalmente, se ejecuta
    //la consulta sql dentro d eun try catch, por si algo no sale bien. Retorna el entero creado al principio del programa
    int insertaUsuario(Context context, UsuariosDTO dto){
        int res=0;
        String sql="INSERT INTO usuarios (id, nombre, apellidos) VALUES ('"+dto.getId()+"', '"+
                    dto.getNombre()+"', '"+dto.getApellidos()+"')";
        SQLiteDatabase db=this.getConn(context);
        try {
            db.execSQL(sql);
        }catch(Exception e){

        }
        return res;
    }
}
