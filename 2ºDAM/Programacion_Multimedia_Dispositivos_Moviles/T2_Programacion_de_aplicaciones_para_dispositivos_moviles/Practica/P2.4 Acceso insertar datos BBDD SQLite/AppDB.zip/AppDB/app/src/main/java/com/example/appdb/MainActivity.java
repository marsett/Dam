package com.example.appdb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    //se crea el boton insertar
    Button btnInsertar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //se iguala el boton al id del mismo boton
        btnInsertar=findViewById(R.id.btnInsert);
        //se le añade el OnClickListener para que, el boton, tenga una funcion al ser presionado
        btnInsertar.setOnClickListener(new View.OnClickListener(){
            //en el metodo simplemente se crea un objeto de la clase Intent, con el objetivo de empezar la actividad de la app
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this, InsertActivity.class);
                startActivity(intent);
            }
        });
    }
}