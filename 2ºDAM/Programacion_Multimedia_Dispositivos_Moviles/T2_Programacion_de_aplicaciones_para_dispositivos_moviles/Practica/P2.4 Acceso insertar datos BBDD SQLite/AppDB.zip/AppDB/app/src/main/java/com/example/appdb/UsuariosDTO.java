package com.example.appdb;

public class UsuariosDTO {
    //en esta clase, sencillamente se definen las variables que van a aparecer en el programa
    private int id;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public void setId(int id) {
        this.id = id;
    }

    private String nombre, apellidos;
}
