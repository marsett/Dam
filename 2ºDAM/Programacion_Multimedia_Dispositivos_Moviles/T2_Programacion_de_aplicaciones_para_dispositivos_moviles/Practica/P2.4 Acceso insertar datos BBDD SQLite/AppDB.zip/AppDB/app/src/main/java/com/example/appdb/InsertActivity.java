package com.example.appdb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class InsertActivity extends AppCompatActivity {
    //se crea el boton insertar
    Button btnInserta;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        //se iguala el boton al id del mismo boton
        btnInserta=findViewById(R.id.btnInsertAct);
        //se le añade el OnClickListener para que, el boton, tenga una funcion al ser presionado
        btnInserta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //se crea un objeto de la clase Modelo
                Modelo obj=new Modelo();
                //se crea un objeto de la clase UsuariosDTO
                UsuariosDTO usr=new UsuariosDTO();
                //se crean tres edit text, a cada uno de los cuales se les iguala el id
                EditText cve=findViewById(R.id.txtCve);
                EditText nombre=findViewById(R.id.txtNombre);
                EditText apellidos=findViewById(R.id.txtApellidos);
                //se fija en cada una de las variables el texto que inserte el usuario, pasandose al tipo de dato conveniente
                usr.setId(Integer.parseInt(cve.getText().toString()));
                usr.setNombre(nombre.getText().toString());
                usr.setApellidos(apellidos.getText().toString());
                //finalmente, para que muestre un mensaje si se ha insertado bien o no, se crea un entero que, con un condicional
                //te dice con un mensaje que sale en pantalla al insertar si esta bien hecho
                int restInsert= obj.insertaUsuario(InsertActivity.this, usr);
                if(restInsert==1){
                    Toast.makeText(InsertActivity.this, "OK", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(InsertActivity.this, "KO", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}