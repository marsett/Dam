package com.example.appdb;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class ConexionSQLite extends SQLiteOpenHelper {
    //en esta clase, se crea la consulta string, donde se crea la tabla y las variables
    final String crearTBL_USR="CREATE TABLE usuarios (id INTEGER, nombre TEXT, apellidos TEXT)";
    public ConexionSQLite(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
    //en el siguiente metodo onCreate, se ejecuta la consulta SQL creada antes
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(crearTBL_USR);
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
