package com.example.lvporcentajes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class PantallaDos extends AppCompatActivity{
    //se crean las variables que se utilizarán en el onCreate de la clase
    private EditText etUnoUno, etDosUno, etTresUno, etCuatroUno, etCincoUno, etSeisUno, etSieteUno, etOchoUno, etNueveUno, etDiezUno;
    private Bundle datos;
    private Button btAnterior, btSiguiente;
    private Switch swUno, swDos, swTres, swCuatro, swCinco, swSeis, swSiete, swOcho, swNueve, swDiez;
    private CheckBox cbUno, cbDos, cbTres, cbCuatro, cbCinco;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.segunda_pantalla);

        //a través del Bundle se recogen los datos del anterior activity
        datos=getIntent().getExtras();
        //por cada variable se enlaza el id correspondiente a las variables de segunda_pantalla
        btAnterior=(Button)findViewById(R.id.btAnterior);

        etUnoUno=(EditText) findViewById(R.id.etUnoUno);
        etDosUno=(EditText) findViewById(R.id.etDosUno);
        etTresUno=findViewById(R.id.etTresUno);
        etCuatroUno=findViewById(R.id.etCuatroUno);
        etCincoUno=findViewById(R.id.etCincoUno);
        etSeisUno=findViewById(R.id.etSeisUno);
        etSieteUno=findViewById(R.id.etSieteUno);
        etOchoUno=findViewById(R.id.etOchoUno);
        etNueveUno=findViewById(R.id.etNueveUno);
        etDiezUno=findViewById(R.id.etDiezUno);

        cbUno=(CheckBox)findViewById(R.id.cbUno);
        cbDos=(CheckBox)findViewById(R.id.cbDos);
        cbTres=(CheckBox)findViewById(R.id.cbTres);
        cbCuatro=(CheckBox)findViewById(R.id.cbCuatro);
        cbCinco=(CheckBox)findViewById(R.id.cbCinco);

        swSeis=(Switch)findViewById(R.id.switchSeis);
        swSiete=(Switch)findViewById(R.id.switchSiete);
        swOcho=(Switch)findViewById(R.id.switchOcho);
        swNueve=(Switch)findViewById(R.id.switchNueve);
        swDiez=(Switch)findViewById(R.id.switchDiez);

        //se recoge la información a través del bundle y el nombre identificativo establecido en el MainActivity
        //se fija en cada EditText de la clase esta información recogida en variables String
        String recUnoUno=datos.getString("datosUnoUno");
        String recUnoDos=datos.getString("datosUnoDos");
        etUnoUno.setText(recUnoUno+" - "+recUnoDos);

        String recDosUno=datos.getString("datosDosUno");
        String recDosDos=datos.getString("datosDosDos");
        etDosUno.setText(recDosUno+" - "+recDosDos);

        String recTresUno=datos.getString("datosTresUno");
        String recTresDos=datos.getString("datosTresDos");
        etTresUno.setText(recTresUno+" - "+recTresDos);

        String recCuatroUno=datos.getString("datosCuatroUno");
        String recCuatroDos=datos.getString("datosCuatroDos");
        etCuatroUno.setText(recCuatroUno+" - "+recCuatroDos);

        String recCincoUno=datos.getString("datosCincoUno");
        String recCincoDos=datos.getString("datosCincoDos");
        etCincoUno.setText(recCincoUno+" - "+recCincoDos);

        String recSeisUno=datos.getString("datosSeisUno");
        String recSeisDos=datos.getString("datosSeisDos");
        etSeisUno.setText(recSeisUno+" - "+recSeisDos);

        String recSieteUno=datos.getString("datosSieteUno");
        String recSieteDos=datos.getString("datosSieteDos");
        etSieteUno.setText(recSieteUno+" - "+recSieteDos);

        String recOchoUno=datos.getString("datosOchoUno");
        String recOchoDos=datos.getString("datosOchoDos");
        etOchoUno.setText(recOchoUno+" - "+recOchoDos);

        String recNueveUno=datos.getString("datosNueveUno");
        String recNueveDos=datos.getString("datosNueveDos");
        etNueveUno.setText(recNueveUno+" - "+recNueveDos);

        String recDiezUno=datos.getString("datosDiezUno");
        String recDiezDos=datos.getString("datosDiezDos");
        etDiezUno.setText(recDiezUno+" - "+recDiezDos);

        btSiguiente=findViewById(R.id.btSiguiente);
        btSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //al clicar en Siguiente, se crea un Intent que pasa la información a la PantallaTres
                Intent abrirActivityTres=new Intent(PantallaDos.this,PantallaTres.class);
                //si en esta clase se ha clicado el combobox o el switch, un String tendrá almacenado una cadena u otra
                //esa información se pasa a la última pantalla
                String clicado;
                    if(cbUno.isChecked()){
                        clicado="si";
                    }else{
                        clicado="no";
                    }
                    abrirActivityTres.putExtra("cb1", clicado);
                    if(cbDos.isChecked()){
                        clicado="si";
                    }else{
                        clicado="no";
                    }
                    abrirActivityTres.putExtra("cb2", clicado);
                    if(cbTres.isChecked()){
                        clicado="si";
                    }else{
                        clicado="no";
                    }
                    abrirActivityTres.putExtra("cb3", clicado);
                if(cbCuatro.isChecked()){
                    clicado="si";
                }else{
                    clicado="no";
                }
                abrirActivityTres.putExtra("cb4", clicado);
                if(cbCinco.isChecked()){
                    clicado="si";
                }else{
                    clicado="no";
                }
                abrirActivityTres.putExtra("cb5", clicado);
                if(swSeis.isChecked()){
                    clicado="si";
                }else{
                    clicado="no";
                }
                abrirActivityTres.putExtra("sww6", clicado);
                if(swSiete.isChecked()){
                    clicado="si";
                }else{
                    clicado="no";
                }
                abrirActivityTres.putExtra("sww7", clicado);
                if(swOcho.isChecked()){
                    clicado="si";
                }else{
                    clicado="no";
                }
                abrirActivityTres.putExtra("sww8", clicado);
                if(swNueve.isChecked()){
                    clicado="si";
                }else{
                    clicado="no";
                }
                abrirActivityTres.putExtra("sww9", clicado);
                if(swDiez.isChecked()){
                    clicado="si";
                }else{
                    clicado="no";
                }
                abrirActivityTres.putExtra("sww10", clicado);

                //se pasa la información de nombre y teléfono a la última pantalla
                abrirActivityTres.putExtra("lvUnoUno",recUnoUno);
                abrirActivityTres.putExtra("lvUnoDos",recUnoDos);
                abrirActivityTres.putExtra("lvDosUno",recDosUno);
                abrirActivityTres.putExtra("lvDosDos",recDosDos);
                abrirActivityTres.putExtra("lvTresUno",recTresUno);
                abrirActivityTres.putExtra("lvTresDos",recTresDos);
                abrirActivityTres.putExtra("lvCuatroUno",recCuatroUno);
                abrirActivityTres.putExtra("lvCuatroDos",recCuatroDos);
                abrirActivityTres.putExtra("lvCincoUno",recCincoUno);
                abrirActivityTres.putExtra("lvCincoDos",recCincoDos);
                abrirActivityTres.putExtra("lvSeisUno",recSeisUno);
                abrirActivityTres.putExtra("lvSeisDos",recSeisDos);
                abrirActivityTres.putExtra("lvSieteUno",recSieteUno);
                abrirActivityTres.putExtra("lvSieteDos",recSieteDos);
                abrirActivityTres.putExtra("lvOchoUno",recOchoUno);
                abrirActivityTres.putExtra("lvOchoDos",recOchoDos);
                abrirActivityTres.putExtra("lvNueveUno",recNueveUno);
                abrirActivityTres.putExtra("lvNueveDos",recNueveDos);
                abrirActivityTres.putExtra("lvDiezUno",recDiezUno);
                abrirActivityTres.putExtra("lvDiezDos",recDiezDos);
                startActivity(abrirActivityTres);
            }
        });
        //el botón Anterior simplemente llama a un método que permite volver al activity anterior con el objetivo de comprobar o actualizar los datos
        btAnterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    PantallaDos.super.onBackPressed();
            }
        });
    }
}
