package com.example.lvporcentajes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    //el MainActivity corresponde a la primera ventana de la aplicación
    //se crean las variables que se corresponden a las que existen en el activity_main
    private EditText etUnoUno, etUnoDos, etDosUno, etDosDos, etTresUno, etTresDos, etCuatroUno;
    private EditText etCuatroDos,etCincoUno,etCincoDos,etSeisUno,etSeisDos,etSieteUno,etSieteDos;
    private EditText etOchoUno, etOchoDos,etNueveUno,etNueveDos,etDiezUno,etDiezDos;
    private Button btSiguiente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //a cada variable se le enlaza el id correspondiente a su variable del activity_main
        etUnoUno=(EditText) findViewById(R.id.etUnoUno);
        etUnoDos=findViewById(R.id.etUnoDos);
        etDosUno=findViewById(R.id.etDosUno);
        etDosDos=findViewById(R.id.etDosDos);
        etTresUno=findViewById(R.id.etTresUno);
        etTresDos=findViewById(R.id.etTresDos);
        etCuatroUno=findViewById(R.id.etCuatroUno);
        etCuatroDos=findViewById(R.id.etCuatroDos);
        etCincoUno=findViewById(R.id.etCincoUno);
        etCincoDos=findViewById(R.id.etCincoDos);
        etSeisUno=findViewById(R.id.etSeisUno);
        etSeisDos=findViewById(R.id.etSeisDos);
        etSieteUno=findViewById(R.id.etSieteUno);
        etSieteDos=findViewById(R.id.etSieteDos);
        etOchoUno=findViewById(R.id.etOchoUno);
        etOchoDos=findViewById(R.id.etOchoDos);
        etNueveUno=findViewById(R.id.etNueveUno);
        etNueveDos=findViewById(R.id.etNueveDos);
        etDiezUno=findViewById(R.id.etDiezUno);
        etDiezDos=findViewById(R.id.etDiezDos);

        btSiguiente=findViewById(R.id.btSiguiente);
        //se le da funcionalidad al botón Siguiente
        btSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //al clicar en Siguiente, se recuperan en variables lo introducido en los campos de texto
                String unoUno=etUnoUno.getText().toString();
                String unoDos=etUnoDos.getText().toString();
                String dosUno=etDosUno.getText().toString();
                String dosDos=etDosDos.getText().toString();
                String tresUno=etTresUno.getText().toString();
                String tresDos=etTresDos.getText().toString();
                String cuatroUno=etCuatroUno.getText().toString();
                String cuatroDos=etCuatroDos.getText().toString();
                String cincoUno=etCincoUno.getText().toString();
                String cincoDos=etCincoDos.getText().toString();
                String seisUno=etSeisUno.getText().toString();
                String seisDos=etSeisDos.getText().toString();
                String sieteUno=etSieteUno.getText().toString();
                String sieteDos=etSieteDos.getText().toString();
                String ochoUno=etOchoUno.getText().toString();
                String ochoDos=etOchoDos.getText().toString();
                String nueveUno=etNueveUno.getText().toString();
                String nueveDos=etNueveDos.getText().toString();
                String diezUno=etDiezUno.getText().toString();
                String diezDos=etDiezDos.getText().toString();
                //se crea un Intent que tiene como objetivo mandar esta información del MainActivity a la PantallaDos
                Intent abrirActivityDos=new Intent(MainActivity.this,PantallaDos.class);
                //a cada EditText, se le introduce un nombre identificativo, además de la variable correspondiente
                abrirActivityDos.putExtra("datosUnoUno",unoUno);
                abrirActivityDos.putExtra("datosUnoDos",unoDos);
                abrirActivityDos.putExtra("datosDosUno",dosUno);
                abrirActivityDos.putExtra("datosDosDos",dosDos);
                abrirActivityDos.putExtra("datosTresUno",tresUno);
                abrirActivityDos.putExtra("datosTresDos",tresDos);
                abrirActivityDos.putExtra("datosCuatroUno",cuatroUno);
                abrirActivityDos.putExtra("datosCuatroDos",cuatroDos);
                abrirActivityDos.putExtra("datosCincoUno",cincoUno);
                abrirActivityDos.putExtra("datosCincoDos",cincoDos);
                abrirActivityDos.putExtra("datosSeisUno",seisUno);
                abrirActivityDos.putExtra("datosSeisDos",seisDos);
                abrirActivityDos.putExtra("datosSieteUno",sieteUno);
                abrirActivityDos.putExtra("datosSieteDos",sieteDos);
                abrirActivityDos.putExtra("datosOchoUno",ochoUno);
                abrirActivityDos.putExtra("datosOchoDos",ochoDos);
                abrirActivityDos.putExtra("datosNueveUno",nueveUno);
                abrirActivityDos.putExtra("datosNueveDos",nueveDos);
                abrirActivityDos.putExtra("datosDiezUno",diezUno);
                abrirActivityDos.putExtra("datosDiezDos",diezDos);
                //se abre el activity siguiente
                startActivity(abrirActivityDos);
            }
        });
    }
}