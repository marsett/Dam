package com.example.lvporcentajes;

public class Modelo {
    //en esta clase simplemente se declaran las variables y se crean el constructor y los getters y setters correspondientes
    String nombre;
    String telefono;
    int imagen;
    public Modelo(){}
    public Modelo(String nombre, String telefono, int imagen) {
        this.nombre=nombre;
        this.telefono=telefono;
        this.imagen=imagen;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre= nombre;
    }
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public int getImagen() {
        return imagen;
    }
    public void setImagen(int imagen) {
        this.imagen = imagen;
    }
}
