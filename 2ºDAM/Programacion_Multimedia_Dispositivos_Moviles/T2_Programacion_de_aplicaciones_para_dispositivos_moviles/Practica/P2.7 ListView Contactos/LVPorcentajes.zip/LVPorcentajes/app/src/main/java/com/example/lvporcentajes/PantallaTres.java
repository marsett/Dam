package com.example.lvporcentajes;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class PantallaTres extends AppCompatActivity {
    //se crean las variables a usar en el programa
    ListView listView;
    List<Modelo> mLista=new ArrayList<>();
    ListAdapter mAdapter;
    private Bundle datos;
    private Button btAnterior;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tercera_pantalla);

        btAnterior=(Button)findViewById(R.id.btAnterior);

        btAnterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PantallaTres.super.onBackPressed();
            }
        });

        datos=getIntent().getExtras();
        //se recoge la información del activity anterior
        String unoUno=datos.getString("lvUnoUno");
        String unoDos=datos.getString("lvUnoDos");
        String dosUno=datos.getString("lvDosUno");
        String dosDos=datos.getString("lvDosDos");
        String tresUno=datos.getString("lvTresUno");
        String tresDos=datos.getString("lvTresDos");
        String cuatroUno=datos.getString("lvCuatroUno");
        String cuatroDos=datos.getString("lvCuatroDos");
        String cincoUno=datos.getString("lvCincoUno");
        String cincoDos=datos.getString("lvCincoDos");
        String seisUno=datos.getString("lvSeisUno");
        String seisDos=datos.getString("lvSeisDos");
        String sieteUno=datos.getString("lvSieteUno");
        String sieteDos=datos.getString("lvSieteDos");
        String ochoUno=datos.getString("lvOchoUno");
        String ochoDos=datos.getString("lvOchoDos");
        String nueveUno=datos.getString("lvNueveUno");
        String nueveDos=datos.getString("lvNueveDos");
        String diezUno=datos.getString("lvDiezUno");
        String diezDos=datos.getString("lvDiezDos");

        String recsw1=datos.getString("cb1");
        String recsw2=datos.getString("cb2");
        String recsw3=datos.getString("cb3");
        String recsw4=datos.getString("cb4");
        String recsw5=datos.getString("cb5");
        String recsw6=datos.getString("sww6");
        String recsw7=datos.getString("sww7");
        String recsw8=datos.getString("sww8");
        String recsw9=datos.getString("sww9");
        String recsw10=datos.getString("sww10");

        listView=findViewById(R.id.listView);
        //al array creado, dependiendo si clicado contiene una cadena u otra, se creará un objeto Modelo diferente
        //esto se ha hecho con el objetivo de cambiar de imagen cada vez que se clique o no los combobox y switchs
        if(recsw1.equals("si")) {
            mLista.add(new Modelo(unoUno, unoDos, R.drawable.contento_low));
        }else if(recsw1.equals("no")){
            mLista.add(new Modelo(unoUno, unoDos, R.drawable.enfadado_low));
        }
        if(recsw2.equals("si")){
            mLista.add(new Modelo(dosUno,dosDos,R.drawable.contento_low));
        }else if(recsw2.equals("no")){
            mLista.add(new Modelo(dosUno,dosDos,R.drawable.enfadado_low));
        }
        if(recsw3.equals("si")){
            mLista.add(new Modelo(tresUno,tresDos,R.drawable.contento_low));
        }else if(recsw3.equals("no")){
            mLista.add(new Modelo(tresUno,tresDos,R.drawable.enfadado_low));
        }
        if(recsw4.equals("si")){
            mLista.add(new Modelo(cuatroUno,cuatroDos,R.drawable.contento_low));
        }else if(recsw4.equals("no")){
            mLista.add(new Modelo(cuatroUno,cuatroDos,R.drawable.enfadado_low));
        }
        if(recsw5.equals("si")){
            mLista.add(new Modelo(cincoUno,cincoDos,R.drawable.contento_low));
        }else if(recsw5.equals("no")){
            mLista.add(new Modelo(cincoUno,cincoDos,R.drawable.enfadado_low));
        }
        if(recsw6.equals("si")){
            mLista.add(new Modelo(seisUno,seisDos,R.drawable.contento_low));
        }else if(recsw6.equals("no")){
            mLista.add(new Modelo(seisUno,seisDos,R.drawable.enfadado_low));
        }
        if(recsw7.equals("si")){
            mLista.add(new Modelo(sieteUno,sieteDos,R.drawable.contento_low));
        }else if(recsw7.equals("no")){
            mLista.add(new Modelo(sieteUno,sieteDos,R.drawable.enfadado_low));
        }
        if(recsw8.equals("si")){
            mLista.add(new Modelo(ochoUno,ochoDos,R.drawable.contento_low));
        }else if(recsw8.equals("no")){
            mLista.add(new Modelo(ochoUno,ochoDos,R.drawable.enfadado_low));
        }
        if(recsw9.equals("si")){
            mLista.add(new Modelo(nueveUno,nueveDos,R.drawable.contento_low));
        }else if(recsw9.equals("no")){
            mLista.add(new Modelo(nueveUno,nueveDos,R.drawable.enfadado_low));
        }
        if(recsw10.equals("si")){
            mLista.add(new Modelo(diezUno,diezDos,R.drawable.contento_low));
        }else if(recsw10.equals("no")){
            mLista.add(new Modelo(diezUno,diezDos,R.drawable.enfadado_low));
        }

        //se crea una instancia de ListAdapter, estableciendo el contexto, donde fijar la información (en qué xml) y el array con la información
        mAdapter=new ListAdapter(PantallaTres.this,R.layout.item_row,mLista);
        //se fija el adaptador dentro del listview, por lo que dentro de este aparecerá la información insertada en anteriores activities
        listView.setAdapter(mAdapter);
    }
}
