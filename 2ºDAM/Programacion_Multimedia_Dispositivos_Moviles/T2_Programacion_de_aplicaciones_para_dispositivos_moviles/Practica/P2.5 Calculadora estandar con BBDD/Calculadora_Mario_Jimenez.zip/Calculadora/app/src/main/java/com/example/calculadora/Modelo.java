package com.example.calculadora;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class Modelo {
    //se crea la conexion con la base de datos, siendo el metodo de la conexion WritableDatabase (puesto que se va a escribir en la db)
    public SQLiteDatabase getConn(Context context){
        ConexionSQLite conn=new ConexionSQLite(context, "dbNumerosEnMemoriaString", null, 1);
        SQLiteDatabase db=conn.getWritableDatabase();
        return db;
    }
    /*int insertaNumero(Context context, VariablesMemoria vm){
        int res=0;
        String sql="INSERT INTO NumerosEnMemoriaString (id, memoriaBase1, memoriaBase2, memoriaBase3) VALUES ('"+vm.getId()+"', '"+
                vm.getMemoriaBase1()+"','"+vm.getMemoriaBase2()+"','"+vm.getMemoriaBase3()+"')";
        SQLiteDatabase db=this.getConn(context);
        try {
            db.execSQL(sql);
        }catch(Exception e){

        }
        return res;
    }*/
    //se crean tres metodos iguales para insertar los numeros en cada memoria, ademas de su id correspondiente:
    //se ejecuta la consulta con la db creada a partir de la conexion anterior
    int insertaNum1(Context context, VariablesMemoria vm){
        int res=0;
        String sql="INSERT INTO NumerosEnMemoriaString (id, memoriaBase1) VALUES ('"+vm.getId()+"', '"+
                vm.getMemoriaBase1()+"')";
        SQLiteDatabase db=this.getConn(context);
        try {
            db.execSQL(sql);
        }catch(Exception e){

        }
        return res;
    }
    int insertaNum2(Context context, VariablesMemoria vm){
        int res=0;
        String sql="INSERT INTO NumerosEnMemoriaString (id, memoriaBase2) VALUES ('"+vm.getId()+"', '"+
                vm.getMemoriaBase2()+"')";
        SQLiteDatabase db=this.getConn(context);
        try {
            db.execSQL(sql);
        }catch(Exception e){

        }
        return res;
    }
    int insertaNum3(Context context, VariablesMemoria vm){
        int res=0;
        String sql="INSERT INTO NumerosEnMemoriaString (id, memoriaBase3) VALUES ('"+vm.getId()+"', '"+
                vm.getMemoriaBase3()+"')";
        SQLiteDatabase db=this.getConn(context);
        try {
            db.execSQL(sql);
        }catch(Exception e){

        }
        return res;
    }
}
