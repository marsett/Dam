package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
public class MainActivity extends AppCompatActivity {
    TextView tvResultado, memoria1, memoria2, memoria3;
    Button btGuardar;
    Button btLeer;
    RadioButton m1, m2, m3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //por cada variable creada, se conecta con el id del elemento creado en el xml (la interfaz de la calculadora)
        tvResultado = findViewById(R.id.tvResultado);
        tvResultado.setText("0");

        btGuardar=findViewById(R.id.idGuardar);
        btLeer=findViewById(R.id.idLeer);
        m1=findViewById(R.id.btMem1);
        m2=findViewById(R.id.btMem2);
        m3=findViewById(R.id.btMem3);
        memoria1=findViewById(R.id.idMemoria1);
        memoria2=findViewById(R.id.idMemoria2);
        memoria3=findViewById(R.id.idMemoria3);

        Modelo objModelo=new Modelo();

        for(int i=0;i<1000;i++) {
            int id = i;
            //cada vez que se clica en una memoria, se fija en el textview correspondiente el resultado
            //del text view de arriba
            //hecho esto, si se clica en guardar, se guarda ese resultado en la base de datos
            //con su id correspondiente
            m1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    memoria1.setText(tvResultado.getText());
                    btGuardar.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            //se crea un objeto de la clase VariablesMemoria, cogiendo el constructor del id
                            VariablesMemoria objVariablesMemoria = new VariablesMemoria(id);

                            //se fija en la memoria el resultado del tvResultado
                            objVariablesMemoria.setMemoriaBase1((String) tvResultado.getText());
                            //se inserta con el objeto de la clase Modelo y el metodo el objeto que se acaba de crear de
                            //la clase VariablesMemoria
                            int restInsert1 = objModelo.insertaNum1(MainActivity.this, objVariablesMemoria);

                            //si se ha insertado, muestra un mensaje por pantalla (justo despues de clicar en guardar)
                            if (restInsert1 == 1) {
                                Toast.makeText(MainActivity.this, "INSERTADO EN BD", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(MainActivity.this, "INSERTADO EN BD", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                }
            });
            m2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    memoria2.setText(tvResultado.getText());
                    btGuardar.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            VariablesMemoria objVariablesMemoria=new VariablesMemoria(id);

                            objVariablesMemoria.setMemoriaBase2((String) tvResultado.getText());
                            int restInsert2 = objModelo.insertaNum2(MainActivity.this, objVariablesMemoria);
                            if (restInsert2 == 1) {
                                Toast.makeText(MainActivity.this, "INSERTADO EN BD", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(MainActivity.this, "INSERTADO EN BD", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            });
            m3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    memoria3.setText(tvResultado.getText());
                    btGuardar.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            VariablesMemoria objVariablesMemoria=new VariablesMemoria(id);

                            objVariablesMemoria.setMemoriaBase3((String) tvResultado.getText());
                            int restInsert3 = objModelo.insertaNum3(MainActivity.this, objVariablesMemoria);
                            if (restInsert3 == 1) {
                                Toast.makeText(MainActivity.this, "INSERTADO EN BD", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(MainActivity.this, "INSERTADO EN BD", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            });
        }
    }

    //metodo que limpia el resultado, al clicar en AC
    public void LimpiarResultado(View view) {
        tvResultado.setText("0");
    }

    public void pulsaNumero(View v) {
        if (tvResultado.getText() == "0")
            tvResultado.setText("");
        Button bt = (Button) v;
        String boton = (String) bt.getText();
        tvResultado.setText(tvResultado.getText() + boton);
    }

    public void Resultado(View view) {
        String valores = (String) tvResultado.getText();
        List<String> numeros = new ArrayList<String>();
        String numero = "";
        int indice = valores.length();
        for (int i = 0; i < indice; i++) {
            char c = valores.charAt(i);
            if (c == '.') {
                numero += String.valueOf(c);
            }
            else {
                numero += Character.getNumericValue(c);
                int n = Character.getNumericValue(c); //Si no es numerico retorna -1
                if ((n == -1) || (i == (indice - 1))) {
                    if ((n == -1)) {
                        numero = numero.substring(0, numero.length() - 2);
                    }
                    numeros.add(numero);
                    numeros.add(String.valueOf(c));
                    numero = "";
                }
            }
        }
        numeros.remove(numeros.size() - 1);
        Log.d("", numeros.toString());

        resultado((ArrayList) numeros);
    }

    private void resultado(ArrayList numeros) {
        Float acumulador = 0f;
        Float num1 = 0f;
        Float num2 = 0f;
        String signo = "";
        for (int i = 1; i < numeros.size(); i += 2) {
            if (i == 1) {
                num1 = Float.parseFloat((String) numeros.get(i - 1));
            }
            else {
                num1 = Float.parseFloat((String) numeros.get(i + 1));
            }
            num2 = Float.parseFloat((String) numeros.get(i + 1));
            signo = (String) numeros.get(i);
            switch (signo) {
                case "+":
                    if (i == 1) {
                        acumulador += (num1 + num2);
                    } else {
                        acumulador += num1;
                    }
                    break;
                case "-":
                    if (i == 1) {
                        acumulador += (num1 - num2);
                    } else {
                        acumulador += num1;
                    }
                    break;
                case "*":
                    if (i == 1) {
                        acumulador += (num1 * num2);
                    } else {
                        acumulador += num1;
                    }
                    break;
                case "/":
                    if (i == 1) {
                        acumulador += (num1 / num2);
                    } else {
                        acumulador += num1;
                    }
                    break;
                case "%":
                    if (i == 1) {
                        acumulador += ((num1 * num2)/100);
                    } else {
                        acumulador += num1;
                    }
                    break;
            }

            num2 = acumulador;

            Log.d("VALORES: ", String.valueOf(i));
            Log.d("ACUMULADOR: ", String.valueOf(acumulador));
        }
        tvResultado.setText(acumulador + "");

    }

}