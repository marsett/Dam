package com.example.calculadora;

public class VariablesMemoria {
    //se crean las variables, constructores y metodos correspondientes
    private static int contadorIds=1;
    private int id;
    private String memoriaBase1, memoriaBase2, memoriaBase3;
    public VariablesMemoria(){

    }
    //para que el id sea incremental en cada ejecucion, se iguala el id a otra variable,
    //la cual se suma cada vez que se usa el constructor
    public VariablesMemoria(int id){
        this();
        id=contadorIds;
        contadorIds++;
        setId(id);
    }
    public VariablesMemoria(int id, String memoriaBase1, String memoriaBase2, String memoriaBase3){
        this();
        id=contadorIds;
        contadorIds++;
        setId(id);
        setMemoriaBase1(memoriaBase1);
        setMemoriaBase2(memoriaBase2);
        setMemoriaBase3(memoriaBase3);
    }
    public void setId(int id){
        this.id=id;
    }
    public int getId() {
        return id;
    }
    public void setMemoriaBase1(String memoriaBase1){
        this.memoriaBase1=memoriaBase1;
    }
    public String getMemoriaBase1(){
        return memoriaBase1;
    }
    public void setMemoriaBase2(String memoriaBase2){
        this.memoriaBase2=memoriaBase2;
    }
    public String getMemoriaBase2(){
        return memoriaBase2;
    }
    public void setMemoriaBase3(String memoriaBase3){
        this.memoriaBase3=memoriaBase3;
    }
    public String getMemoriaBase3(){
        return memoriaBase3;
    }
}
