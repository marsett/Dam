package com.example.examen;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class Modelo {
    //se crea un metodo que llama a la conexion de la otra clase y se establece el objeto de la clase SQLiteDatabase
    //igual a la conexion.getWritableDatabase (ya que solo se van a insertar datos en la base)
    public SQLiteDatabase getConn(Context context){
        ConexionSQLite conn=new ConexionSQLite(context,"dbTickets",null,1);
        SQLiteDatabase db=conn.getWritableDatabase();
        return db;
    }
    //en este metodo que retorna int (que sirve para establecer el Toast en el MainActivity)
    //se muestra la consulta que inserta los datos en la base de datos
    //en un try-catch, se ejecuta la consulta
    int insertaTickets(Context context, VariablesTickets varTickets){
        int res=0;
        String sql="INSERT INTO tickets (ud1, articulo1, precio1," +
                                        "ud2, articulo2, precio2," +
                                        "ud3, articulo3, precio3," +
                                        "totalTicket)" +
                    "VALUES ('"+varTickets.getUd1()+"','"+varTickets.getArticulo1()+"','"
                    +varTickets.getPrecio1()+"','"+varTickets.getUd2()+"','"+varTickets.getArticulo2()+"','"
                +varTickets.getPrecio2()+"','"+varTickets.getUd3()+"','"+varTickets.getArticulo3()+"','"
                +varTickets.getPrecio3()+"','"+varTickets.getTotalTicket()+"')";
        SQLiteDatabase db=this.getConn(context);
        try{
            db.execSQL(sql);
        }catch(Exception e){

        }
        return res;
    }

}
