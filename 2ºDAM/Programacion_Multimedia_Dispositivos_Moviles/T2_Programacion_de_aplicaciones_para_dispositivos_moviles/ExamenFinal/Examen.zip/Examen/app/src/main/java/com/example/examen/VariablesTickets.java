package com.example.examen;

public class VariablesTickets {
    //se crean todas las variables que estaran en la base de datos, con sus respectivos getters y setters
    private int ud1, ud2, ud3;
    private String articulo1, articulo2, articulo3;
    private double precio1, precio2, precio3, totalTicket;
    public int getUd1(){
        return ud1;
    }
    public void setUd1(int ud1){
        this.ud1=ud1;
    }
    public int getUd2(){
        return ud2;
    }
    public void setUd2(int ud2){
        this.ud2=ud2;
    }
    public int getUd3(){
        return ud3;
    }
    public void setUd3(int ud3){
        this.ud3=ud3;
    }
    public String getArticulo1(){
        return articulo1;
    }
    public void setArticulo1(String articulo1){
        this.articulo1=articulo1;
    }
    public String getArticulo2(){
        return articulo2;
    }
    public void setArticulo2(String articulo2){
        this.articulo2=articulo2;
    }
    public String getArticulo3(){
        return articulo3;
    }
    public void setArticulo3(String articulo3){
        this.articulo3=articulo3;
    }
    public double getPrecio1(){
        return precio1;
    }
    public void setPrecio1(double precio1){
        this.precio1=precio1;
    }
    public double getPrecio2(){
        return precio2;
    }
    public void setPrecio2(double precio2){
        this.precio2=precio2;
    }
    public double getPrecio3(){
        return precio3;
    }
    public void setPrecio3(double precio3){
        this.precio3=precio3;
    }
    public double getTotalTicket(){
        return totalTicket;
    }
    public void setTotalTicket(double totalTicket){
        this.totalTicket=totalTicket;
    }
}
