package com.example.examen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //se crean las variables a utilizar dentro de la clase
    EditText cajaUd1, cajaUd2, cajaUd3, cajaArticulo1, cajaArticulo2, cajaArticulo3, cajaPrecio1, cajaPrecio2, cajaPrecio3, totalTicket;
    Button btnGuardar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //a cada componente se le añade el id correspondiente al elemento del xml
        cajaUd1=findViewById(R.id.idCajaUd1);
        cajaUd2=findViewById(R.id.idCajaUd2);
        cajaUd3=findViewById(R.id.idCajaUd3);
        cajaArticulo1=findViewById(R.id.idCajaArticulo1);
        cajaArticulo2=findViewById(R.id.idCajaArticulo2);
        cajaArticulo3=findViewById(R.id.idCajaArticulo3);
        cajaPrecio1=findViewById(R.id.idCajaPrecio1);
        cajaPrecio2=findViewById(R.id.idCajaPrecio2);
        cajaPrecio3=findViewById(R.id.idCajaPrecio3);
        totalTicket=findViewById(R.id.idCajaTotal);

        //se llama con el boton Guardar al listener, para que al ser presionado realice la funcionalidad siguiente
        btnGuardar=findViewById(R.id.idbtnGuardar);
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //se crea un objeto de la clase Modelo
                Modelo obj=new Modelo();
                //se crea un objeto de la clase VariablesTickets
                VariablesTickets variablesTickets=new VariablesTickets();
                //se fija cada columna de la base de datos, parseando cuando se necesita lo que ha insertado el usuario
                //en cada EditText
                variablesTickets.setUd1(Integer.parseInt(cajaUd1.getText().toString()));
                variablesTickets.setUd2(Integer.parseInt(cajaUd2.getText().toString()));
                variablesTickets.setUd3(Integer.parseInt(cajaUd3.getText().toString()));
                variablesTickets.setArticulo1(cajaArticulo1.getText().toString());
                variablesTickets.setArticulo2(cajaArticulo2.getText().toString());
                variablesTickets.setArticulo3(cajaArticulo3.getText().toString());
                variablesTickets.setPrecio1(Double.parseDouble(cajaPrecio1.getText().toString()));
                variablesTickets.setPrecio2(Double.parseDouble(cajaPrecio2.getText().toString()));
                variablesTickets.setPrecio3(Double.parseDouble(cajaPrecio3.getText().toString()));
                variablesTickets.setTotalTicket(Double.parseDouble(totalTicket.getText().toString()));

                //se llama al metodo de la clase Modelo y se realiza la insercion de datos
                //se muestra un toast que saldra cuando se haya pulsado el boton Guardar
                int restInsert=obj.insertaTickets(MainActivity.this,variablesTickets);
                if(restInsert==0){
                    Toast.makeText(MainActivity.this,"DATOS INSERTADOS",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this,"DATOS INSERTADOS ELSE",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    //este metodo esta relacionado con el boton Borrar (al clicarse se ejecutara lo que hay dentro)
    public void limpiarResultado(View view) {
        //se fijan vacios todos los campos
        cajaUd1.setText("");cajaUd2.setText("");cajaUd3.setText("");
        cajaArticulo1.setText("");cajaArticulo2.setText("");cajaArticulo3.setText("");
        cajaPrecio1.setText("");cajaPrecio2.setText("");cajaPrecio3.setText("");
        totalTicket.setText("");
        //se muestra un Toast al clicar el boton Borrar
        Toast.makeText(MainActivity.this,"CAMPOS BORRADOS",Toast.LENGTH_SHORT).show();
    }
    //metodo relacionado con el boton Total
    public void totalTicket(View view) {
        //se reocgen tanto unidades como precios (parseando)
        double precio1=Double.parseDouble(cajaPrecio1.getText().toString());
        double precio2=Double.parseDouble(cajaPrecio2.getText().toString());
        double precio3=Double.parseDouble(cajaPrecio3.getText().toString());
        int unidad1=Integer.parseInt(cajaUd1.getText().toString());
        int unidad2=Integer.parseInt(cajaUd2.getText().toString());
        int unidad3=Integer.parseInt(cajaUd3.getText().toString());

        //se crea una variable que multiplica cada fila de unidad con precio (y se terminan sumando todos)
        double sumaTotal=(precio1*unidad1)+(precio2*unidad2)+(precio3*unidad3);
        //se fija el valor final
        totalTicket.setText(""+sumaTotal);
        //se muestra un Toast al clicar en el boton Total
        Toast.makeText(MainActivity.this,"TOTAL DEL TICKET",Toast.LENGTH_SHORT).show();
    }
}