package com.example.examen;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class ConexionSQLite extends SQLiteOpenHelper {
    //se crea la consulta, creando la tabla con todas las variables y su tipo de dato
    final String crearTabla="CREATE TABLE tickets (ud1 INTEGER, articulo1 TEXT, precio1 DOUBLE," +
                                                "ud2 INTEGER, articulo2 TEXT, precio2 DOUBLE," +
                                                "ud3 INTEGER, articulo3 TEXT, precio3 DOUBLE," +
                                                "totalTicket DOUBLE)";
    public ConexionSQLite(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version){
        super(context, name, factory, version);
    }
    //en este metodo sobrescrito se ejecuta la consulta
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(crearTabla);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
