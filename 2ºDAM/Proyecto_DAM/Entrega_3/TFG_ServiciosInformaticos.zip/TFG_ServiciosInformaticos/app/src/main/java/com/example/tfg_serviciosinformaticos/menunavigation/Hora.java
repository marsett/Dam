package com.example.tfg_serviciosinformaticos.menunavigation;

public class Hora {
    private Integer id;
    private String hora;
    private String minutos;
    public Hora(){}
    public Hora(Integer id, String hora, String minutos){
        this.id=id;
        this.hora=hora;
        this.minutos=minutos;
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getMinutos() {
        return minutos;
    }

    public void setMinutos(String minutos) {
        this.minutos = minutos;
    }

    @Override
    public String toString() {
        return hora + ":" + minutos;
    }
}
