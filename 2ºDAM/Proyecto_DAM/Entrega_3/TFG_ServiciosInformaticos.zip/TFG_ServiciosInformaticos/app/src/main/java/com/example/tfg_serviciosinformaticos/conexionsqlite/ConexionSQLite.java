package com.example.tfg_serviciosinformaticos.conexionsqlite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.tfg_serviciosinformaticos.iniciarsesion.ActivityAlClicarInicioSesion_1;

public class ConexionSQLite extends SQLiteOpenHelper {
    //en esta clase, se crea la consulta string, donde se crea la tabla y las variables
    static final String nombreBaseDatos="informacionInicial.db";
    final String tablaInfo="CREATE TABLE tablaInfo (direccionCorreo TEXT, nombreUsuario TEXT, contrasena TEXT, nombre TEXT, apellidos TEXT, direccion TEXT, tipoUsuario TEXT)";
    //final String tablaCrearCuenta ="CREATE TABLE tablaCrearCuenta (direccionCorreo TEXT, nombreUsuario TEXT, contrasena TEXT)";
    //final String tablaDatosPersonales="CREATE TABLE tablaDatosPersonales (nombre TEXT, apellidos TEXT, direccion TEXT)";
    public ConexionSQLite(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, nombreBaseDatos, factory, version);
    }
    //en el siguiente metodo onCreate, se ejecuta la consulta SQL creada antes
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(tablaInfo);
        //db.execSQL(tablaCrearCuenta);
        //db.execSQL(tablaDatosPersonales);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists tablaInfo");
        //db.execSQL("drop Table if exists tablaCrearCuenta");
        //db.execSQL("drop Table if exists tablaDatosPersonales");
        onCreate(db);
    }

    public boolean insertarDatosInfo(String direccionCorreo, String usuario, String password, String nombre, String apellidos, String direccion, String tipoUsuario){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("direccionCorreo",direccionCorreo);
        contentValues.put("nombreUsuario",usuario);
        contentValues.put("contrasena",password);
        contentValues.put("nombre",nombre);
        contentValues.put("apellidos",apellidos);
        contentValues.put("direccion",direccion);
        contentValues.put("tipoUsuario",tipoUsuario);
        long result=db.insert("tablaInfo",null,contentValues);
        if(result==-1)return false;
        else
            return true;
    }

    /*public boolean insertarDatosCrearCuenta(String direccionCorreo, String usuario, String password){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("direccionCorreo",direccionCorreo);
        contentValues.put("nombreUsuario",usuario);
        contentValues.put("contrasena",password);
        long result=db.insert("tablaCrearCuenta",null,contentValues);
        if(result==-1)return false;
        else
            return true;
    }
    public boolean insertarDatosDatosPersonales(String nombre, String apellidos, String direccion){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("nombre",nombre);
        contentValues.put("apellidos",apellidos);
        contentValues.put("direccion",direccion);
        long result=db.insert("tablaDatosPersonales",null,contentValues);
        if(result==-1)return false;
        else
            return true;
    }*/
    public boolean checkUsername(String usuario){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery("select * from tablaInfo where nombreUsuario=?",new String[]{usuario});
        if(cursor.getCount()>0){
            return true;
        }else{
            return false;
        }
    }
    public boolean checkUsernamePassword(String usuario, String contrasena){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery("select * from tablaInfo where nombreUsuario=? and contrasena=?",new String[]{usuario, contrasena});
        if(cursor.getCount()>0){
            return true;
        }else{
            return false;
        }
    }

    @SuppressLint("Range")
    public String checkClienteProfesional(String usuario, String tipoUsuario){
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery("select tipoUsuario from tablaInfo where nombreUsuario='"+usuario+"'",new String[]{});
        String resultadoCursor=null;
        while(cursor.moveToNext()){
            resultadoCursor=cursor.getString(cursor.getColumnIndex("tipoUsuario"));
        }
        Log.d("TAGG","EL CURSOR VALE "+resultadoCursor);
        String a= null;
        if(resultadoCursor.equalsIgnoreCase("Cliente")){
            a="Cliente";
            return a;
        }else if(resultadoCursor.equalsIgnoreCase("Profesional")){
            a="Profesional";
            return a;
        }
        return a;
    }

}
