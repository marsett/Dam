package com.example.tfg_serviciosinformaticos.buscarservicio;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tfg_serviciosinformaticos.R;

import java.util.ArrayList;
import java.util.List;

public class ActivityBuscarServicio extends AppCompatActivity implements RecyclerAdapter.RecyclerItemClick, SearchView.OnQueryTextListener {
    private RecyclerView rvLista;
    private SearchView svSearch;
    private RecyclerAdapter adapter;
    private List<ItemList> items;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_buscarservicio);

        initViews();
        initValues();
        initListener();
    }

    private void initViews(){
        rvLista=findViewById(R.id.rvLista);
        svSearch=findViewById(R.id.svSearch);
    }

    private void initValues(){
        LinearLayoutManager manager=new LinearLayoutManager(this);
        rvLista.setLayoutManager(manager);

        items=getItems();
        adapter=new RecyclerAdapter(items, this);
        rvLista.setAdapter(adapter);
    }

    private void initListener(){
        svSearch.setOnQueryTextListener(this);
    }

    private List<ItemList> getItems(){
        List<ItemList> itemLists=new ArrayList<>();
        itemLists.add(new ItemList("Técnico DAM","Profesional licenciado en el desarrollo de aplicaciones multiplataforma.",R.drawable.dam));
        itemLists.add(new ItemList("Técnico DAW","Profesional licenciado en el desarrollo de aplicaciones web.",R.drawable.daw));
        itemLists.add(new ItemList("Técnico ASIR","Profesional licenciado en la administración y mantenimiento de sistemas informáticos en red.",R.drawable.asir));
        itemLists.add(new ItemList("Technical Consultant","Experto en tecnologías e infraestructuras IT como ServiceNow, normalmente desarrolladas por la empresa consultora que las utilice.",R.drawable.technicalconsultant));
        itemLists.add(new ItemList("Developer junior JAVA","Desarrollador junior en el lenguaje de programación JAVA.",R.drawable.java));
        itemLists.add(new ItemList("Diseñador de páginas web","Experto en el ámbito del desarrollo de interfaces web.",R.drawable.web));
        itemLists.add(new ItemList("Técnico multimedia","Profesional acostumbrado a trabajar con productos que mezclan texto, sonido, gráficos, vídeo digital, música e imágenes.",R.drawable.multimedia));
        itemLists.add(new ItemList("Scrum Master","Líder en proyectos dentro de un equipo de trabajo.",R.drawable.scrum));
        itemLists.add(new ItemList("Diseñador de Videojuegos","Experto en la mecánica de juegos innovadores y la representación de papeles, guiones y biografías de personajes.",R.drawable.game));
        itemLists.add(new ItemList("Montador de Ordenadores","Experto en hardware y su montaje.",R.drawable.pc));
        itemLists.add(new ItemList("Administrador de redes informáticas","Supervisor de sistemas informáticos y redes de bases de datos dentro de una organización.",R.drawable.network));
        itemLists.add(new ItemList("Técnico en Telecomunicaciones","Experto en instalación, prueba y reparación de aparatos que funcionan con tecnología de telecomunicaciones.",R.drawable.teleco));
        itemLists.add(new ItemList("Analista de sistemas informáticos","Profesional que utiliza las TIC para ayudar a las empresas a trabajar de forma más rápida y eficiente.",R.drawable.analyst));
        itemLists.add(new ItemList("Gerente de ventas de material informático","Profesional en el ámbito de la venta y soporte de material informático.",R.drawable.sales));
        itemLists.add(new ItemList("Ingeniero informático de hardware","Licenciado en el trabajo del diseño, desarrollo y fabricación de equipos informáticos.",R.drawable.engineer));
        itemLists.add(new ItemList("Administrador de bases de datos","Experto en el uso y manejo de bases de datos.",R.drawable.database));
        itemLists.add(new ItemList("Instalador y reparador en tecnologías TIC","Experto en el soporte y arreglo de elementos dentro de las TIC.",R.drawable.tic));
        itemLists.add(new ItemList("Especialista en Ciberseguridad","Profesional encargado de la privacidad y seguridad informática de una empresa u organización.",R.drawable.ciber));
        itemLists.add(new ItemList("Cloud engineer","Ingeniero encargado de supervisar la gestión de los procesos basados en la nube existentes y la migración digital.",R.drawable.cloud));
        itemLists.add(new ItemList("Especialista en Inteligencia Artificial","Encargado de realizar las mejoras operativas basadas en el aprendizaje automático y desarrollar nuevos procesos, objetos o servicios para solucionar problemas.",R.drawable.ia));
        itemLists.add(new ItemList("Data Scientist","Profesional que aplica sobre bases de datos sus conocimientos en programación, matemáticas y estadística para recopilar, extraer y procesar información relevante que contienen.",R.drawable.scientist));
        itemLists.add(new ItemList("Data Architect","Profesional que se encarga de plantear la estrategia de datos de la empresa en la que trabaja, influyendo sus estándares de calidad, el tratamiento del flujo de datos dentro de la organización y la seguridad de los mismos.",R.drawable.architect));
        itemLists.add(new ItemList("Data Analyst","Profesional que extrae, procesa y analiza grandes cantidades de datos que marcarán la gestión estratégica de la empresa.",R.drawable.danalyst));
        itemLists.add(new ItemList("Gestor de proyectos de I+D","Coordinador de todas las actividades relacionadas con el desarrollo de nuevos productos, procesos o tecnologías en una empresa.",R.drawable.imasd));
        return itemLists;
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        adapter.filter(newText);
        return false;
    }

    @Override
    public void itemClick(ItemList item) {
        Intent intent=new Intent(this, DetailActivity.class);
        intent.putExtra("itemDetail", item);
        startActivity(intent);
    }
}
