package com.example.tfg_serviciosinformaticos.buscarservicio;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg_serviciosinformaticos.R;

public class DetailActivity extends AppCompatActivity {
    private ImageView imgItemDetail;
    private TextView tvTituloDetail, tvDescripcionDetail;
    private ItemList itemDetail;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        setTitle(getClass().getSimpleName());

        initViews();
        initValues();
    }

    private void initViews(){
        imgItemDetail=(ImageView)findViewById(R.id.imgItemDetail);
        tvTituloDetail=(TextView)findViewById(R.id.tvTituloDetail);
        tvDescripcionDetail=(TextView)findViewById(R.id.tvDescripcionDetail);
    }

    private void initValues(){
        itemDetail= (ItemList) getIntent().getExtras().getSerializable("itemDetail");

        imgItemDetail.setImageResource(itemDetail.getImgResource());
        tvDescripcionDetail.setText(itemDetail.getTitulo());
        tvDescripcionDetail.setText(itemDetail.getDescripcion());
    }

}
