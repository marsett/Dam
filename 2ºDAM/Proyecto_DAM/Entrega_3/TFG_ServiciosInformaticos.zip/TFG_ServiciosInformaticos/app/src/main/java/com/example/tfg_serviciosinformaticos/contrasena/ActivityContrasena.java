package com.example.tfg_serviciosinformaticos.contrasena;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg_serviciosinformaticos.R;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class ActivityContrasena extends AppCompatActivity {
    private EditText etCorreoCredencial;
    private Button btCorreoCredencial;

    private static String emailFrom = "tfgserviciosinformaticos@gmail.com";
    private static String passwordFrom = "mcugqmivxacdzglq";//contraseña de aplicacion
    private String emailTo;
    private String subject;
    private String content;

    private Properties mProperties;
    private Session mSession;
    private MimeMessage mCorreo;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contrasena);

        etCorreoCredencial=(EditText) findViewById(R.id.etCorreoCredencial);
        btCorreoCredencial=(Button)findViewById(R.id.btCorreoCredencial);

        btCorreoCredencial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                envioCorreos();
                createEmail();
                sendEmail();
            }
        });
    }

    private void envioCorreos(){
        mProperties=new Properties();
    }

    private void createEmail(){

        emailTo=etCorreoCredencial.getText().toString().trim();
        subject="Restablecer Contraseña";
        content="<h1>Este es el contenido que tendrá el correo</h1><br>Salto de línea ;)" +
                "<a href=\"http://www.tfgserviciosinformaticos.com/restablecercontrasena\" target=\"_blank\" style=\"\">Mi botón</a>";

        mProperties.put("mail.smtp.host", "smtp.gmail.com");
        mProperties.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        mProperties.setProperty("mail.smtp.starttls.enable", "true");
        mProperties.setProperty("mail.smtp.port", "587");
        mProperties.setProperty("mail.smtp.user",emailFrom);
        mProperties.setProperty("mail.smtp.ssl.protocols", "TLSv1.2");
        mProperties.setProperty("mail.smtp.auth", "true");


        mSession = Session.getDefaultInstance(mProperties);

        try {
            mCorreo = new MimeMessage(mSession);
            mCorreo.setFrom(new InternetAddress(emailFrom));
            mCorreo.setRecipient(Message.RecipientType.TO, new InternetAddress(emailTo));
            mCorreo.setSubject(subject);
            mCorreo.setText(content, "ISO-8859-1", "html");

        } catch (AddressException ex) {
            Logger.getLogger(ActivityContrasena.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(ActivityContrasena.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void sendEmail(){
        try {
            Transport mTransport = mSession.getTransport("smtp");
            Thread thread = new Thread(new Runnable() {

                @Override
                public void run() {
                    try  {
                        mTransport.connect(emailFrom, passwordFrom);
                        mTransport.sendMessage(mCorreo, mCorreo.getRecipients(Message.RecipientType.TO));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            thread.start();

            mTransport.close();

            Toast.makeText(ActivityContrasena.this,"Correo enviado",Toast.LENGTH_SHORT).show();
        } catch (NoSuchProviderException ex) {
            Logger.getLogger(ActivityContrasena.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(ActivityContrasena.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
