package com.example.tfg_serviciosinformaticos.detallesperfil;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg_serviciosinformaticos.R;

public class ActivityDetallesPerfil extends AppCompatActivity {
    private ImageButton imgFlechaAtras;
    private Button btEditar;
    private Bundle datos;
    private TextView tvDescripcionPerfilLineas;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detallesperfil);

        tvDescripcionPerfilLineas=(TextView)findViewById(R.id.tvDescripcionPerfilLineas);

        //a través del Bundle se recogen los datos del anterior activity
        datos=getIntent().getExtras();

        //String recInfoDescripcion=datos.getString("infoDescripcion");


        imgFlechaAtras=findViewById(R.id.imgFlechaAtras);
        imgFlechaAtras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        btEditar=(Button)findViewById(R.id.btEditar);
        btEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ActivityDetallesPerfil.this, ActivityEditarPerfil.class);
                int requestCode=1;//codigo de solicitud unico
                startActivityForResult(intent,requestCode);

                Intent resultIntent = new Intent();
                resultIntent.putExtra("datos", tvDescripcionPerfilLineas.getText().toString());
                setResult(Activity.RESULT_OK, resultIntent);
                finish();

            }
        });

        preferences= getSharedPreferences("sesiones", Context.MODE_PRIVATE);
        editor=preferences.edit();

        String textoDescripcion = preferences.getString("textoDescripcion", null);
        if (textoDescripcion != null) {
            tvDescripcionPerfilLineas.setText(textoDescripcion);
        }

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            String informacion = data.getStringExtra("data");
            tvDescripcionPerfilLineas.setText(informacion);
            editor.putString("textoDescripcion", informacion);
        }
    }
}
