package com.example.tfg_serviciosinformaticos.detallesperfil;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg_serviciosinformaticos.R;

import java.io.File;

public class ActivityEditarPerfil extends AppCompatActivity {
    private ImageView fotoPerfil;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    File f;
    private EditText etDescripcionPerfil;
    private Button btGuardar;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editarperfil);

        preferences= getSharedPreferences("sesiones", Context.MODE_PRIVATE);
        editor=preferences.edit();

        fotoPerfil=findViewById(R.id.imgFotoPerfil);

        fotoPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dialogo1 = new AlertDialog.Builder(ActivityEditarPerfil.this);
                dialogo1.setTitle("Cambiar Foto de Perfil");
                dialogo1.setMessage("Elija una foto de su Galería");
                dialogo1.setCancelable(false);
                dialogo1.setPositiveButton("Galería", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogo1, int id) {
                        cargarImagen();
                        aceptar();
                    }
                });
                dialogo1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogo1, int id) {
                        cancelar();
                    }
                });
                dialogo1.show();
            }

            public void aceptar() {
                Toast.makeText(ActivityEditarPerfil.this,"Se ha cargado la imagen", Toast.LENGTH_SHORT).show();
            }

            public void cancelar() {}
        });


        etDescripcionPerfil=(EditText)findViewById(R.id.etDescripcionPerfil);

        String imagePath = preferences.getString("imagePath", null);
        if (imagePath != null) {
            // Cargar la imagen en el ImageView utilizando la ruta almacenada en SharedPreferences
            fotoPerfil.setImageURI(Uri.parse(imagePath));
            fotoPerfil.invalidate();
        }

        String textoDescripcion = preferences.getString("textoDescripcionEP", null);
        if (textoDescripcion != null) {
            etDescripcionPerfil.setText(textoDescripcion);
        }



        btGuardar=(Button)findViewById(R.id.btGuardarPerfil);
        btGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("data", etDescripcionPerfil.getText().toString());
                setResult(Activity.RESULT_OK, resultIntent);
                finish();

                Intent intent = new Intent(ActivityEditarPerfil.this, ActivityDetallesPerfil.class);
                int requestCode = 1; // código de solicitud único
                startActivityForResult(intent, requestCode);
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK){
            Uri imageUri=data.getData();
            final String realPath=getRealPathFromURI(imageUri);
            Log.d("TAGG",realPath);
            editor.putString("imagePath",realPath);
            editor.apply();
            this.f=new File(realPath);
            fotoPerfil.invalidate();
            fotoPerfil.setImageURI(imageUri);

            String informacion = data.getStringExtra("data");
            editor.putString("textoDescripcionEP", informacion);
        }
    }








    private void cargarImagen(){
        fotoPerfil.invalidate();
        Intent intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/");
        startActivityForResult(Intent.createChooser(intent,"Seleccione la Aplicación"),10);
    }

    private String getRealPathFromURI(Uri contentUri) {
        String result;
        Cursor cursor=getContentResolver().query(contentUri,null,null,null,null);
        if(cursor==null){
            result=contentUri.getPath();
        }else{
            cursor.moveToFirst();
            int idx=cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result=cursor.getString(idx);
            cursor.close();
        }
        return result;
    }
}
