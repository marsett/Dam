package com.example.tfg_serviciosinformaticos.B_crearcuenta;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg_serviciosinformaticos.R;
import com.example.tfg_serviciosinformaticos.conexionsqlite.ConexionSQLite;
import com.example.tfg_serviciosinformaticos.menunavigation.ActivityMenuBottomNavigationCliente;
import com.example.tfg_serviciosinformaticos.menunavigation.ActivityMenuBottomNavigationProfesional;

public class ActivityEleccionCuenta_3 extends AppCompatActivity {
    //se declaran las variables que se van a utilizar en la clase
    private Button btnCliente, btnProfesional;
    private Bundle datos;
    private ConexionSQLite db;
    private String cliente="Cliente";
    private String profesional="Profesional";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_cuentacreada_3);

        //se llama al método que vincula las variables
        vinculacionVariables();

        //se llama al siguiente método con el objetivo de obtener los datos que se han pasado entre componentes de la aplicación utilizando un objeto Bundle
        datos=getIntent().getExtras();

        //se recogen en variables String los datos del anterior activity
        String recCorreo=datos.getString("correo");
        String recUser=datos.getString("user");
        String recPassword=datos.getString("password");
        String recNombre=datos.getString("nombre");
        String recApellidos=datos.getString("apellidos");
        String recDireccion=datos.getString("direccion");

        //se inicializa la variable que llama al constructor de la clase ConexionSQLite, donde se crea y actualiza una base de datos SQLite
        db=new ConexionSQLite(this,"tablaInfo",null,1);

        //al clicar en el botón cliente, se hace lo que hay dentro del método
        btnCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cliente(recCorreo, recUser, recPassword, recNombre, recApellidos, recDireccion);
            }
        });

        //al clicar en el botón profesional, se hace lo que hay dentro del método
        btnProfesional.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profesional(recCorreo, recUser, recPassword, recNombre, recApellidos, recDireccion);
            }
        });
    }

    private void vinculacionVariables(){
        //se vincula cada elemento creado en la clase con su correspondiente en el layout
        btnCliente=(Button)findViewById(R.id.btnCliente);
        btnProfesional=(Button) findViewById(R.id.btnProfesional);
    }

    private void cliente(String recCorreo, String recUser,String recPassword, String recNombre, String recApellidos, String recDireccion){
        //se muestra un mensaje de aviso confirmando qué perfil se ha elegido
        Toast.makeText(ActivityEleccionCuenta_3.this,"Has elegido perfil Cliente",Toast.LENGTH_SHORT).show();

        //se muestra en una variable si, al llamar al método que comprueba la existencia de un usuario, existe el usuario pasado por parámetro
        boolean comprobarUser=db.checkUsername(recUser);

        //si no existe, se inserta dentro de la base de datos SQLite junto con los demás datos insertados
        if(comprobarUser==false) {
            //se insertan los datos en la base de datos, con el distintivo de que es un cliente
            boolean insert = db.insertarDatosInfo(recCorreo, recUser, recPassword, recNombre, recApellidos, recDireccion, cliente);

            //si esta inserción es correcta, mostrará un mensaje mostrando que la inserción fue un éxito y se mostrará la siguiente actividad
            if (insert == true) {
                Toast.makeText(ActivityEleccionCuenta_3.this, "Insercion Datos Info Correcta", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), ActivityMenuBottomNavigationCliente.class);
                startActivity(intent);
            }
            //si no se ha completado bien la inserción, saldrá un mensaje de avisando de que algo va mal
            else {
                Toast.makeText(ActivityEleccionCuenta_3.this, "Insercion Datos Info Fallida", Toast.LENGTH_SHORT).show();
            }

        }
        //si existiera el usuario que se ha puesto, saldrá un mensaje diciendo que ya existe el usuario y que se inicie sesión
        else{
            Toast.makeText(ActivityEleccionCuenta_3.this,"Este usuario ya existe: por favor, inicia sesión",Toast.LENGTH_SHORT).show();
        }
    }

    private void profesional(String recCorreo, String recUser,String recPassword, String recNombre, String recApellidos, String recDireccion){
        //se muestra un mensaje de aviso confirmando qué perfil se ha elegido
        Toast.makeText(ActivityEleccionCuenta_3.this,"Has elegido perfil Profesional",Toast.LENGTH_SHORT).show();

        //se muestra en una variable si, al llamar al método que comprueba la existencia de un usuario, existe el usuario pasado por parámetro
        boolean comprobarUser=db.checkUsername(recUser);

        //si no existe, se inserta dentro de la base de datos SQLite junto con los demás datos insertados
        if(comprobarUser==false) {
            //se insertan los datos en la base de datos, con el distintivo de que es un profesional
            boolean insert = db.insertarDatosInfo(recCorreo, recUser, recPassword, recNombre, recApellidos, recDireccion, profesional);

            //si esta inserción es correcta, mostrará un mensaje mostrando que la inserción fue un éxito y se mostrará la siguiente actividad
            if (insert == true) {
                Toast.makeText(ActivityEleccionCuenta_3.this, "Insercion Datos Info Correcta", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), ActivityMenuBottomNavigationProfesional.class);
                startActivity(intent);
            }
            //si no se ha completado bien la inserción, saldrá un mensaje de avisando de que algo va mal
            else {
                Toast.makeText(ActivityEleccionCuenta_3.this, "Insercion Datos Info Fallida", Toast.LENGTH_SHORT).show();
            }
        }
        //si existiera el usuario que se ha puesto, saldrá un mensaje diciendo que ya existe el usuario y que se inicie sesión
        else{
            Toast.makeText(ActivityEleccionCuenta_3.this,"Este usuario ya existe: por favor, inicia sesión",Toast.LENGTH_SHORT).show();
        }
    }

}
