package com.example.tfg_serviciosinformaticos.B_crearcuenta;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tfg_serviciosinformaticos.R;
import com.example.tfg_serviciosinformaticos.conexionsqlite.ConexionSQLite;
import com.example.tfg_serviciosinformaticos.iniciarsesion.ActivityAlClicarInicioSesion_1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CredencialesRedireccion extends AppCompatActivity {
    //se declaran las variables que se van a utilizar en la clase
    private EditText etDireccionCorreo, etNombreUsuario, etContrasenaCrearCuenta, etConfirmaContrasenaCrearCuenta;
    private Button btnCrearCuenta;
    private TextView tvRedirigirIniciarSesion;
    private ConexionSQLite db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.b_credencialesredireccion);

        //se llama al método que vincula las variables
        vinculacionVariables();

        //se inicializa la variable que llama al constructor de la clase ConexionSQLite, donde se crea y actualiza una base de datos SQLite
        db=new ConexionSQLite(this,"tablaInfo",null,1);

        //al clicar en el botón de crear cuenta, se hace lo que hay dentro del método
        btnCrearCuenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                crearCuenta();
            }
        });

        //al clicar en el TextView indicado, se hace lo que hay dentro del método
        tvRedirigirIniciarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                redirigirIniciarSesion();
            }
        });
    }

    private void vinculacionVariables(){
        //se vincula cada elemento creado en la clase con su correspondiente en el layout
        etDireccionCorreo =(EditText)findViewById(R.id.etDireccionCorreoCrearCuenta);
        etNombreUsuario =(EditText)findViewById(R.id.etUsuarioCrearCuenta);
        etContrasenaCrearCuenta =(EditText)findViewById(R.id.etContrasenaCrearCuenta);
        etConfirmaContrasenaCrearCuenta =(EditText)findViewById(R.id.etConfirmaContrasenaCrearCuenta);
        btnCrearCuenta =(Button)findViewById(R.id.btnCrearCuenta);
        tvRedirigirIniciarSesion=(TextView)findViewById(R.id.tvRedirigirIniciarSesion);
    }

    @SuppressLint("Range")
    private void crearCuenta(){
        //se crean variables donde se almacena la información insertada en los distintos EditText
        String direccionCorreo= etDireccionCorreo.getText().toString();

        if (!direccionCorreo.endsWith("@gmail.com")) {
            if (direccionCorreo.contains("@")) {
                Toast.makeText(this, "El correo debe terminar en @gmail.com. Lo sentimos", Toast.LENGTH_SHORT).show();
                return; // detener la ejecución si el correo no es válido
            }
            direccionCorreo += "@gmail.com"; // añadir la cadena si no se ha insertado ya
            etDireccionCorreo.setText(direccionCorreo); // actualizar el texto en el EditText
        }

        String nombreUsuario= etNombreUsuario.getText().toString();

        String contrasenaCrearCuenta= etContrasenaCrearCuenta.getText().toString();

        String confirmaContrasenaCrearCuenta= etConfirmaContrasenaCrearCuenta.getText().toString();

        //se crea un condicional donde, si cualquier EditText está vacío, se impida avanzar a la siguiente atividad
        //se ha hecho esto con el propósito de que todos los campos tengan la información que se pide
        //mostraría entonces un mensaje de aviso para rellenar todos los campos
        if(direccionCorreo.equals("")||nombreUsuario.equals("")||contrasenaCrearCuenta.equals("")||confirmaContrasenaCrearCuenta.equals("")){
            Toast.makeText(CredencialesRedireccion.this,"Rellena todos los campos, por favor",Toast.LENGTH_SHORT).show();
        }
        //si están todos los campos rellenos, se debe cumplir otro condicional más
        else{
            //si el campo contraseña y el campo para confirmar contraseña son iguales, se crea un Intent que lleva a la siguiente actividad
            //además, se llevan los datos insertados en los campos a través de este mismo Intent
            if(contrasenaCrearCuenta.equals(confirmaContrasenaCrearCuenta)){

                SQLiteDatabase sqldb=db.getReadableDatabase();

                // Verificar si el correo existe en la base de datos
                Cursor cursorCorreo = sqldb.rawQuery("SELECT * FROM tablaInfo WHERE direccionCorreo = ?", new String[]{direccionCorreo});
                boolean existeCorreo = cursorCorreo.moveToFirst();
                cursorCorreo.close();

// Verificar si el usuario existe en la base de datos
                Cursor cursorUsuario = sqldb.rawQuery("SELECT * FROM tablaInfo WHERE nombreUsuario = ?", new String[]{nombreUsuario});
                boolean existeUsuario = cursorUsuario.moveToFirst();
                cursorUsuario.close();

                if (existeCorreo && existeUsuario) {
                    // Ambos existen en la base de datos
                    Toast.makeText(this, "El correo y el usuario ya están vinculados a la aplicación", Toast.LENGTH_SHORT).show();
                } else if (existeCorreo) {
                    // El correo existe, pero el usuario no
                    Toast.makeText(this, "El correo ya está vinculado a la aplicación", Toast.LENGTH_SHORT).show();
                } else if (existeUsuario) {
                    // El usuario existe, pero el correo no
                    Toast.makeText(this, "El usuario ya está vinculado a la aplicación", Toast.LENGTH_SHORT).show();
                } else {
                    // No se encontró ningún registro, se puede agregar el nuevo registro a la base de datos
                    Intent intent = new Intent(CredencialesRedireccion.this, DatosPersonales.class);
                    intent.putExtra("correo", direccionCorreo);
                    intent.putExtra("user", nombreUsuario);
                    intent.putExtra("password", contrasenaCrearCuenta);
                    startActivity(intent);
                }




            }
            //si no son iguales las contraseñas puestas, mostrará un mensaje de aviso para que se pongan bien
            else{
                Toast.makeText(CredencialesRedireccion.this,"Las contraseñas no concuerdan",Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void redirigirIniciarSesion(){
        //este método tiene como objetivo redirigir a la actividad de inicio de sesión con un Intent
        //esto se ha puesto ya que muchas veces los usuarios se equivocan al navegar en la app
        //por lo que se ha puesto este atajo para que lo puedan usar
        Intent intent=new Intent(CredencialesRedireccion.this, ActivityAlClicarInicioSesion_1.class);
        startActivity(intent);
    }

    public enum PasswordStrength {
        WEAK,
        MEDIUM,
        STRONG
    }

    public PasswordStrength getPasswordStrength(String password) {
        if (password.length() < 8) {
            return PasswordStrength.WEAK;
        }

        boolean hasLowercase = false;
        boolean hasUppercase = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isLowerCase(c)) {
                hasLowercase = true;
            } else if (Character.isUpperCase(c)) {
                hasUppercase = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isWhitespace(c)) {
                hasSpecial = true;
            }
        }

        if (hasLowercase && hasUppercase && hasNumber && hasSpecial) {
            return PasswordStrength.STRONG;
        } else if ((hasLowercase || hasUppercase) && hasNumber && hasSpecial) {
            return PasswordStrength.MEDIUM;
        } else {
            return PasswordStrength.WEAK;
        }
    }

}