package com.example.tfg_serviciosinformaticos.menunavigation;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.tfg_serviciosinformaticos.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class ActivityMenuBottomNavigationCliente extends AppCompatActivity {
    FirstFragment firstFragment=new FirstFragment();
    SecondFragment secondFragment=new SecondFragment();
    ThirdFragment thirdFragment=new ThirdFragment();
    FourthFragment fourthFragment=new FourthFragment();
    FifthFragment fifthFragment=new FifthFragment();

    /*SharedPreferences preferences;
    SharedPreferences.Editor editor;*/

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_pantalla_bottomnavigation_cliente);
        BottomNavigationView navigation=findViewById(R.id.bottom_navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        /*preferences=this.getSharedPreferences("sesiones",Context.MODE_PRIVATE);
        editor=preferences.edit();*/

        loadFragment(firstFragment);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
    }
    private final BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener=new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.firstFragment:
                        loadFragment(firstFragment);
                        return true;
                    case R.id.secondFragment:
                        loadFragment(secondFragment);
                        return true;
                    case R.id.thirdFragment:
                        loadFragment(thirdFragment);
                        return true;
                    case R.id.fourthFragment:
                        loadFragment(fourthFragment);
                        return true;
                    case R.id.fifthFragment:
                        loadFragment(fifthFragment);
                        return true;
                }
            return false;
        }
    };

    public void loadFragment(Fragment fragment){
        FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container,fragment);
        transaction.commit();
    }

    @Override
    public void onBackPressed() {//super.onBackPressed();
    }

}
