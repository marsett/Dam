package com.example.tfg_serviciosinformaticos.frecuencia;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg_serviciosinformaticos.R;

import java.util.Calendar;

public class ActivityRecurrente extends AppCompatActivity {
    private CalendarView cal;
    private Button botonHora, botonSiguiente;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_recurrente);

        cal=(CalendarView)findViewById(R.id.calendar);
        botonHora=(Button)findViewById(R.id.botonHora);
        botonSiguiente=(Button)findViewById(R.id.botonSiguiente);
        cal.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String fecha=dayOfMonth+"/"+month+"/"+year;
                Toast.makeText(ActivityRecurrente.this,fecha,Toast.LENGTH_SHORT).show();
            }
        });
        botonHora.setOnClickListener(new View.OnClickListener() {
            Calendar c=Calendar.getInstance();
            int hora=c.get(Calendar.HOUR_OF_DAY);
            int min=c.get(Calendar.MINUTE);
            @Override
            public void onClick(View v) {
                TimePickerDialog tmd=new TimePickerDialog(ActivityRecurrente.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        Toast.makeText(ActivityRecurrente.this,hourOfDay+":"+minute,Toast.LENGTH_SHORT).show();
                    }
                },hora,min,false);
                tmd.show();
            }
        });
        botonSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ActivityRecurrente.this, ActivityRListView.class);
                startActivity(intent);
            }
        });
    }






















}
