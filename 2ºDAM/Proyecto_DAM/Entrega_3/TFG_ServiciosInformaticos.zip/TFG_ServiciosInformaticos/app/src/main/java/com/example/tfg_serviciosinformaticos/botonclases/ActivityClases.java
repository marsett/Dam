package com.example.tfg_serviciosinformaticos.botonclases;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg_serviciosinformaticos.R;
import com.example.tfg_serviciosinformaticos.frecuencia.ActivityRecurrente;
import com.example.tfg_serviciosinformaticos.frecuencia.ActivitySemanal;

public class ActivityClases extends AppCompatActivity {
    private Button botonAccesoDatos, botonServiciosProcesos, botonSistemasGestionEmpresarial,
            botonBasesDatos, botonSistemasInformaticos, botonLenguajesMarcas, botonDesarrolloInterfaces,
            botonProgramacionMultimedia;
    private CheckBox cbRecurrente, cbSemanal;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_botonclases);

        botonAccesoDatos=(Button)findViewById(R.id.botonAccesoDatos);
        botonServiciosProcesos=(Button)findViewById(R.id.botonServiciosProcesos);
        botonSistemasGestionEmpresarial=(Button)findViewById(R.id.botonSistemasGestionEmpresarial);
        botonBasesDatos=(Button)findViewById(R.id.botonBaseDatos);
        botonSistemasInformaticos=(Button)findViewById(R.id.botonSistemasInformaticos);
        botonLenguajesMarcas=(Button)findViewById(R.id.botonLenguajesMarcas);
        botonDesarrolloInterfaces=(Button)findViewById(R.id.botonDesarrolloInterfaces);
        botonProgramacionMultimedia=(Button)findViewById(R.id.botonProgramacionMultimedia);
        cbRecurrente=(CheckBox)findViewById(R.id.cbRecurrente);
        cbSemanal=(CheckBox)findViewById(R.id.cbSemanal);

        botonAccesoDatos.setOnClickListener(new View.OnClickListener() {
            boolean marcado;
            @Override
            public void onClick(View v) {
                checkMarcados();
                if(cbRecurrente.isChecked()&&!cbSemanal.isChecked()){
                    marcado=true;
                    Intent intent=new Intent(ActivityClases.this, ActivityRecurrente.class);
                    intent.putExtra("marcadoR",marcado);
                    startActivity(intent);
                }else if(cbSemanal.isChecked()&&!cbRecurrente.isChecked()){
                    marcado=false;
                    Intent intent=new Intent(ActivityClases.this, ActivitySemanal.class);
                    intent.putExtra("marcadoS",marcado);
                    startActivity(intent);
                }
            }
        });

    }
    public void checkMarcados(){
        if(!cbRecurrente.isChecked()&&!cbSemanal.isChecked()){
            Toast.makeText(ActivityClases.this,"Debes marcar una sola casilla",Toast.LENGTH_SHORT).show();
        }else if(cbRecurrente.isChecked()&&cbSemanal.isChecked()){
            Toast.makeText(ActivityClases.this,"Sólo puedes marcar una casilla",Toast.LENGTH_SHORT).show();
        }
    }
}
