package com.example.tfg_serviciosinformaticos.menunavigation;

import static android.app.Activity.RESULT_OK;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tfg_serviciosinformaticos.R;
import com.example.tfg_serviciosinformaticos.detallesperfil.ActivityDetallesPerfil;

import java.io.File;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FifthFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FifthFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public FifthFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FifthFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static FifthFragment newInstance(String param1, String param2) {
        FifthFragment fragment = new FifthFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    private Button btCerrarSesion;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    private ImageView fotoPerfil;
    final int GALLERY_REQUEST_CODE=200;
    File f;
    TextView tvMiPerfil;

    private void cargarImagen(){
        fotoPerfil.invalidate();
        Intent intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/");
        startActivityForResult(Intent.createChooser(intent,"Seleccione la Aplicación"),10);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK){
            Uri imageUri=data.getData();
            final String realPath=getRealPathFromURI(imageUri);
            Log.d("TAGG",realPath);
            editor.putString("imagePath",realPath);
            editor.apply();
            this.f=new File(realPath);
            fotoPerfil.invalidate();
            fotoPerfil.setImageURI(imageUri);
        }
    }

    private String getRealPathFromURI(Uri contentUri) {
        String result;
        Cursor cursor=getContext().getContentResolver().query(contentUri,null,null,null,null);
        if(cursor==null){
            result=contentUri.getPath();
        }else{
            cursor.moveToFirst();
            int idx=cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result=cursor.getString(idx);
            cursor.close();
        }
        return result;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root=inflater.inflate(R.layout.fragment_fifth, container, false);

        preferences= getContext().getSharedPreferences("sesiones", Context.MODE_PRIVATE);
        editor=preferences.edit();
        btCerrarSesion=root.findViewById(R.id.btCerrarSesion);
        btCerrarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putBoolean("sesion",false);
                editor.apply();
                Toast.makeText(getActivity(),"la sesion ",Toast.LENGTH_SHORT).show();
            }
        });
        fotoPerfil=root.findViewById(R.id.imgFotoPerfil);

        String imagePath = preferences.getString("imagePath", null);
        if (imagePath != null) {
            // Cargar la imagen en el ImageView utilizando la ruta almacenada en SharedPreferences
            fotoPerfil.invalidate();
            fotoPerfil.setImageURI(Uri.parse(imagePath));

        }
            fotoPerfil.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder dialogo1 = new AlertDialog.Builder(getContext());
                    dialogo1.setTitle("Cambiar Foto de Perfil");
                    dialogo1.setMessage("Elija una foto de su Galería");
                    dialogo1.setCancelable(false);
                    dialogo1.setPositiveButton("Galería", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogo1, int id) {
                            cargarImagen();
                            aceptar();
                        }
                    });
                    dialogo1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogo1, int id) {
                            cancelar();
                        }
                    });
                    dialogo1.show();
                    }

                    public void aceptar() {
                        Toast.makeText(getActivity(),"Se ha aceptado el diálogo", Toast.LENGTH_SHORT).show();
                    }

                    public void cancelar() {
                        Toast.makeText(getActivity(),"Se ha cancelado el diálogo", Toast.LENGTH_SHORT).show();
                    }
            });

        tvMiPerfil=root.findViewById(R.id.tvMiPerfil);
        tvMiPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(), ActivityDetallesPerfil.class);
                startActivity(intent);
            }
        });

        return root;

    }

}