package com.example.tfg_serviciosinformaticos.B_crearcuenta;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tfg_serviciosinformaticos.R;
import com.example.tfg_serviciosinformaticos.conexionsqlite.ConexionSQLite;

public class DatosPersonales extends AppCompatActivity {
    //se declaran las variables que se van a utilizar en la clase
    private TextView tvDatosPersonales;
    private EditText etNombre, etApellidos, etDireccion;
    private Button btnSiguiente;
    private ConexionSQLite db;
    private Bundle datos;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.b_datospersonales);

        //se llama al método que vincula las variables
        vinculacionVariables();

        //db=new ConexionSQLite(this,"tablaDatosPersonales",null,1);

        etDireccion.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    etDireccion.setHint("por ejemplo, c/Fuentearcos, 27");
                } else {
                    etDireccion.setHint("");
                }
            }
        });

        //la clase Bundle sirve para pasar datos entre actividades, fragmentos y servicios
        //se llama al siguiente método con el objetivo de obtener los datos que se han pasado entre componentes de la aplicación utilizando un objeto Bundle
        datos=getIntent().getExtras();

        //al clicar en el botón siguiente, se hace lo que hay dentro del método
        btnSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                siguiente();
            }
        });
    }

    private void vinculacionVariables(){
        //se vincula cada elemento creado en la clase con su correspondiente en el layout
        tvDatosPersonales=(TextView)findViewById(R.id.tvDatosPersonales);
        etNombre=(EditText)findViewById(R.id.etNombre);
        etApellidos=(EditText)findViewById(R.id.etApellidos);
        etDireccion=(EditText)findViewById(R.id.etDireccion);
        btnSiguiente=(Button)findViewById(R.id.btnSiguiente);
    }

    private void siguiente(){
        //se recogen en variables String los datos del anterior activity
        String recCorreo=datos.getString("correo");
        String recUser=datos.getString("user");
        String recPassword=datos.getString("password");

        //se recogen en variables String lo insertado en los campos hasta clicar el botón
        String nombre=etNombre.getText().toString();
        String apellidos=etApellidos.getText().toString();
        String direccion=etDireccion.getText().toString();

        //al igual que en el anterior activity, hay un condicional que obliga rellenar todos los campos
        //si está vaccío cualquiera de ellos o, en su defecto todos, mostrará un mensaje de aviso
        if(nombre.equals("")||apellidos.equals("")||direccion.equals("")){
            Toast.makeText(DatosPersonales.this,"Rellena todos los campos",Toast.LENGTH_SHORT).show();
        }
        //si está todo relleno, se accede al siguiente activity, pasando la información de esta actividad a través del método putExtra()
        else{
            Intent intent=new Intent(DatosPersonales.this, ActivityEleccionCuenta_3.class);
            intent.putExtra("correo",recCorreo);
            intent.putExtra("user",recUser);
            intent.putExtra("password",recPassword);
            intent.putExtra("nombre",nombre);
            intent.putExtra("apellidos",apellidos);
            intent.putExtra("direccion",direccion);
            startActivity(intent);
        }
    }

}
