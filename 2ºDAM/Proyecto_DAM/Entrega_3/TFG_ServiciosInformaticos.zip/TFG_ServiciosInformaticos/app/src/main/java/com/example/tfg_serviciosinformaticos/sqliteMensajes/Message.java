package com.example.tfg_serviciosinformaticos.sqliteMensajes;

import java.util.Date;

public class Message {
    private String sender;
    private String senderImage;
    private String text;
    private Date timestamp;

    public Message(String sender, String senderImage, String text, Date timestamp) {
        this.sender = sender;
        this.senderImage = senderImage;
        this.text = text;
        this.timestamp = timestamp;
    }

    public String getSender() {
        return sender;
    }

    public String getSenderImage() {
        return senderImage;
    }

    public String getText() {
        return text;
    }

    public Date getTimestamp() {
        return timestamp;
    }
}
