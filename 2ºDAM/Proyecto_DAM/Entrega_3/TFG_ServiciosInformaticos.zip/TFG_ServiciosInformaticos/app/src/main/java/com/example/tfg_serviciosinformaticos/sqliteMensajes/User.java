package com.example.tfg_serviciosinformaticos.sqliteMensajes;

public class User {
    private int id;
    private String name;
    private String lastMessage;

    public User(String name, String lastMessage) {
        this.name = name;
        this.lastMessage = lastMessage;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getLastMessage() {
        return lastMessage;
    }
}
