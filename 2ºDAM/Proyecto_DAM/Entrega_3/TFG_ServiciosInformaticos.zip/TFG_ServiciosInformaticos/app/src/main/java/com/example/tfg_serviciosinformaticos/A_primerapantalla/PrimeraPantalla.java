package com.example.tfg_serviciosinformaticos.A_primerapantalla;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.tfg_serviciosinformaticos.R;
import com.example.tfg_serviciosinformaticos.B_crearcuenta.CredencialesRedireccion;
import com.example.tfg_serviciosinformaticos.iniciarsesion.ActivityAlClicarInicioSesion_1;

public class PrimeraPantalla extends AppCompatActivity {
    //se declaran las variables que se van a utilizar en la clase
    private ImageView imgvLogoSI;
    private Button btnIniciarSesion, btnCrearCuenta;
    private final int REQUEST_CODE=200;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_primerapantalla);

        //se llama a los métodos que vinculan las variables
        //y los que verifican los permisos de la aplicación
        vinculacionVariables();
        verificarPermisos();

        //se establece un ImageView con el logo de la aplicación
        imgvLogoSI.setImageResource(R.drawable.imagenicono);

        //al clicar en el botón de inicio de sesión, se hace lo que hay dentro del método
        btnIniciarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarSesion();
            }
        });

        //al clicar en el botón de creación de cuenta, se hace lo que hay dentro del método
        btnCrearCuenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                crearCuenta();
            }
        });
    }

    private void vinculacionVariables(){
        //se vincula cada elemento creado en la clase con su correspondiente en el layout
        imgvLogoSI =(ImageView)findViewById(R.id.imgvLogoSI);
        btnIniciarSesion =(Button)findViewById(R.id.btnIniciarSesion);
        btnCrearCuenta =(Button)findViewById(R.id.btnCrearCuenta);
    }

    private void iniciarSesion(){
        //se crea un Intent, el cual llevará a la clase que inicia sesión
        Intent intent=new Intent(PrimeraPantalla.this, ActivityAlClicarInicioSesion_1.class);
        startActivity(intent);

        //se muestra un mensaje mostrando que todo se ha realizado correctamente
        Toast.makeText(this,"Acceso a Inicio de Sesión con éxito",Toast.LENGTH_SHORT).show();
    }

    private void crearCuenta(){
        //se crea un Intent, el cual llevará a la clase que crea la cuenta
        Intent intent=new Intent(PrimeraPantalla.this, CredencialesRedireccion.class);
        startActivity(intent);

        //se muestra un mensaje mostrando que todo se ha realizado correctamente
        Toast.makeText(this,"Acceso a Creación de Cuenta con éxito",Toast.LENGTH_SHORT).show();
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void verificarPermisos(){
        //se crean dos variables enteras que determinan si se han dado los permisos
        //en la primera variable se determina si se ha establecido el permiso para acceder al contenido de almacenamiento externo del dispositivo
        int permisosLecturaAlmacenamientoExterno=ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);

        //en la segunda variable se determina si se ha establecido el permiso para escribir en el almacenamiento externo
        int permisosEscrituraAlmacenamientoExterno=ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        //en el siguiente condicional se comparan si las dos anteriores variables son iguales a la constante PackageManager.PERMISSION_GRANTED
        //esta constante es un valor entero que indica que un permiso ha sido otorgado por el usuario en tiempo de ejecución
        //si se cumple la condición, se mostrará un mensaje diciendo que se han concedido los permisos
        if(permisosLecturaAlmacenamientoExterno==PackageManager.PERMISSION_GRANTED && permisosEscrituraAlmacenamientoExterno==PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this,"Permisos Galería concedidos",Toast.LENGTH_SHORT).show();
        }
        //si no se cumple la condición,se solicitan los permisos a través de la llamada al método requestPermissions()
        //como argumentos se muestran los permisos que se desean conceder y una constante que sirve para identificar la solicitud de permiso en el método onRequestPermissionsResult() de la actividad o fragmento que solicitó los permisos
        //se mostraría entonces el cuadro de diálogo que permite conceder estos permisos
        else{
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE},REQUEST_CODE);
        }

    }

}