package com.example.tfg_serviciosinformaticos.iniciarsesion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tfg_serviciosinformaticos.R;
import com.example.tfg_serviciosinformaticos.conexionsqlite.ConexionSQLite;
import com.example.tfg_serviciosinformaticos.contrasena.ActivityContrasena;
import com.example.tfg_serviciosinformaticos.menunavigation.ActivityMenuBottomNavigationCliente;
import com.example.tfg_serviciosinformaticos.menunavigation.ActivityMenuBottomNavigationProfesional;

public class ActivityAlClicarInicioSesion_1 extends AppCompatActivity {
    EditText username, password;
    Button btnlogin;
    ConexionSQLite db;
    TextView tvRestablecerContrasena;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    CheckBox cbMantenerSesion;
    String llave="sesion";

    private void guardarSesion(boolean checked){
        editor.putBoolean(llave,checked);
        editor.apply();
    }
    private boolean revisarSesion(){
        return this.preferences.getBoolean(llave,false);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_alclicariniciosesion_1);

        username=(EditText) findViewById(R.id.etNombreUsuarioInicioSesion);
        password=(EditText) findViewById(R.id.etPasswordInicioSesion);
        btnlogin=(Button) findViewById(R.id.btIniciarSesion);
        db=new ConexionSQLite(this,"tablaInfo",null,1);
        tvRestablecerContrasena=(TextView) findViewById(R.id.tvRestablecerContrasena);
        preferences=this.getSharedPreferences("sesiones",Context.MODE_PRIVATE);
        editor=preferences.edit();
        cbMantenerSesion=(CheckBox)findViewById(R.id.cbMantenerSesion);

        if(revisarSesion()){
            startActivity(new Intent(this,ActivityMenuBottomNavigationCliente.class));
        }else{
            String mensaje="Iniciar Sesión";
            Toast.makeText(this,mensaje,Toast.LENGTH_SHORT).show();
        };

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarSesion(cbMantenerSesion.isChecked());
                String user=username.getText().toString();
                String pass=password.getText().toString();

                String tipoUsuario="Profesional";
                SQLiteDatabase sqld=db.getWritableDatabase();

                Cursor infoUsuarioContrasena=sqld.rawQuery("select nombreUsuario, contrasena from tablaInfo where nombreUsuario='"+user+"' and contrasena='"+pass+"'" ,new String[]{});
                String resultado1=null;
                String resultado2=null;

                while(infoUsuarioContrasena.moveToNext()){
                    resultado1=infoUsuarioContrasena.getString(0);
                    Log.d("TAGG","EL CURSOR 1 VALE -> "+resultado1);
                    resultado2=infoUsuarioContrasena.getString(1);
                }


                Log.d("TAGG","EL CURSOR 2 VALE -> "+resultado2);

                String usuario=resultado1;
                String contrasena=resultado2;

                if(user.equals(usuario)&&pass.equals(contrasena)){
                    Toast.makeText(ActivityAlClicarInicioSesion_1.this,"Usuario y Contraseña coinciden",Toast.LENGTH_SHORT).show();
                    if(user.equals("")||pass.equals("")){
                        Toast.makeText(ActivityAlClicarInicioSesion_1.this,"Rellena todos los campos",Toast.LENGTH_SHORT).show();
                    }else{
                        boolean checkuserpass=db.checkUsernamePassword(user,pass);
                        Cursor infoTipoUsuario=sqld.rawQuery("select tipoUsuario from tablaInfo where nombreUsuario='"+user+"' and contrasena='"+pass+"'" ,new String[]{});
                        String checkclienteprofesional=db.checkClienteProfesional(user, String.valueOf(infoTipoUsuario));
                        Log.d("","CHECK CLIENTE PROFESIONAL ES -> "+String.valueOf(checkclienteprofesional));

                        if(checkuserpass==true && checkclienteprofesional=="Cliente") {
                            Toast.makeText(ActivityAlClicarInicioSesion_1.this, "Inicio de Sesión exitoso Cliente", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), ActivityMenuBottomNavigationCliente.class);
                            startActivity(intent);
                        }else if(checkuserpass==true && checkclienteprofesional=="Profesional"){
                            Toast.makeText(ActivityAlClicarInicioSesion_1.this, "Inicio de Sesión exitoso Profesional", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), ActivityMenuBottomNavigationProfesional.class);
                            startActivity(intent);
                        }else{
                            Toast.makeText(ActivityAlClicarInicioSesion_1.this,"Contraseña incorrecta para este usuario",Toast.LENGTH_SHORT).show();
                        }
                    }
                }else{
                    Toast.makeText(ActivityAlClicarInicioSesion_1.this,"Usuario y/o contraseña incorrectos",Toast.LENGTH_SHORT).show();
                    Log.d("TAGG","Usuario y/o contrasena incorrectos");
                }
            }
        });
        tvRestablecerContrasena.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ActivityAlClicarInicioSesion_1.this, ActivityContrasena.class);
                startActivity(intent);
            }
        });
    }
}