package p1_1;
import java.io.*;
import java.util.*;

public class Archivo_Configuracion_Cantidad {
	public static void main(String[] args) throws FileNotFoundException, IOException{
		
		//Practica Acceso a Datos
		//El siguiente programa se lanza con el siguiente comando: java Archivo_Configuracion_Cantidad inventario.conf
		
		File f=new File("C:\\Users\\jimen\\Downloads\\"+args[0]);
		Properties configuracion = new Properties();
		
		configuracion.load(new FileInputStream(f));
		
		String clave=configuracion.getProperty("cantidad");
		int valor=Integer.parseInt(clave);
		valor++;
		clave=""+valor;
		
		configuracion.setProperty("cantidad", clave);
		configuracion.store(new FileOutputStream(f), "Fichero de cantidades (con la cantidad sumada en una unidad)");
		
		FileReader fr=new FileReader(f);
		int caract=fr.read();
		while(caract!=-1) {
			System.out.print((char)caract);
			caract=fr.read();
		}
		
		fr.close();
		
	}
}
