package pruebas;

import java.io.File;
import java.io.IOException;

public class EstructurasFiles {

	public static void main(String args[]) throws IOException {

		File directorio = new File("C:\\Users\\sergi\\eclipse-workspace\\accesoDatos\\Ficheros\\Cursos\\");
		File temaP = new File("C:\\Users\\sergi\\eclipse-workspace\\accesoDatos\\Ficheros\\Cursos\\Tema1");
		File temaS = new File("C:\\Users\\sergi\\eclipse-workspace\\accesoDatos\\Ficheros\\Cursos\\Tema2");
		File temaT = new File("C:\\Users\\sergi\\eclipse-workspace\\accesoDatos\\Ficheros\\Cursos\\Tema3");

		File fichero1 = new File("C:\\Users\\sergi\\eclipse-workspace\\accesoDatos\\Ficheros\\Cursos\\Tema1\\tema1.txt");
		File fichero2 = new File("C:\\Users\\sergi\\eclipse-workspace\\accesoDatos\\Ficheros\\Cursos\\Tema2\\tema2.txt");
		File fichero3 = new File("C:\\Users\\sergi\\eclipse-workspace\\accesoDatos\\Ficheros\\Cursos\\Tema3\\tema3.txt");

		File practica1 = new File("C:\\Users\\sergi\\eclipse-workspace\\accesoDatos\\Ficheros\\Cursos\\Tema1\\practica1.txt");
		File practica2 = new File("C:\\Users\\sergi\\eclipse-workspace\\accesoDatos\\Ficheros\\Cursos\\Tema2\\practica2.txt");
		File practica3 = new File("C:\\Users\\sergi\\eclipse-workspace\\accesoDatos\\Ficheros\\Cursos\\Tema3\\practica3.txt");

		if (!directorio.exists()) {
			if (directorio.mkdirs()) {

				System.out.println("Directorio Cursos creado");
				System.out.println();

			} else {
				System.out.println("Error al crear directorio");
			}
		}

		if (!temaP.exists()) {
			if (temaP.mkdirs()) {

				System.out.println("Directorio tema1 creado");
				System.out.println();

				if (fichero1.createNewFile() && practica1.createNewFile()) {

					System.out.println("Los ficheros se han creado correctamente");
					System.out.println();
				}

				else {

					System.out.println("No se han podido crear los ficheros");
					System.out.println();

				}

			} else {
				System.out.println("Error al crear directorio");
				System.out.println();
			}
		}

		if (!temaS.exists()) {
			if (temaS.mkdirs()) {
				System.out.println("Directorio tema2 creado");
				System.out.println();

				if (fichero2.createNewFile() && practica2.createNewFile()) {

					System.out.println("Los ficheros se han creado correctamente");
					System.out.println();
				}

				else {

					System.out.println("No se han podido crear los ficheros");
					System.out.println();

				}
			} else {
				System.out.println("Error al crear directorio");
				System.out.println();
			}
		}

		if (!temaT.exists()) {
			if (temaT.mkdirs()) {
				System.out.println("Directorio tema3 creado");
				System.out.println();

				if (fichero3.createNewFile() && practica3.createNewFile()) {

					System.out.println("Los ficheros se han creado correctamente");
					System.out.println();
				}

				else {

					System.out.println("No se han podido crear los ficheros");
					System.out.println();

				}
			} else {
				System.out.println("Error al crear directorio");
				System.out.println();
			}
		}
		
		System.out.println(temaP.getPath());
		System.out.println(fichero2.getAbsolutePath());
		System.out.println(temaT.getName());
		System.out.println(temaT.getParent());
		System.out.println(temaP.isDirectory());
		System.out.println(fichero1.isDirectory());
		System.out.println(fichero3.length());
		System.out.println(practica2.length());
		
	}

}
