package pruebas;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FilePrueba {

	public static void main(String[] args) throws IOException{
		
		escritura();

		lectura();

	}

	public static void escritura() throws IOException {

		FileWriter fichero = null;
		PrintWriter escritor = null;

		try {
			fichero = new FileWriter("Ficheros/archivo.txt");
			escritor = new PrintWriter(fichero);
			escritor.println("Esto es una línea del fichero");
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			if (fichero != null)
				try {
					fichero.close();
				} catch (IOException ioe) {

				}

		}

	}

	public static void lectura() throws IOException {

		BufferedReader buffer = null;
		//File fichero = null;
		//FileReader lector = null;

		try {
			buffer = new BufferedReader(new FileReader(new File("Ficheros/archivo.txt")));
			String linea = null;
			while ((linea = buffer.readLine()) != null)
				System.out.println(linea);
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			if (buffer != null)
				try { 
					buffer.close();
				} catch (IOException ioe) {

				}
		}
	}

}
