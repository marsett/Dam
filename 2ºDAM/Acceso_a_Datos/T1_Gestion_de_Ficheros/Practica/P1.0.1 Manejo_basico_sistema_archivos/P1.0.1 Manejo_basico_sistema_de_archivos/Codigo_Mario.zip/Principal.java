package ficheros;
import java.io.*;
import java.util.*;

public class Principal {
	public static void main(String[] args) throws IOException{
		
		Scanner entrada=new Scanner(System.in);
		
		int contador=1;
		
		Directorios_Ficheros b = new Directorios_Ficheros();
		
		for(int i=0;i<3;i++) {
			b.directorio_curso = new File("C:\\Users\\jimen\\CURSO");
			b.metcurso();
			b.temas = new File("C:\\Users\\jimen\\CURSO\\TEMA"+contador+"");
			b.metemas();
			b.teorias = new File("C:\\Users\\jimen\\CURSO\\TEMA"+contador+"\\teoria"+contador+".txt");
			b.meteorias();
			b.practicas = new File("C:\\Users\\jimen\\CURSO\\TEMA"+contador+"\\practica"+contador+".txt");
			b.metpracticas();
			contador++;
		}
		
		System.out.println("Preguntas sobre los Metodos");
		System.out.println("Es CURSO un directorio? --> "+b.directorio_curso.isDirectory());
		System.out.println("Son los TEMAS directorios? --> "+b.temas.isDirectory());
		System.out.println("Son las teorias ficheros? --> "+b.teorias.isFile());
		System.out.println("El nombre del directorio CURSO es "+b.directorio_curso.getName());
		System.out.println("La ruta de la practica1.txt es "+b.practicas.getPath());
		System.out.println("La ruta de la teoria1.txt es "+b.teorias.getAbsolutePath());
		System.out.println("La teoria1.txt puede ser leida? --> "+b.teorias.canRead());
		System.out.println("La practica1.txt puede ser escrita? --> "+b.practicas.canWrite());
		System.out.println("La longitud de teoria1.txt es "+b.teorias.length());
		System.out.println("La ruta de CURSO es "+b.temas.getParent());
		
		int sub=1;
		
		String[] lista=b.directorio_curso.list();
		for(int i=0;i<lista.length;i++) {
			System.out.println("El SUBDIRECTORIO "+sub+" de CURSO es "+lista[i]);
			sub++;
		}
		
		
		/*String nuevonombre;
		System.out.println("Introduce el nombre del fichero a renombrar");
		nuevonombre = entrada.nextLine();
		
		File f =new File(nuevonombre);
		if(f.exists()) {
			if(b.practicas.renameTo(f)) {
				System.out.println("Se ha cambiado el nombre");
			}
			else {
				System.out.println("No se pudo cambiar el nombre");
			}
		}*/
		
		entrada.close();
		
		String nombrefichero="C:\\Users\\jimen\\CURSO\\TEMA1\\teoria1.txt";
		//String nombrefichero2="C:\\Users\\jimen\\CURSO\\TEMA2\\teoria2.txt";
		
		FileWriter fw=null;
		try {
			fw=new FileWriter(nombrefichero);
			fw.write("Esta es la teoria del fichero teoria1.txt. Escrito con FileWriter");
			fw.close();
		}
		catch(FileNotFoundException e) {
			System.out.println("Error, fichero no encontrado");
			System.out.println(e.getMessage());
		}
		
		FileReader fr=null;
		try {
			fr = new FileReader(nombrefichero);
			int caracter=fr.read();
			while(caracter != -1) {
				System.out.print((char)caracter);
				caracter=fr.read();
			}
			fr.close();
		}
		catch(FileNotFoundException e){
			System.out.println("Error:Fichero no encontrado");
			System.out.println(e.getMessage());
		}
		
	}
}

class Directorios_Ficheros {
	
	int contador=1;
	int contador2=1;
	int contador3=1;
	
	File directorio_curso,temas,teorias,practicas;
	
	public void metcurso() {
		if(!directorio_curso.exists()) {
			if(directorio_curso.mkdirs()) {
				System.out.println("CURSO creado");
			}
			else {
				System.out.println("Ha habido un error al crear el directorio CURSO o ya existe");
			}
		}
	}
		
	public void metemas() {
		if(!temas.exists()) {
			if(temas.mkdir()){
				System.out.println("TEMA"+contador+" creado");
				contador++;
			}
			else {
				System.out.println("Ha habido un error al crear el directorio TEMA"+contador+" o ya existe");
				contador++;
			}
		}
	}
	
	public void meteorias() {
		if(!teorias.exists()) {
			try {
				if(teorias.createNewFile()) {
					System.out.println("teoria"+contador2+".txt creado");
					contador2++;
				}
				else {
					System.out.println("Ha habido un error al crear el fichero teoria"+contador2+".txt o ya existe");
					contador2++;
				}
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void metpracticas() {
		if(!practicas.exists()) {
			try {
				if(practicas.createNewFile()) {
					System.out.println("practica"+contador3+".txt creado");
					contador3++;
				}
				else {
					System.out.println("Ha habido un error al crear el fichero practica"+contador3+".txt o ya existe");
					contador3++;
				}
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
		
}