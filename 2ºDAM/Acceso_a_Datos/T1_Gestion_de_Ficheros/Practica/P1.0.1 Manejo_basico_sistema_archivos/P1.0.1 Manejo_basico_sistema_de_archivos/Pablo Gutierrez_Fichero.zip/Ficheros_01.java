package ad_Tema1;

import java.io.*;

public class Ficheros_01 {

	public static void main(String[] args) throws IOException{
		File d1 = new File("Cursos");
		d1.mkdir();
		String ruta1 = d1.getAbsolutePath();

		File d2 = new File(ruta1, "Tema1");
		File d3 = new File(ruta1, "Tema2");
		File d4 = new File(ruta1, "Tema3");
		d2.mkdirs();
		d3.mkdirs();
		d4.mkdirs();
		String ruta2 = d2.getAbsolutePath();
		String ruta3 = d3.getAbsolutePath();
		String ruta4 = d4.getAbsolutePath();

		File f1 = new File(ruta2, "teoria1.txt");
		File f2 = new File(ruta2,"pratica1.txt");
		File f3 = new File(ruta3,"teoria2.txt");
		File f4 = new File(ruta3,"pratica2.txt");
		File f5 = new File(ruta4,"teoria3.txt");
		File f6 = new File(ruta4,"pratica3.txt");
		f1.createNewFile();
		f2.createNewFile();
		f3.createNewFile();
		f4.createNewFile();
		f5.createNewFile();
		f6.createNewFile();

		System.out.println("Es un Directorio: "+d2.isDirectory());
		System.out.println("¿Cuál es el tamaño del Fichero2? "+f2.length());
		System.out.println("¿Cuál es el nombre de este directorio? "+d4.getName());
		System.out.println("¿Cuál es la ruta de este fichero? "+f3.getPath());
		System.out.println("¿Puede leer este fichero? "+f1.canRead());
		System.out.println("¿Puede escribir este fichero? "+f2.canWrite());
		System.out.println("Para listar este directorio: "+d2.list());
		System.out.println("Para borrar el fichero: "+f5.delete());
		System.out.println("Para saber el directorio padre: "+f4.getParent());
		System.out.println("Es un fichero: "+f6.isFile());
		System.out.println("Para renombrar un fichero: "+f6.renameTo(f5));
		
	}

}
