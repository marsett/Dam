package filePrueba;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class PruebaLuis {

	public static void main(String[] args) throws IOException {
		/*Scanner sc = new Scanner(System.in);
		System.out.println("Introduce lo que quieras en el fichero Prueba");
		String textoFichero=sc.nextLine();

		File Prueba = new File("Prueba");
		FileWriter fw;
		try {
			fw = new FileWriter(Prueba);
			fw.write(textoFichero);
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FileReader fr;
		BufferedReader br;
		try {
			fr = new FileReader(Prueba);
			br = new BufferedReader(fr);
			String linea = null;
			if(Prueba.canRead()) {
				System.out.println("Se puede leer");
				while ((linea = br.readLine()) != null)
					System.out.println(linea);
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
		System.out.println(Prueba.getAbsolutePath());
		*/
		int largo=3;

		File cursos = new File("Cursos");
		File temas[] = new File[largo];
		File temasTexto[]= new File[largo];
		File practicaTexto[] = new File[largo];;
		
		cursos.mkdir();
		
		for(int a=0;a<largo;a++) {
			
			int numTema=a+1;
			
			temas[a]=new File(cursos.getAbsolutePath(), "Tema "+numTema);
			temas[a].mkdir();
						
			if(temas[a].isDirectory()) {
				
				System.out.println(temas[a].getName()+" es un directorio");
				
				temasTexto[a] =new File(temas[a].getAbsolutePath(), "tema"+numTema+".txt");
				temasTexto[a].createNewFile();
				
				practicaTexto[a] =new File(temas[a].getAbsolutePath(), "practica"+numTema+".txt");
				practicaTexto[a].createNewFile();
				
				FileWriter fw = new FileWriter(temasTexto[a]);
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write("Se ha escrito en el fichero del Tema "+numTema+" correctamente");
				bw.close();
				FileReader fr = new FileReader(temasTexto[a]);
				BufferedReader br = new BufferedReader(fr);
				String linea = null;
				if(temasTexto[a].canRead()) {
					System.out.println("Se puede leer");
					while ((linea = br.readLine()) != null)
						System.out.println(linea);
				}
				br.close();
				
			}else {
				System.out.println(temas[a].getName()+"no es un directorio");
			}
			
		}
		
	}

}
