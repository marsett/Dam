package acceso_a_datos;

import java.io.*;

public class PruebaDirectorios {

	public static void main(String[] args) throws IOException {

		// Creación directorio curso

		File curso = new File("curso");
		curso.mkdir();

		// Creación de los temas

		File tema1 = new File(curso.getAbsolutePath(), "tema1");
		tema1.mkdirs();
		File tema2 = new File(curso.getAbsolutePath(), "tema2");
		tema2.mkdirs();
		File tema3 = new File(curso.getAbsolutePath(), "tema3");
		tema3.mkdirs();

		// Creación de los archivos *.txt

		File archivo1 = new File(tema1.getAbsolutePath(), "archivo1.txt");
		archivo1.createNewFile();
		
		File archivo2 = new File(tema1.getAbsolutePath(), "archivo2.txt");
		archivo2.createNewFile();
		
		File archivo3 = new File(tema1.getAbsolutePath(), "archivo3.txt");
		archivo3.createNewFile();

		File archivo4 = new File(tema2.getAbsolutePath(), "archivo1.txt");
		archivo4.createNewFile();
		
		File archivo5 = new File(tema2.getAbsolutePath(), "archivo2.txt");
		archivo5.createNewFile();
		
		File archivo6 = new File(tema2.getAbsolutePath(), "archivo3.txt");
		archivo6.createNewFile();

		File archivo7 = new File(tema3.getAbsolutePath(), "archivo1.txt");
		archivo7.createNewFile();
		
		File archivo8 = new File(tema3.getAbsolutePath(), "archivo2.txt");
		archivo8.createNewFile();
		
		File archivo9 = new File(tema3.getAbsolutePath(), "archivo3.txt");
		archivo9.createNewFile();
	}

}