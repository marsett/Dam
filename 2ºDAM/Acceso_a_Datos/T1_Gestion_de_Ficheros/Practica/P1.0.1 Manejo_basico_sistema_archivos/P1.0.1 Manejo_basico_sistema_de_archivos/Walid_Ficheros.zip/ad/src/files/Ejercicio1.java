package files;

import java.io.File;

public class Ejercicio1 {

	public static void main(String[] args) {
		File directorioCurso = new File("C:\\Users\\34637\\Documents\\Curso");

		/*
		 * File tema2 = new File("C:\\Users\\34637\\Documents\\Curso\\Tema2"); File
		 * tema3 = new File("C:\\Users\\34637\\Documents\\Curso\\Tema3");
		 */

		if (!directorioCurso.exists()) {
			if (directorioCurso.mkdirs()) {
				System.out.println("Directorios creados correctamente");
			} else {
				System.out.println("No se han podido crear los directorios");
			}
		}
		File tema1 = new File("C:\\Users\\34637\\Documents\\Curso\\Tema1");
		if (!tema1.exists()) {
			if (tema1.mkdirs()) {
				System.out.println("Directorios creados correctamente");
			} else {
				System.out.println("No se han podido crear los directorios");
			}
		}
		
		File tema2 = new File("C:\\Users\\34637\\Documents\\Curso\\Tema2");
		if (!tema2.exists()) {
			if (tema2.mkdirs()) {
				System.out.println("Directorios creados correctamente");
			} else {
				System.out.println("No se han podido crear los directorios");
			}
		}
		
		File tema3 = new File("C:\\Users\\34637\\Documents\\Curso\\Tema3");
		if (!tema3.exists()) {
			if (tema3.mkdirs()) {
				System.out.println("Directorios creados correctamente");
			} else {
				System.out.println("No se han podido crear los directorios");
			}
		}
	}

}
