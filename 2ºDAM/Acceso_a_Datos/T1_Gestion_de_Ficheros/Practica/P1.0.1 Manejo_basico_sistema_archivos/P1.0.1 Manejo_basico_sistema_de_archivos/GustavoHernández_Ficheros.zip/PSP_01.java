package Principios;

import java.io.*;

public class PSP_01 {
	
public static void main(String[] args) throws IOException, InterruptedException {
	
		File archivo = new File("Curso");
		archivo.mkdir();
		String R1 = archivo.getAbsolutePath();
		
		File Tema01 = new File(R1, "Tema1");
		Tema01.mkdir();
		String R2 = Tema01.getAbsolutePath();
		File A1 = new File(R2, "Teoria1.txt");
		A1.createNewFile();
		File A2 = new File(R2, "Teoria2.txt");
		A2.createNewFile();
		
		File Tema02 = new File(R1, "Tema2");
		Tema02.mkdir();
		String R3 = Tema02.getAbsolutePath();
		File A3 = new File(R3, "Teoria2.txt");
		A3.createNewFile();
		File A4 = new File(R3, "Proyecto2.txt");
		A4.createNewFile();
		
		File Tema03 = new File(R1, "Tema3");
		Tema03.mkdir();
		String R4 = Tema03.getAbsolutePath();
		File A5 = new File(R4, "Teoria3.txt");
		A5.createNewFile();
		File A6 = new File(R4, "Practica3.txt");
		A6.createNewFile();
		
		System.out.println("El primer archivo tiene "+A1.length()+" caracteres.");
		System.out.println("¿A2 es un directorio? "+A2.isDirectory());
		System.out.println("¿A3 es un archivo de texto? "+A3.isFile());
		System.out.println("El nombre de A5 es "+A5.getName());
		System.out.println("¿El archivo A6 se puede leer? "+A6.canRead());
		System.out.println("¿El archivo A3 se puede modificar? "+A3.canRead());
		System.out.println("El contenido del fichero Curso es "+archivo.list());
		System.out.println("El archivo A5 ha sido eliminado "+A5.delete());
		System.out.println(A1.renameTo(A6));
		
	}

}
