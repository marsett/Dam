package ficheros;

import java.io.File;

public class Main {
	
	public static void main(String[] args) {
		File curso = new File("C:\\Users\\artur\\CURSO");
		crearDirectorio(curso);
		int contador = 1;
		
		for(int i = 0; i<3; i++) {
			crearDirectorio(new File("C:\\Users\\artur\\CURSO\\TEMA"+ contador));
			crearFicheroDeTexto(new File("C:\\Users\\artur\\CURSO\\TEMA"+contador+"\\teoria"+contador+".txt"));
			crearFicheroDeTexto(new File("C:\\Users\\artur\\CURSO\\TEMA"+contador+"\\practica"+contador+".txt"));
			contador++;
		}
	}
	
	public static void crearDirectorio(File f) {
		if(f.mkdir()) {
			System.out.println("Directorio "+f.getName()+ " creado con éxito");
		}else {
			System.out.println("El directorio "+f.getName()+" ya existe");
		}
	}
	
	public static void crearFicheroDeTexto(File f) {
		try {
			if(f.createNewFile()) {
				System.out.println("Fichero "+f.getName()+ " creado con éxito");
			}else {
				System.out.println("El fichero "+f.getName()+" ya existe");
			}
		}catch(Exception e) {
			
		}
	}
	
}
