package archivos_binarios;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

public class Main{
	private RandomAccessFile raf;
	private File file;
	private FileOutputStream fos;
	private FileInputStream fis;
	
	//Parte RAF
	
	private void writePerson(long num, Person person) throws IOException{
		this.raf.seek(num*Person.SIZE);
		byte[] record=person.toBytes();
		this.raf.write(record);
	}
	
	private Person readPerson(long num) throws IOException{
		this.raf.seek(num*Person.SIZE);
		byte[] record=new byte[Person.SIZE];
		this.raf.read(record);
		return Person.fromBytes(record);
	}
	
	//Parte SECUENCIAL
	
	private void writePerson(Person person, boolean salida,long num) throws IOException {
		fos = new FileOutputStream(file, salida);
		byte[] record = person.toBytes();
		for(int i=0;i<record.length;i++) {
			fos.write(record[i]);
		}
		fos.close();
	}
 
	private Person readPerson(Person person, boolean salida) throws IOException {
		fis = new FileInputStream(file);
		byte[] record = person.toBytes();
		for(int i=0;i<record.length;i++) {
			fis.readAllBytes();
		}
		fis.close();
		return Person.fromBytes(record);
	}
	
	public void run() {
		try {
			
			Person p1=new Person(1000, "Ignacio", 40,false);
			Person p2=new Person(2000, "Ezequiel", 63, true);
			Person p3=new Person(3000, "Zacarias", 18, false);
			Person p4=new Person(4000, "Ditario", 24, true);
			Person p5=new Person(5000, "Hilario", 43, true);
			Person p6=new Person(6000, "Jose Luis", 18, false);
			
			//Parte RAF
			
			raf=new RandomAccessFile("peopleraf.dat","rw"); 
			
			this.writePerson(0, p1);
			this.writePerson(1, p2);
			this.writePerson(2, p3);
			this.writePerson(3, p4);
			this.writePerson(4, p5);
			this.writePerson(5, p6);
			
			Person praf;
			
			praf=this.readPerson(0);
			System.out.println("p raf= "+praf);
			praf=this.readPerson(1);
			System.out.println("p raf= "+praf);
			praf=this.readPerson(2);
			System.out.println("p raf= "+praf);		
			praf=this.readPerson(3);
			System.out.println("p raf= "+praf);
			praf=this.readPerson(4);
			System.out.println("p raf= "+praf);
			praf=this.readPerson(5);
			System.out.println("p raf= "+praf);
			
			System.out.println("/*****/\n/*****/\n/*****/\n/*****/");
			
			//Parte SECUENCIAL
			
			file=new File("peoplesec.dat");
			
			this.writePerson(p1, false, 0);
			this.writePerson(p2, true, 1);
			this.writePerson(p3, true, 2);
			this.writePerson(p4, true, 3);
			this.writePerson(p5, true, 4);
			this.writePerson(p6, true, 5);
 
			Person psec;
 
			psec = this.readPerson(p1,false);
			System.out.println("p sec= " + psec);
			psec = this.readPerson(p2,true);
			System.out.println("p sec= " + psec);
			psec = this.readPerson(p3,true);
			System.out.println("p sec= " + psec);
			psec = this.readPerson(p4,true);
			System.out.println("p sec= " + psec);
			psec = this.readPerson(p5,true);
			System.out.println("p sec= " + psec);
			psec = this.readPerson(p6,true);
			System.out.println("p sec= " + psec);
			
		}
		catch(IOException e) {
			System.out.println("Ha ocurrido un error");
		}
	}
	
	public static void main(String[] args) {
		Main objetomain=new Main();
		objetomain.run();
	}
}
