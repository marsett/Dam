package archivos_binarios;

public class PackUtils {
	
	/*En el primer metodo de la libreria se va a empaquetar los valores de tipo boolean,
	 * pasando por parametro un boolean, un array de bytes que va a servir para leer o
	 * escribir los datos y una variable de tipo int, la cual indicara la posicion inicial
	 * a partir de la que leeremos o escribiremos
	 * 
	 * Dentro del metodo, hay un condicional que dice que, si b es igual a 1, el array de bytes
	 * sea igual a 1(con casteo incluido); si no, sera igual a 0. Si es igual a 1, es true; si es
	 * igual a 0, es false*/
	
	public static void packBoolean(boolean b, byte[] buffer, int offset) {
		if(b) {
			buffer[offset]=(byte)1;
		}
		else {
			buffer[offset]=(byte)0;
		}
	}
	
	/*Sin embargo, en el siguiente método se desempaquetan estos valores de tipo boolean; en este caso,
	 * solo se pasan por parametro el array de bytes y la variable int que indicaba la posicion inicial
	 * a partir de la que se lee o escribe. Es un metodo que devuelve que, el array buffer es igual a 1,
	 * lo cual es true, lo cual hace que se desempaqueten los bytes correspondientes*/
	
	public static boolean unpackBoolean(byte[] buffer, int offset) {
		return buffer[offset]==(byte)1;
	}
	
	/*En este metodo, se empaquetan los valores de tipo char. Se pasa por parametros lo mismo que en el primer metodo,
	 * pero cambiando el boolean por el char; se dice que el array buffer (casteando byte) desplaza 8 bits a la derecha
	 * los valores de tipo char. Si se añade 1 al offset, no se desplaza*/
	
	public static void packChar(char c, byte[] buffer, int offset) {
		buffer[offset]=(byte)(0xFF & (c >> 8));
		buffer[offset +1]=(byte)(0xFF & c);
	}
	
	/*En este metodo se desempaquetan los valores char; se pasa por parametro lo mismo que al desempaquetar boolean.
	 * Se devuelve (casteando char) el buffer desplazado 8 bits a la izquierda; con el offset sumandole 1, no se
	 * desplaza nada*/
	
	public static char unpackChar(byte[] buffer, int offset) {
		return (char) ((buffer[offset] << 8) | (buffer[offset+1] & 0xFF));
	}
	
	/*En este metodo se empaquetan valores de tipo String. Se pasa por parametros lo mismo que en los anteriores metodos,
	 * cambiando que se pasa ahora un String y un entero que marca la maxima longitud. Se hace un bucle for con esta ultima
	 * variable; dentro de el, un if que dice que, si el indice del for es menor a la longitud del String, se llama al
	 * metodo packChar, pasando por parametro como char a cada posicion del for, al bufer y al offset; este ultimo con una
	 * modificacion: se multiplica la posicion específica y se le multiplica por 2; esto se le suma al offset.
	 * El else hace lo mismo, exceptuando que no coge cada posicion del for*/
	
	public static void packLimitedString(String str, int maxLength, byte[] buffer, int offset) {
		for(int i=0;i<maxLength;i++) {
			if(i<str.length()) {
				packChar(str.charAt(i),buffer,offset+2*i);
			}
			else {
				packChar('\0', buffer, offset+2*i);
				break;
			}
		}
	}
	
	/*En este metodo se desempaquetan los valores String, pasando los mismos valores por parametro que en el anterior metodo,
	 * pero quitando el String. Se hace un for (con la misma filosofia que el anterior); dentro, la variable char llama al metodo de desempaquetar
	 * los char, pasando por parametros el buffer y el offset con la modificacion del anterior metodo. Despues, se hace un if que dice que,
	 * si el char es igual a \0, al String result que se acaba de crear se le suma esta c. Finalmente se retorna el String result*/
	
	public static String unpacklimitedString(int maxLength, byte[] buffer, int offset) {
		String result="";
		for(int i=0;i<maxLength;i++) {
			char c=unpackChar(buffer, offset+2*i);
			if(c!='\0') {
				result+=c;
			}
			else {
				break;
			}
		}
		return result;
	}
	
	/*En este metodo se empaquetan valores de tipo int, pasando como parametros un entero, el buffer y el offset.
	 * El buffer (casteando byte) sera igual al entero n desplazado 24 bits a la derecha. Se va sumando al offset un numero
	 * y reduciendo los bits a desplazar hasta que se queda sin bits*/
	
	public static void packInt(int n, byte[] buffer, int offset) {
		buffer[offset]=(byte)(n>>24);
		buffer[offset+1]=(byte)(n>>16);
		buffer[offset+2]=(byte)(n>>8);
		buffer[offset+3]=(byte)n;
	}
	
	/*En este metodo se desempaquetan los valores de tipo int. Este devuelve lo mismo que el anterior metodo, pero con un cambio:
	 * en vez de desplazar los bits a la derecha, se desplazan a la izquierda. Ademas, se pasaba por parametros lo mismo, exceptuando
	 * el entero*/
	
	public static int unpackInt(byte[] buffer, int offset) {
		return ((buffer[offset])<<24)|
				((buffer[offset+1]&0xFF)<<16)|
				((buffer[offset+2]&0xFF)<<8)|
				((buffer[offset+3]&0xFF));
	}
	
	/*Este metodo de empaquetamiento de variables de tipo long es exactamente igual al de empaquetamiento de variables de tipo int
	 * cambiando simplemente el numero de bits a desplazar (que obviamente es mas grande) y la variable pasada por parametro, que es long
	 * en vez de int*/
	
	public static void packLong(long n, byte[] buffer, int offset) {
		buffer[offset]=(byte)(n>>56);
		buffer[offset+1]=(byte)(n>>48);
		buffer[offset+2]=(byte)(n>>40);
		buffer[offset+3]=(byte)(n>>32);
		buffer[offset+4]=(byte)(n>>24);
		buffer[offset+5]=(byte)(n>>16);
		buffer[offset+6]=(byte)(n>>8);
		buffer[offset+7]=(byte)n;
	}
	
	/*Este metodo de desempaquetan las variables de tipo long. Es igual que el anterior metodo, lo unico que cambia son los bits desplazados
	 * (que se desplazan a la izquierda) y que no se pasa la variable long por parametro*/
	
	public static long unpackLong(byte[] buffer, int offset) {
		return ((long)(buffer[offset])<<56)|
			   ((long)(buffer[offset+1]&0xFF)<<48)|
			   ((long)(buffer[offset+2]&0xFF)<<40)|
			   ((long)(buffer[offset+3]&0xFF)<<32)|
			   ((long)(buffer[offset+4]&0xFF)<<24)|
			   ((long)(buffer[offset+5]&0xFF)<<16)|
			   ((long)(buffer[offset+6]&0xFF)<<8)|
			   ((long)(buffer[offset+7]&0xFF));
	}
	
	/*Este metodo de empaquetamiento de variables double pasa por parametro un double, el buffer y el offset. Se crea un long de bits
	 * que llama al metodo de la clase Double "doubleToRawLongBits", que pasa por parametro la variable double anterior. Este metodo
	 * devuelve los bits representados en esta variable. Luego, se empaquetan esos bits llamando al metodo packLong*/
	
	public static void packDouble(double n, byte[] buffer, int offset) {
		long bits=Double.doubleToRawLongBits(n);
		packLong(bits, buffer, offset);
	}
	
	/*Este metodo desempaqueta las variables double. Se pasa por parametro solo el buffer y el offset. La variable bits llama al metodo
	 * unpackLong (pasando por parametros el buffer y el offset) y retornando los valores double de los bits que estaban antes empaquetados
	 * en el metodo packLong*/
	
	public static double unpackDouble(byte[] buffer, int offset) {
		long bits=unpackLong(buffer, offset);
		return Double.longBitsToDouble(bits);
	}

}
