package domsax;
import java.io.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

@SuppressWarnings("deprecation")
public class EjemploDOMySAX {
	//método que escribe en el fichero de datos a cuatro personas
	private static void creaFicheroDatosPersonas(String[] args) throws IOException {
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File(args[0])));
		oos.writeObject(new Persona("Mario", 19));
		oos.writeObject(new Persona("Sergio", 19));
		oos.writeObject(new Persona("Luis", 20));
		oos.writeObject(new Persona("Pablo", 20));
		oos.close();
	}
	//método que crea el fichero xml donde se almacenarán las personas
	private static void creaFicheroXMLPersonas(String[] args) throws IOException {
		FileInputStream fis = new FileInputStream(new File(args[0]));
		ObjectInputStream ois = new ObjectInputStream(fis);
		Persona p;
		try {
			Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().getDOMImplementation().createDocument(null, "personas", null);
			document.setXmlVersion("1.0");
			while (fis.available() > 0) {
				p = (Persona) ois.readObject();
				Element raiz = document.createElement("persona");
				document.getDocumentElement().appendChild(raiz);
				crearElemento("nombre", p.getNombre(), raiz, document);
				crearElemento("edad", String.valueOf(p.getEdad()), raiz, document);
			}
			TransformerFactory.newInstance().newTransformer().transform(new DOMSource(document),
					new StreamResult(new java.io.File(args[1])));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ois.close();
		fis.close();
	}
	//método que crea el elemento
	static void crearElemento(String datoEmple, String valor, Element raiz, Document document) {
		Element elem = document.createElement(datoEmple);
		Text text = document.createTextNode(valor);
		raiz.appendChild(elem);
		elem.appendChild(text);
	}
	//método que imprime el fichero xml con las personas escritas
	public static void imprimirFicheroXMLPersonas(String[] args) {
		try {
			Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new File(args[1]));
			document.getDocumentElement().normalize();
			System.out.println(document.getDocumentElement().getNodeName());
			NodeList empleados = document.getElementsByTagName("persona");
			for (int i = 0; i < empleados.getLength(); i++) {
				Node emple = empleados.item(i);
				if (emple.getNodeType() == Node.ELEMENT_NODE) {
					Element elemento = (Element) emple;
					System.out.print(" " + getNodo("nombre", elemento));
					System.out.println(" \t" + getNodo("edad", elemento));
				}
			}
		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
	}
	//método que hace llamar al nodo
	private static String getNodo(String etiqueta, Element elem) {
		NodeList nodo = elem.getElementsByTagName(etiqueta).item(0).getChildNodes();
		Node valorNodo = (Node) nodo.item(0);
		return valorNodo.getNodeValue();
	}
	//se llama a todos los métodos
	public static void main(String[] args) throws IOException, SAXException {
		String[] argumentos = { "personas.dat", "personas.xml" };
		creaFicheroDatosPersonas(argumentos);
		creaFicheroXMLPersonas(argumentos);
		imprimirFicheroXMLPersonas(argumentos);
		XMLReader lector = XMLReaderFactory.createXMLReader();
		GestionContenido gestor = new GestionContenido();
		lector.setContentHandler(gestor);
		InputSource ficheroXML = new InputSource("personas.xml");
		lector.parse(ficheroXML);
	}
}
	//clase interna que muestra el contenido a través de SAX
	class GestionContenido extends DefaultHandler{
		public GestionContenido(){
		super();
		}
		@Override
		public void startDocument(){
		System.out.println("Comienzo del documento");
		}
		@Override
		public void endDocument(){
		System.out.println("Fin del documento");
		}
		@Override
		public void startElement(String uri,String nombre,String nombreC, Attributes atts){
		System.out.println("\tPrincipio del Elemento: "+nombre);
		}
		@Override
		public void endElement(String uri,String nombre,String nombreC){
		System.out.println("\tFin del Elemento: "+nombre);
		}
		@Override
		public void characters(char[]ch,int inicio,int longitud)throws SAXException{
		String car = new String(ch,inicio,longitud);
		car = car.replaceAll("[\t\n]","");
		System.out.println("\tCaracteres: "+car);
		}
	}