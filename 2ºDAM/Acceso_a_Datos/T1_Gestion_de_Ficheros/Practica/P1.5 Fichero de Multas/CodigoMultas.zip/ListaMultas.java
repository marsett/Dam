package multasprincipio;
import java.io.*;
import java.util.*;
public class ListaMultas implements Serializable{
	private static final long serialVersionUID = 1L;
	private static ArrayList<Multa>lista=new ArrayList<>();
		public void insertarMulta(Multa multa) {
			lista.add(multa);
		}
		public ArrayList<Multa> getLista() {
			return lista;
		}
		@SuppressWarnings("static-access")
		public void setLista(ArrayList<Multa> lista) {
			this.lista = lista;
		}
}
