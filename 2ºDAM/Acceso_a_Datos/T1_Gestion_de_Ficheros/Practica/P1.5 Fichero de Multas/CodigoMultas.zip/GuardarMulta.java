package multasprincipio;
import java.io.*;

public class GuardarMulta {
	ListaMultas listamultas=new ListaMultas();
		public void guardar(File fichero) {
				try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fichero));){
					oos.writeObject(listamultas);		
				}catch(IOException e) {
					System.out.println("Error al ESCRIBIR");
					e.printStackTrace();
				}
			System.out.println("Fichero guardado en la ruta "+fichero.getAbsolutePath());
		}
}
