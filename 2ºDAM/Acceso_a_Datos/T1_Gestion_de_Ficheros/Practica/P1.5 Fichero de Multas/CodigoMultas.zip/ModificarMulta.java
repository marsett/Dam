package multasprincipio;

import java.util.Scanner;

public class ModificarMulta {
	Scanner sc=new Scanner(System.in);
	ListaMultas listamultas=new ListaMultas();
		public void modificar(int posicion) {
			System.out.println("Que variable de la multa deseas modificar?\n1-NumAgente\n2-Localidad\n3-Coste\n4-Pagada,NoPagada");
				int opcion=sc.nextInt();
					switch(opcion) {
					case 1:
						System.out.println("Introduce el nuevo NumAgente");
							int nuevoNumAgente=sc.nextInt();
								Multa multaAgente=new Multa(listamultas.getLista().get(posicion).getNumMulta(),nuevoNumAgente,listamultas.getLista().get(posicion).getLocalidad(),listamultas.getLista().get(posicion).getCoste(),
										listamultas.getLista().get(posicion).isPagada());
								listamultas.getLista().remove(posicion);
								listamultas.getLista().add(multaAgente);
						break;
					case 2:
						System.out.println("Introduce la nueva Localidad");
						sc.nextLine();
						String nuevaLocalidad=sc.nextLine();
						System.out.println("Cambiando localidad...");
							Multa multaLocalidad=new Multa(listamultas.getLista().get(posicion).getNumMulta(),listamultas.getLista().get(posicion).getNumAgente(),nuevaLocalidad, listamultas.getLista().get(posicion).getCoste(),
									listamultas.getLista().get(posicion).isPagada());
							listamultas.getLista().remove(posicion);
							listamultas.getLista().add(multaLocalidad);
						System.out.println("LOCALIDAD CAMBIADA");
						break;
					case 3:
						System.out.println("Introduce el nuevo Coste");
							double nuevoCoste=sc.nextDouble();
								Multa multaCoste=new Multa(listamultas.getLista().get(posicion).getNumMulta(),listamultas.getLista().get(posicion).getNumAgente(),listamultas.getLista().get(posicion).getLocalidad(), nuevoCoste,
										listamultas.getLista().get(posicion).isPagada());
								listamultas.getLista().remove(posicion);
								listamultas.getLista().add(multaCoste);
						break;
					case 4:
						boolean cambio;
							if(listamultas.getLista().get(posicion).isPagada()==true) {
								cambio=false;
							}
							else {
								cambio=true;
							}
								Multa multaCambio=new Multa(listamultas.getLista().get(posicion).getNumMulta(),listamultas.getLista().get(posicion).getNumAgente(),listamultas.getLista().get(posicion).getLocalidad(),
										listamultas.getLista().get(posicion).getCoste(),cambio);
								listamultas.getLista().remove(posicion);
								listamultas.getLista().add(multaCambio);
						break;
					}
		}
}
