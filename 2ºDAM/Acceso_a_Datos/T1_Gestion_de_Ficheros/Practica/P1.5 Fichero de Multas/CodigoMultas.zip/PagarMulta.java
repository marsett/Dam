package multasprincipio;

public class PagarMulta {
	ListaMultas listamultas=new ListaMultas();
		public void pagar(int posicion) {
			boolean cambio;
				if(listamultas.getLista().get(posicion).isPagada()==true) {
					System.out.println("La multa ya esta pagada");
				}
				else {
					System.out.println("Esta multa esta pendiente de pago");
					System.out.println("El coste de la misma es de "+listamultas.getLista().get(posicion).getCoste());
						try {
							System.out.println("Pagando...");
								Thread.sleep(3000);
								cambio=true;
									Multa multaCambio=new Multa(listamultas.getLista().get(posicion).getNumMulta(),listamultas.getLista().get(posicion).getNumAgente(),listamultas.getLista().get(posicion).getLocalidad(),
											listamultas.getLista().get(posicion).getCoste(),cambio);
									listamultas.getLista().remove(posicion);
									listamultas.getLista().add(multaCambio);
							System.out.println("Multa Pagada");
						}catch (InterruptedException e) {
							e.printStackTrace();
						}
				}
		}
}
