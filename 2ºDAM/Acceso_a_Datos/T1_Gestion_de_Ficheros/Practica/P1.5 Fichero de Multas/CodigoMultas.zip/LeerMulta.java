package multasprincipio;
import java.io.*;

public class LeerMulta {
	ListaMultas listamultas=new ListaMultas();
		public void leer(File fichero) throws IOException, ClassNotFoundException{
			ObjectInputStream ois=null;
				if(fichero.exists()) {
					ois=new ObjectInputStream(new FileInputStream(fichero));
						try {
							listamultas =(ListaMultas)ois.readObject();
							System.out.println("Las Multas almacenadas son:");
								for(Multa m: listamultas.getLista()) {
									System.out.println(m);
								}
						}catch(EOFException e) {
							System.out.println("Final del Fichero");
						}finally {
							ois.close();
						}
				}
		}
}
