package multasprincipio;
import java.io.*;
public class Multa implements Serializable{
	private static final long serialVersionUID = 1L;
	private int numMulta;
	private static int contador=1;
	private int numAgente;
	private String localidad;
	private double coste;
	private boolean pagada;
		public Multa() {
			
		}
		public Multa(int numAgente, String localidad, double coste, boolean pagada) {
			this.numMulta = contador;
			this.numAgente = numAgente;
			this.localidad = localidad;
			this.coste = coste;
			this.pagada = pagada;
			contador++;
		}
		public Multa(int numMulta, int numAgente, String localidad, double coste, boolean pagada) {
			this.numMulta = numMulta;
			this.numAgente = numAgente;
			this.localidad = localidad;
			this.coste = coste;
			this.pagada = pagada;
		}
			public int getNumMulta() {
				return numMulta;
			}
			public void setNumMulta(int numMulta) {
				this.numMulta = numMulta;
			}
			public int getNumAgente() {
				return numAgente;
			}
			public void setNumAgente(int numAgente) {
				this.numAgente = numAgente;
			}
			public String getLocalidad() {
				return localidad;
			}
			public void setLocalidad(String localidad) {
				this.localidad = localidad;
			}
			public double getCoste() {
				return coste;
			}
			public void setCoste(double coste) {
				this.coste = coste;
			}
			public boolean isPagada() {
				return pagada;
			}
			public void setPagada(boolean pagada) {
				this.pagada = pagada;
			}
			public String toString() {
				return "Multa{"+"NumMulta="+numMulta+", NumAgente="+numAgente+", Localidad="+localidad+", Coste="+coste+", Pagada="+pagada+"}";
			}
}
