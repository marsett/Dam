package multasprincipio;
import java.io.*;
import java.util.*;
public class Principal {
	static final File fichero=new File("C:\\Users\\jimen\\eclipse-workspace\\Multas\\ficheroMultas.txt");
	ListaMultas listamultas=new ListaMultas();
	Scanner entrada=new Scanner(System.in);
		Principal(){
		}
		public static void main(String[] args) throws Exception {
			Principal p=new Principal();
			p.menu();
		}
		public void menu() throws Exception {
			MetodosMultas metodosmultas=new MetodosMultas();
			LeerMulta leermulta=new LeerMulta();
			metodosmultas.cargarListaMultas(fichero);
			int eleccion;
			do {
				System.out.println("Bienvenido al Menu de Multas");
					try {
						Thread.sleep(500);
					}catch (InterruptedException e) {
						e.printStackTrace();
					}
				System.out.println("Elige entre las siguientes opciones\n1-Crear multa\n2-Eliminar multa\n3-Guardar multas\n4-Modificar multa"
						+ "\n5-Pagar multa\n6-Consultar las multas\n7-Buscar multas por agente\n8-Buscar multas por numMulta"
						+ "\n9-Buscar multas por localidad\n10-Salir del Menu");
					eleccion=entrada.nextInt();
					switch(eleccion) {
					case 1:
						metodosmultas.crearMulta();
						break;
					case 2:
						metodosmultas.eliminarMulta();
						break;
					case 3:
						metodosmultas.guardarMulta(fichero);
						break;
					case 4:
						metodosmultas.modificarMulta();
						break;
					case 5:
						metodosmultas.pagarMulta();
						break;
					case 6:
						leermulta.leer(fichero);
						break;
					case 7:
						metodosmultas.buscarMultaNumeroAgente();
						break;
					case 8:
						metodosmultas.buscarMultaIdMulta();
						break;
					case 9:
						metodosmultas.buscarMultaLocalidad();
						break;
					case 10:
						System.out.println("Saliendo del Menu...");
						System.out.println("Ejecucion del Programa finalizada");
						break;
					}
			}while(eleccion!=10);
				entrada.close();
		}
}
