package multasprincipio;
import java.util.*;

import java.io.*;
public class MetodosMultas {
	Scanner entrada=new Scanner(System.in);
	ListaMultas listamultas=new ListaMultas();
		public void crearMulta() {
			System.out.println("Crear Multa\nVariables de la Multa\nNumero de Agente");
				int numAgente=entrada.nextInt();
			entrada.nextLine();
			System.out.println("Localidad");
				String localidad=entrada.nextLine();
			System.out.println("Coste");
				double coste=entrada.nextDouble();
			System.out.println("Pagada-->true\nNo Pagada-->false");
				boolean pagada=entrada.nextBoolean();
			System.out.println("Creando Multa...");
				Multa m=new Multa(numAgente,localidad,coste,pagada);
				this.listamultas.insertarMulta(m);	
			System.out.println("Multa Creada");
		}
		public void eliminarMulta() {
			System.out.println("Eliminar Multa\nCual es el idMulta?");
				int id=entrada.nextInt();
				int posicion=0;
					for(int i=0;i<listamultas.getLista().size();i++) {
						if(id==listamultas.getLista().get(i).getNumMulta()) {
							posicion=i;
							System.out.println("Multa eliminada con exito");
						}
					}
			listamultas.getLista().remove(posicion);
		}
		public void guardarMulta(File fichero) {
			GuardarMulta gm=new GuardarMulta();
			System.out.println("Guardar Multa\nDeseas guardar todas las multas creadas?\\nSi\\nNo");
				entrada.nextLine();
				String respuesta=entrada.nextLine();
					if(respuesta.equalsIgnoreCase("si")) {
						gm.guardar(fichero);
					}
			System.out.println("Todas las multas han sido guardadas");
		}
		public void modificarMulta() {
			System.out.println("Modificar Multa\nCual es el idMulta de la multa a modificar?");
				int id=entrada.nextInt();
				int posicion=0;
					for(int i=0;i<listamultas.getLista().size();i++) {
						if(id==listamultas.getLista().get(i).getNumMulta()) {
							posicion=i;
						}
					}
			ModificarMulta mm=new ModificarMulta();
			mm.modificar(posicion);
		}
		public void pagarMulta() {
			System.out.println("Pagar Multa\nCual es el idMulta de la multa a verificar su pago?");
				int id=entrada.nextInt();
				int posicion=0;
					for(int i=0;i<listamultas.getLista().size();i++) {
						if(id==listamultas.getLista().get(i).getNumMulta()) {
							posicion=i;
						}
					}
			PagarMulta mpm=new PagarMulta();
			mpm.pagar(posicion);
		}
		public void buscarMultaNumeroAgente() {
			System.out.println("Buscar Multas por Numero de Agente\nCual es el numAgente de la multa o multas a encontrar?");
				int numAgente=entrada.nextInt();
				int posicion=0;
			System.out.println("Las multas son:");
					for(int i=0;i<listamultas.getLista().size();i++) {
						if(numAgente==listamultas.getLista().get(i).getNumAgente()) {
							posicion=i;
							System.out.println(listamultas.getLista().get(posicion));
						}
					}
		}
		public void buscarMultaIdMulta() {
			System.out.println("Buscar Multas por Numero de Multa\nCual es el idMulta de la multa o multas a encontrar?");
				int idMulta=entrada.nextInt();
				int posicion=0;
			System.out.println("Las multas son:");
					for(int i=0;i<listamultas.getLista().size();i++) {
						if(idMulta==listamultas.getLista().get(i).getNumMulta()) {
							posicion=i;
							System.out.println(listamultas.getLista().get(posicion));
						}
					}
		}
		public void buscarMultaLocalidad() {
			System.out.println("Buscar Multas por Localidad\nCual es la localidad de la multa o multas a encontrar?");
			entrada.nextLine();
				String localidad=entrada.nextLine();
				int posicion=0;
			System.out.println("Las multas son:");
			for(int i=0;i<listamultas.getLista().size();i++) {
				if(localidad.equalsIgnoreCase(listamultas.getLista().get(i).getLocalidad())) {
					posicion=i;
					System.out.println(listamultas.getLista().get(posicion));
				}
			}
		}
		public ListaMultas cargarListaMultas(File fichero) throws Exception {
			System.out.println("Cargando Multas...");
			DataInputStream dis=new DataInputStream(new FileInputStream(fichero));
			ObjectInputStream ois=new ObjectInputStream(dis);
			listamultas=(ListaMultas)ois.readObject();
			ois.close();
			dis.close();
			for(Multa m:listamultas.getLista()) {
				System.out.println(m);
			}
			System.out.println("Multas cargadas con exito");
			return listamultas;
		}
}
