package db4o;
import com.db4o.*;
//Ejemplo DB4O
public class Main {
	public static void main(String[] args) {
	//Creamos la conexion
		ObjectContainer db=Db4oEmbedded.openFile("personas.db4o");
	//Creamos los objetos
		Persona p1=new Persona("Crispulo",30,120,1.59);
		Persona p2=new Persona("Robustiano",40,180,1.99);
		Persona p3=new Persona("Andrea Diaz Navas",20,56,1.70);
		Persona p4=new Persona("Rober Widoll",57,50,1.65);
		Persona p5=new Persona("Arturo",20,70,1.80);
	//Guardamos los objetos en la base de datos
		db.store(p1);
		db.store(p2);
		db.store(p3);
		db.store(p4);
		db.store(p5);
	// Para filtrar objetos con DB4O necesitamos un objeto de ejemplo para que lo filtre por ello. Vamos a ver varios ejemplos.
	// Si quisiéramos mostrar todos los objetos de una base de datos:
	// Todas las personas
		Persona p=new Persona();
		ObjectSet<Persona>result=db.queryByExample(p);
		System.out.println("Todas las Personas");
			while(result.hasNext()) {
				System.out.println(result.next());
			}
	// Si queremos filtrar por un atributo en concreto, tendremos que darle valor a ese atributo en concreto:
	// Todas las personas con la edad de 30
		p=new Persona(null,30,0,0);
		result=db.queryByExample(p);
		System.out.println("Personas con 30 años");
			while(result.hasNext()) {
				System.out.println(result.next());
			}
	// Si fuera dos parámetros:Todas las personas con la edad de 30 y 1.70 de altura
		p=new Persona(null,20,1.70,0);
		result=db.queryByExample(p);
		System.out.println("Personas con 20 años y altura de 1.70");
			while(result.hasNext()) {
				System.out.println(result.next());
			}
	// Personas con un nombre concreto: Todas las personas llamadas Domingo
		p=new Persona("Rober Widoll",0,0,0);
		result=db.queryByExample(p);
		System.out.println("Personas que se llamen Rober Widoll");
			while(result.hasNext()) {
				System.out.println(result.next());
			}
	// BORRAR Personas con un nombre concreto:  Todas las personas llamadas Arturo
		p=new Persona("Arturo",0,0,0);
		result=db.queryByExample(p);
		System.out.println("Personas borradas que se llamen Arturo");
			while(result.hasNext()) {
				db.delete(result.next());
			}
	//Para ver si se han borrado las personas que se llamen Arturo
		p=new Persona();
		result=db.queryByExample(p);
		System.out.println("Todas las personas");
			while(result.hasNext()) {
				System.out.println(result.next());
			}
	//Cerramos la base de datos
		db.close();
	}
}
