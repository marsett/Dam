package ormlite2;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 * ejemplo de objeto Account el cual es persistente gracias al DAO
 */
@DatabaseTable(tableName = "accounts")
public class Account {
	//se crean las variables estáticas y constantes del nombre y la contraseña en los campos
	public static final String NAME_FIELD_NAME = "name";
	public static final String PASSWORD_FIELD_NAME = "passwd";
	//se crea la variable id si el generateId es igual a verdadero
	@DatabaseField(generatedId = true)
	private int id;
	//se crea el nombre de la columna si este es el de la variable anteriormente creada y no puede ser falso
	@DatabaseField(columnName = NAME_FIELD_NAME, canBeNull = false)
	private String name;
	//se crea la contraseña si el nombre de la columna es igual al campo de la contraseña
	@DatabaseField(columnName = PASSWORD_FIELD_NAME)
	private String password;
	//todas las clases persistentes deben definir un constructor vacío
	Account() {}
	//se crean dos constructores diferentes con las variables anteriormente creadas
	public Account(String name) {
		this.name = name;
	}
	public Account(String name, String password) {
		this.name = name;
		this.password = password;
	}
	//se crean los getters y setters correspondientes
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	//el método hashCode se ha sobrescrito para retornar la variable nombre con el método hashCode
	@Override
	public int hashCode() {
		return name.hashCode();
	}
	//se sobrescribe el método equals con el objetivo de comparar la variable nombre con otro objeto casteado a Account
	@Override
	public boolean equals(Object other) {
		if (other == null || other.getClass() != getClass()) {
			return false;
		}
		return name.equals(((Account) other).name);
	}
}
