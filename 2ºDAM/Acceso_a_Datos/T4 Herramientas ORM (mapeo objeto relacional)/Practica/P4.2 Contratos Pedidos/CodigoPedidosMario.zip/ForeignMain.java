package ormlite2;
import java.util.List;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.jdbc.JdbcConnectionSource;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.support.ConnectionSource;
//import com.j256.ormlite.table.TableUtils;

public class ForeignMain {
	//se crea una variable donde se introduce el nombre de la base de datos creada en MySQL Workbench
	private final static String DATABASE_URL = "dbpruebaDos";
	//se crean dos variables del tipo Dao cuyo tipado es Account y Order
	private Dao<Account, Integer> accountDao;
	private Dao<Order, Integer> orderDao;
	//en el main se define el driver de MySQL, además de llamar al método doMain
	public static void main(String[] args) throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		new ForeignMain().doMain(args);
	}
	//este método crea una conexión, a la cual se le pasa el nombre de la base de datos anteriormente utilizada
	private void doMain(String[] args) throws Exception {
		JdbcConnectionSource connectionSource = null;
		try {
			connectionSource = new JdbcConnectionSource("jdbc:mysql://localhost:3306/"+DATABASE_URL,"root","mysql");
			//se configura la base de datos pasándoloe la conexión creada
			setupDatabase(connectionSource);
			//se lee y escriben datos
			readWriteData();
			System.out.println("\n\nIt seems to have worked\n\n");
		} finally {
			//se elimina la fuente de datos 
			if (connectionSource != null) {
				connectionSource.close();
			}
		}
	}
	private void setupDatabase(ConnectionSource connectionSource) throws Exception {
		//se inicializan los DAOs anteriormente creados, pasándoles las conexión a MySQL Workbench y el .class de la clase en específico
		accountDao = DaoManager.createDao(connectionSource, Account.class);
		orderDao = DaoManager.createDao(connectionSource, Order.class);

		//si se necesitase crear la tabla, se llama a los siguientes métodos
		/*TableUtils.createTable(connectionSource, Account.class);
		TableUtils.createTable(connectionSource, Order.class);*/
	}
	private void readWriteData() throws Exception {
		//se crea una instancia de la clase Account, a la cual se le pasa el nombre creado
		String name = "Buzz Lightyear";
		Account account = new Account(name);
		//el objeto Account persiste en la base de datos
		accountDao.create(account);
		//se crea un objeto de la clase Order para la clase Account
		int quantity1 = 2;
		int itemNumber1 = 21312;
		float price1 = 12.32F;
		Order order1 = new Order(account, itemNumber1, price1, quantity1);
		orderDao.create(order1);
		//se crea otro objeto similar al anterior
		int quantity2 = 1;
		int itemNumber2 = 785;
		float price2 = 7.98F;
		Order order2 = new Order(account, itemNumber2, price2, quantity2);
		orderDao.create(order2);
		//se construye una consulta usando QueryBuilder
		QueryBuilder<Order, Integer> statementBuilder = orderDao.queryBuilder();
		//debe encontrar ambos objetos Order
		//ORMLite extre el id de Account para la consulta automáticamente
		statementBuilder.where().eq(Order.ACCOUNT_ID_FIELD_NAME, account);
		List<Order> orders = orderDao.query(statementBuilder.prepare());
	}
}
