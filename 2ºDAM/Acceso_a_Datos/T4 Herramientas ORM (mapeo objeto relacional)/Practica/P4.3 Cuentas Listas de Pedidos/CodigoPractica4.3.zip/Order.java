package ormlite3;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 * ejemplo de objeto de la clase Order que es persistente gracias al DAO
 */
@DatabaseTable(tableName = "orders")
public class Order {
	//se crea una variable estática y constante el cual es el id de Account
	public static final String ACCOUNT_ID_FIELD_NAME = "account_id";
	//se crea una variable id solo si generateId es verdadero
	@DatabaseField(generatedId = true)
	private int id;
	//se crea una instancia de Account si foreign es verdadero y la variable nombre de columna es igual a la variable anteriormente creada
	@DatabaseField(foreign = true, columnName = ACCOUNT_ID_FIELD_NAME)
	private Account account;
	//se crean tres variables enteras y float (las cuales se pasaran a la hora de crear objetos Order en ForeignMain)
	@DatabaseField
	private int itemNumber;
	@DatabaseField
	private int quantity;
	@DatabaseField
	private float price;
	//todas las clases persistentes deben definir un constructor vacío
	Order() {}
	//se crea un constructor con las variables anteriormente creadas
	public Order(Account account, int itemNumber, float price, int quantity) {
		this.account = account;
		this.itemNumber = itemNumber;
		this.price = price;
		this.quantity = quantity;
	}
	//se crean los getters y setters de las variables
	public int getId() {
		return id;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public int getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(int itemNumber) {
		this.itemNumber = itemNumber;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
}
