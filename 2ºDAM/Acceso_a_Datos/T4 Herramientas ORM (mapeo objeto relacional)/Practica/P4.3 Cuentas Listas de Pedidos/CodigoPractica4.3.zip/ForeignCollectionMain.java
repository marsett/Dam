package ormlite3;

import java.util.List;

import com.j256.ormlite.dao.CloseableIterator;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.dao.ForeignCollection;
import com.j256.ormlite.jdbc.JdbcConnectionSource;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

public class ForeignCollectionMain {
	//se crea la variable que almacenará el nombre de la base de datos, siendo esta de MySQL
	private final static String DATABASE_URL = "dpruebaTres";
	//se crean las variables de tipo Dao, cuyo tipado es de las otras clases (Account y Order)
	private Dao<Account, Integer> accountDao;
	private Dao<Order, Integer> orderDao;
	public static void main(String[] args) throws Exception {
		//se llama al método doMain, pasándole como parámetro los argumentos
		new ForeignCollectionMain().doMain(args);
	}
	private void doMain(String[] args) throws Exception {
		JdbcConnectionSource connectionSource = null;
		try {
			//dentro de este método, se crea la conexión, a la cual se le pasa la url de conexion a MySQL junto con la variable anteriormente creada que almacenaba el nombre de la base de datos
			connectionSource = new JdbcConnectionSource("jdbc:mysql://localhost:3306/"+DATABASE_URL,"root","mysql");
			//se llama al método que configura la base de datos y pasa esta conexión como parámetro
			setupDatabase(connectionSource);
			//se llama al método que lee y escribe datos
			readWriteData();
			System.out.println("\n\nIt seems to have worked\n\n");
		} finally {
			//se elimina la fuente de datos
			if (connectionSource != null) {
				connectionSource.close();
			}
		}
	}
	private void setupDatabase(ConnectionSource connectionSource) throws Exception {
		//método donde se inicializan las variables llamando al método createDao, pasando como parámetro la conexión creada y el .class predefinido
		accountDao = DaoManager.createDao(connectionSource, Account.class);
		orderDao = DaoManager.createDao(connectionSource, Order.class);
		//si se necesita crear la tabla (solo la primera ejecución del programa)
		TableUtils.createTable(connectionSource, Account.class);
		TableUtils.createTable(connectionSource, Order.class);
	}
	private void readWriteData() throws Exception {
		//se crea una instancia de la clase Account pasando por parámetro el nombre creado
		String name = "Buzz Lightyear";
		Account account = new Account(name);
		//con el metodo create, el objeto Account persiste en la base de datos
		accountDao.create(account);
		//se crea un objeto Order asociado con Account, pasando por parámetro las variables creadas
		int quantity1 = 2;
		int itemNumber1 = 21312;
		float price1 = 12.32F;
		Order order1 = new Order(account, itemNumber1, price1, quantity1);
		orderDao.create(order1);
		//se crea otro objeto Order
		int quantity2 = 1;
		int itemNumber2 = 785;
		float price2 = 7.98F;
		Order order2 = new Order(account, itemNumber2, price2, quantity2);
		orderDao.create(order2);
		//se crea una variable que recoge el id del objeto de la clase Account determinada
		Account accountResult = accountDao.queryForId(account.getId());
		//esta variable resultado, se le pasa el metodo para recoger los objetos Order y alamcenarlos en una colección de tipo Order
		ForeignCollection<Order> orders = accountResult.getOrders();
		//se comprueban las operaciones
		CloseableIterator<Order> iterator = orders.closeableIterator();
		try {
			Order order = iterator.next();
			order = iterator.next();
		} finally {
			iterator.close();
		}
		//se crea un tercer objeto de tipo Order con variables diferentes
		int quantity3 = 50;
		int itemNumber3 = 78315;
		float price3 = 72.98F;
		Order order3 = new Order(account, itemNumber3, price3, quantity3);
		//creado el objeto, se añade a la colección anterior
		orders.add(order3);
		//en una variable de tipo List, se consultan los objetos Order
		List<Order> orderList = orderDao.queryForAll();
	}
}
