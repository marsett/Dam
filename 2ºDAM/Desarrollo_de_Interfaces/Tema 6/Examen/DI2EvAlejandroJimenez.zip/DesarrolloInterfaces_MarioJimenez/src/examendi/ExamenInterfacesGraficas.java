package examendi;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

public class ExamenInterfacesGraficas extends JFrame{
	private JPanel panelIzquierdo, panelDerechoSuperior, panelDerechoInferior;
	private JLabel etiquetaDrives, etiquetaCarpetas; 
	private JComboBox<String> listaDrives, listaCarpetas;
	private static DefaultMutableTreeNode root;
	private DefaultTreeModel model;
	public static void main(String[] args) {
		new ExamenInterfacesGraficas();
	}
	public ExamenInterfacesGraficas() {
		super("Examen DAM Interfaces Graficas");
		crearInterfaz();
	}
	private void crearInterfaz() {
		System.out.println("Creando Interfaz...");
		etiquetaDrives=new JLabel("Drive");
		etiquetaCarpetas=new JLabel("Carpetas en la raiz");
		
		panelIzquierdo=new JPanel(new FlowLayout());
		panelIzquierdo.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		panelDerechoSuperior=new JPanel(new FlowLayout());
		panelDerechoSuperior.setBorder(BorderFactory.createLineBorder(Color.GREEN));
		panelDerechoInferior=new JPanel(new FlowLayout());
		panelDerechoInferior.setBorder(BorderFactory.createLineBorder(Color.RED));
		BoxLayout boxLayoutIzquierdo=new BoxLayout(panelIzquierdo, BoxLayout.Y_AXIS);
		panelIzquierdo.setLayout(boxLayoutIzquierdo);
		/*panelDerechoSuperior.setLayout(new FlowLayout());
		panelDerechoInferior.setLayout(new FlowLayout());*/
		add(panelIzquierdo);
		add(panelDerechoSuperior);
		add(panelDerechoInferior);
		
		JSplitPane splitPaneVertical=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,panelDerechoSuperior,panelDerechoInferior);
		JSplitPane splitPaneHorizontal=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,panelIzquierdo,splitPaneVertical);
		
		/*splitPaneVertical.setOneTouchExpandable(true);
		splitPaneVertical.setDividerLocation(100);
		add(splitPaneVertical,BorderLayout.WEST);*/
		
		splitPaneHorizontal.setOneTouchExpandable(true);
		splitPaneHorizontal.setDividerLocation(370);
		add(splitPaneHorizontal,BorderLayout.CENTER);
		
		
		
		
		
		listaDrives=new JComboBox<String>();
		for(File fichero:getDrives()) {
			listaDrives.addItem(fichero.toString());
		}
		panelIzquierdo.add(etiquetaDrives);
		panelIzquierdo.add(listaDrives);
		
		listaCarpetas=new JComboBox<String>();
		for(File fichero:getCarpetas()) {
			listaCarpetas.addItem(fichero.toString());
		}
		panelIzquierdo.add(etiquetaCarpetas);
		panelIzquierdo.add(listaCarpetas);
		
		listaCarpetas.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				String seleccionado=(String)listaCarpetas.getSelectedItem();
				String carpetaSeleccionada=null;
				JComboBox<String> comboBox=(JComboBox<String>)(e.getSource());
				if(e.getStateChange()==ItemEvent.SELECTED) {
					carpetaSeleccionada=(String)comboBox.getSelectedItem();
					System.out.println("Seleccionado: "+seleccionado+" carpeta: "+carpetaSeleccionada);
					panelDerechoSuperior.add(crearPanel(carpetaSeleccionada));
					
				}
			}
			
		});
		
		setSize(1000,500);
		setVisible(true);
		System.out.println("Interfaz creada");
	}
	public JScrollPane crearPanel(String carpetaSeleccionada) {
		String drive=null;
		for(File fichero:getCarpetas()) {
			drive=fichero.toString();
		}
		root=new DefaultMutableTreeNode(drive);
		model=new DefaultTreeModel(root);
		JTree arbol=new JTree(model);
		
		getFicheros(carpetaSeleccionada);
		
		JScrollPane scroll=new JScrollPane(arbol);
		getContentPane().add(scroll);
		revalidate();
		repaint();
		return scroll;
	}
	public void getFicheros(String carpeta) {
		DefaultMutableTreeNode nodoHijo=new DefaultMutableTreeNode(carpeta);
		File nietos=null;
		File[] listaCarpeta;
		for(File fichero:getCarpetas()) {
			 nietos=fichero;
		}
		listaCarpeta=nietos.listFiles();
		for(File directoriosFicheros:listaCarpeta) {
			DefaultMutableTreeNode nodoNieto=new DefaultMutableTreeNode(directoriosFicheros);
			nodoHijo.add(nodoNieto);
		}
		root.add(nodoHijo);
	}
	public File[] getDrives() {
		File[] listaDrives=File.listRoots();
		for(int i=0; i<listaDrives.length; i++) {
			System.out.println(listaDrives[i]);
		}
		return listaDrives;
	}
	public File[] getCarpetas() {
		String drive=null;
		for(File fichero:getDrives()) {
			drive=fichero.toString();
		}
		File raiz=new File(drive);
		File[] listaCarpetas=raiz.listFiles();
		for(int i=0; i<listaCarpetas.length; i++) {
			System.out.println(listaCarpetas[i]);
		}
		return listaCarpetas;
	}
	
}
