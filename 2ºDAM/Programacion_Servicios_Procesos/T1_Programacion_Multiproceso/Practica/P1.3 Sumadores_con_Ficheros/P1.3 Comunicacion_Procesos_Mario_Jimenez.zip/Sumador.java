package multiproceso;

public class Sumador {
	
	/*Basicamente, en este programa se realiza un metodo sumar, el cual pasa por
	 *parametros dos enteros, a los cuales se les hace una condicion para que, si
	 *el primer numero es mayor que el segundo, estos se intercambien y el primer numero
	 *sea el menor de los dos. Se hace un for para realizar la suma y, finalmente, el
	 *metodo retorna esta suma*/

	public static int sumar(int n1, int n2) {
		
		int suma = 0;
		if (n1 > n2) {
			int aux = n1;
			n1 = n2;
			n2 = aux;
		}
		for (int i = n1; i <= n2; i++) {
			suma = suma + i;
		}
		return suma;
	}
	
	/*en el main simplemente se llama por argumentos a los dos valores de la suma, se crea una
	 * variable para llamar al metodo anterior y se imprime la suma, el resultado*/

	public static void main(String[] args) {
		int n1 = Integer.parseInt(args[0]);
		int n2 = Integer.parseInt(args[1]);
		int suma = sumar(n1, n2);
		System.out.println(suma);
		System.out.flush();
	}
}
