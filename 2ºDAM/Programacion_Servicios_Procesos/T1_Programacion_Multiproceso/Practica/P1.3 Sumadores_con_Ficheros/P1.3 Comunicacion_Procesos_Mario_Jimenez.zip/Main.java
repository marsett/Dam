package multiproceso;

import java.io.*;

public class Main {
	
	/*este programa tiene como objetivo lanzar el proceso de sumar a partir de otra clase
	 * primero, se declaran dos variables estaticas: la primera, recogera el numero de procesos;
	 * la segunda, que nombre comun tendran los ficheros*/
	
	static final int NUM_PROCESOS = 4;
	static final String PREFIJO_FICHEROS ="fich";
	
	/*se crea un metodo que lanza el sumador: se pasa por parametros los dos numeros de la suma en cuestion y
	 * un string que sera un file que recoja los resultados
	 * Se crea un string comando que llamara a la clase Sumador a traves del package (que es el mismo para el Sumador
	 * y el Main)
	 * Se crea un directorioSumador, de tipo File, que llamara a la carpeta bin (donde estan los .class)
	 * Se crea el fichResultado, de tipo File, que coge por parametro el String anterior que recogia los resultados
	 * Se crea un objeto del tipo ProcessBuilder, pasando "java" ,el comando y los dos numeros de la suma (pasandolos como string)
	 * Se redirige el contenido del fichero y comienza el proceso*/

	public static void lanzarSumador(int n1, int n2, String fichResultados) throws IOException {
		String comando;
		comando = "multiproceso.Sumador";
		File directorioSumador;
		directorioSumador = new File("bin\\");
		File fichResultado = new File(fichResultados);
		ProcessBuilder pb;
		pb = new ProcessBuilder("java", comando, String.valueOf(n1), String.valueOf(n2));
		pb.redirectError(new File ("error.txt"));
		pb.directory(directorioSumador);
		pb.redirectOutput(fichResultado);
		pb.start();
	}
	
	/*se crea un metodo que consigue introducir el resultado en el fichero: se pasa por parametro un String
	 * nombreFichero
	 * Se crea un FileInputStream, pasando por parametro nombreFichero
	 * lo mismo ocurre con el InputStreamReader (para leerlo) y el BufferedReader, linealmente
	 * Lo que haya dentro, se almacena en el String linea, el cual se convertira a Integer con la variable suma
	 * Este metodo devuelve la suma; tambien se manejan excepciones, por si algun paso esta mal hecho*/

	public static int getResultadoFichero(String nombreFichero) {
		int suma = 0;
		try {
			FileInputStream fichero = new FileInputStream(nombreFichero);
			InputStreamReader fir = new InputStreamReader(fichero);
			BufferedReader br = new BufferedReader(fir);
			String linea = br.readLine();
			br.close();
			suma = Integer.valueOf(linea);
			return suma;
		} catch (FileNotFoundException e) {
			System.out.println("No se pudo abrir " + nombreFichero);
		} catch (IOException e) {
			System.out.println("No hay nada en " + nombreFichero);
		}
		return suma;
	}
	
	/*este metodo devuelve la suma total hecha entre todos los ficheros que intervengan en el programa
	 * Se declara una variable sumaTotal que, con un bucle for, sera igual a lo que devuelva el metodo anterior
	 * getResultadofichero*/

	public static int getSumaTotal(int numFicheros) {
		int sumaTotal = 0;
		for (int i = 1; i <= NUM_PROCESOS; i++) {
			sumaTotal += getResultadoFichero("Ficheros\\"+PREFIJO_FICHEROS + String.valueOf(i));
		}
		return sumaTotal;
	}

	/*el main del programa recibira por argumentos dos valores y, a traves de un algoritmo, se realiza la 
	 *suma de los valores comprendidos entre estos dos parametros
	 *Con un for, por cada fichero, se realiza la suma con salto, la cual se consigue llamando al n1 y sumandole el salto,
	 *Se lanza el sumador con este ultimo resultado, ademas de la ruta y de llamar a los ficheros a los que hacerles la suma total
	 *Se termina imprimiendo la sumaTotal, la cual se consigue finalmente llamando al metodo getSumaTotal*/
	
	public static void main(String[] args) throws IOException, InterruptedException {
		int n1 = Integer.parseInt(args[0]);
		int n2 = Integer.parseInt(args[1]);
		int salto = (n2 / NUM_PROCESOS) - 1;
		for (int i = 1; i <= NUM_PROCESOS; i++) {
			System.out.println("n1:" + n1);
			int resultadoSumaConSalto = n1 + salto;
			System.out.println("n2:" + resultadoSumaConSalto);
			lanzarSumador(n1, n1 + salto, "Ficheros\\"+PREFIJO_FICHEROS + String.valueOf(i));
			n1 = n1 + salto + 1;
			System.out.println("Suma lanzada...");
		}
		Thread.sleep(200);
		int sumaTotal = getSumaTotal(NUM_PROCESOS);
		System.out.println("La suma total es: " + sumaTotal);
		
		try {
			 File f = new File("C:\\Users\\jimen\\OneDrive\\Documentos\\programa.txt");
			 if (f.createNewFile()) {
				 System.out.println("File created");
			 }
			 else {
				 System.out.println("File already exists");
			 }
			 f.delete();
		}
		catch (Exception e) {
			 System.err.println(e);
		}
	}
}
