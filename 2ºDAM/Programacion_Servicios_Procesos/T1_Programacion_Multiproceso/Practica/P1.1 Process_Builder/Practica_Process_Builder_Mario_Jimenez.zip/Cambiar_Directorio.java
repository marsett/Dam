package ejemplos;
import java.io.*;

public class Cambiar_Directorio {
	public static void main(String[] args) throws IOException{
		
		/*Este programa trata de establecer el directorio raiz como directorio de trabajo del 
		 * ProcessBuilder. Se crea el objeto de la clase ProcessBuilder y, en otra variable,
		 * se retorna con un getProperty el valor string del usuario*/
		
		var usuario_home=System.getProperty("user.home");
		var proceso=new ProcessBuilder();
		
		/*Con el metodo command, se invoca al cmd y el comando a ejecutar. Dentro del comando
		 * directory, se crea un file con la variable que devolvia el usuario*/
		
		proceso.command("cmd.exe","/c","dir");
		proceso.directory(new File(usuario_home));
		
		/*Se crea una variable para comenzar a ejecutar el proceso y, con un BufferedReader un 
		 * InputStreamReader y un bucle while, se consigue sacar por pantalla leyendo el contenido
		 * al ejecutar dir en el cmd */
		
		var process=proceso.start();
		try (var reader=new BufferedReader(new InputStreamReader(process.getInputStream()))){
			String line;
			while((line=reader.readLine())!=null) {
				System.out.println(line);
			}
		}
	}
}
