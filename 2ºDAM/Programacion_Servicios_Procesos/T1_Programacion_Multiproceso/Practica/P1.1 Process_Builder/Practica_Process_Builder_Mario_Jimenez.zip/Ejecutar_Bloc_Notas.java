package process_builder_ejemplos;
import java.io.*;

public class Ejecutar_Bloc_Notas {
	public static void main(String[] args) throws IOException, InterruptedException{
		
		/*Este pequeño programa trata de que, al ser ejecutado, abra el bloc de notas 
		 * automáticamente. Para ello, se crea un objeto perteneciente a la clase
		 * ProcessBuilder, la cual maneja una coleccion de procesos. */
		
		var ejecucion=new ProcessBuilder();
		
		/*Despues, con este objeto se invoca al metodo command(), el cual crea un nuevo
		 * proceso, el cual es, en este caso, ejecutar el bloc de notas.
		 * Con el metodo start(), empieza este nuevo proceso*/
		
		ejecucion.command("notepad.exe");
		var comienzo= ejecucion.start();
		
		/*Con el metodo waitFor(), se hace que el subproceso actual espere hasta que termine
		 * el proceso representado por el objeto Process. Ademas, retorna un codigo %d al finalizar
		 * la ejecucion*/
		
		var esperar=comienzo.waitFor();
		System.out.printf("El programa se cerro con el codigo: %d",esperar);
		
	}
}
