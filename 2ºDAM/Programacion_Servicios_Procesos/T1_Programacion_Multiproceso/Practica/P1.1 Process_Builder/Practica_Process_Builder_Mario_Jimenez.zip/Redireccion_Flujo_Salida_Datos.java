package process_builder_ejemplos;
import java.io.*;

public class Redireccion_Flujo_Salida_Datos {
	public static void main(String[] args) throws IOException{
		
		/*En este programa se redirige el flujo de salida de datos a un fichero a crear
		 * Para ello, se retorna en una variable el valor del usuario y se instancia una variable
		 * de la clase ProcessBuilder*/
		
		var directorio_home=System.getProperty("user.home");
		var ejecucion=new ProcessBuilder();
		
		/*Con esa clase del ProcessBuilder, se invoca al método command, con el cual se llama
		 * al cmd y se especifica el comando a ejecutar. Luego se crea un fichero, dentro del
		 * cual se introduce un String.format, donde especificamos dónde guardar el fichero
		 * y el usuario. Después, se redirige el flujo de salida del fichero con redirectOutput*/
		
		ejecucion.command("cmd.exe","/c","date /t");
		var fichero=new File(String.format("%s/Documents/output.txt", directorio_home));
		ejecucion.redirectOutput(fichero);
		
		/*Con start empieza el proceso; por último, se redirige la salida del proceso al fichero*/
		
		var comienzo=ejecucion.start();
		try (var br=new BufferedReader(new InputStreamReader(comienzo.getInputStream()))){
			String frase;
			while((frase=br.readLine())!=null) {
				System.out.println(frase);
			}
		}
	}
}
