package process_builder_ejemplos;

public class Doble_Ejecucion {
	public static void main(String[] args) throws Exception{
		
		/*Este ejemplo trata de ejecutar dos archivos de texto, a partir del bloc de notas.
		 * Para ello, se crean dos objetos de la clase ProcessBuilder, dentro de los cuales
		 * se establece el programa a ejecutar y la ruta del fichero el cual abrir*/
		
		System.out.println("Los dos procesos comienzan sincronizados");
		var fichero1=new ProcessBuilder("notepad.exe","C:\\Users\\jimen\\OneDrive\\Documentos\\fichero1.txt");
		var fichero2=new ProcessBuilder("notepad.exe","C:\\Users\\jimen\\OneDrive\\Documentos\\fichero2.txt");
		
		/*Con el metodo start(), se inician los procesos, y con el waitFor(), se espera que el proceso
		 * termine para empezar a ejecutar el subproceso*/
		
		Process proceso1=fichero1.start();
		Process proceso2=fichero2.start();
		proceso1.waitFor();
		proceso2.waitFor();
		System.out.println("Espera hasta que ambos procesos se hayan completado");
		
	}
}
