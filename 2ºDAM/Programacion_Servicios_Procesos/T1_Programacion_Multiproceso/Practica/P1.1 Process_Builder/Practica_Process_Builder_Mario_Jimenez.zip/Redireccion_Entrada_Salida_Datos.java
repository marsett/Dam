package process_builder_ejemplos;
import java.io.*;

public class Redireccion_Entrada_Salida_Datos {
	public static void main(String[] args)throws IOException{
		
		/*En este programa, se pide redirigir la entrada y salida de datos, partiendo
		 * de los datos del fichero input.txt. Se crea una variable de la clase 
		 * ProcessBuilder. Con esta variable, se llama al método command, en el cual
		 * se introduce el comando cat. Seguido de esto, se llama a redirectInput para
		 * crear un nuevo file, con una ruta específica y el archivo antes creado;
		 * luego, con redirectOutput, se hace lo mismo, pero redirigiendo al fichero 
		 * output.txt*/
		
		var ejecucion=new ProcessBuilder();
		ejecucion.command("cat").redirectInput(new File("/home/mario/","input.txt"))
		.redirectOutput(new File("/home/mario/","output.txt")).start();
		
	}
}
