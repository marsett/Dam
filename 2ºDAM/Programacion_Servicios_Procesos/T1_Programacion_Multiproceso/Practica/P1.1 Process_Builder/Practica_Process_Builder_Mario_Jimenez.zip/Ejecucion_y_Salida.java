package process_builder_ejemplos;
import java.io.*;

public class Ejecucion_y_Salida {
	public static void main(String[] args) throws IOException {
		
		/*En este caso, el objetivo del programa es mostrar por consola el calendario
		 * especificado. Se crea un objeto de la clase ProcessBuilder, el cual va a llamar
		 * al metodo command, el cual crea un nuevo proceso. Cuenta con el programa a ejecutar y
		 * sus parametros de ejecucion */
		
		var ejecucion = new ProcessBuilder();
		ejecucion.command("cal", "2022", "-m 12");
		
		/*Se llama al metodo start para comenzar el proceso con los parametros antes comentados*/
		
		var comienzo = ejecucion.start();
		
		/*Entonces, para mostrar el resultado por consola, se crea un bufferedreader, dentro del cual
		 * se crea un inputstreamreader, con el cual conectar el flujo de entrada del proceso "comienzo"
		 * con el metodo getinputstream. Por ultimo, el while permite leer el resultado del proceso,
		 * lo cual es el calendario del mes y ano especificado*/
		
		try (var br = new BufferedReader(new InputStreamReader(comienzo.getInputStream()))) {
			String frase;
			while ((frase = br.readLine()) != null) {
				System.out.println(frase);
			}
		}
	}
}
