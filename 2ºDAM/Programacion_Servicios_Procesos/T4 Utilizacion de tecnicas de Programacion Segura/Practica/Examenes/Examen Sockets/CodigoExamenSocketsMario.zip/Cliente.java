package examen;
import java.io.*;
import java.net.*;
import java.util.*;
 
public class Cliente {
    public static void main(String[] args) {
    	//Clase Cliente TCP/IP
    	//se crean las variables a utilizar en el programa
        String direccion="127.0.0.1";
        int numeroPuerto=5000;
        DataInputStream in;
        DataOutputStream out;
        Scanner entrada=new Scanner(System.in);
        try {
            //dentro de un bloque try-catch, se crea el Socket que recoge la dirección IP y el número de puerto
            Socket sc = new Socket(direccion, numeroPuerto);
            //con este método se establece un tiempo de espera: si no llega una respuesta, saldrá un mensaje de error
            sc.setSoTimeout(5000);
            //se inicializan los inputs que recogen y envían la información
            in = new DataInputStream(sc.getInputStream());
            out = new DataOutputStream(sc.getOutputStream());
            //se lee la petición recogida del servidor
            String peticion=in.readUTF();
            System.out.println("La peticion es "+peticion);
            //dependiendo de cual sea la petición, se mostrará en pantalla una información recibida u otra
            if(peticion.equalsIgnoreCase("IP")) {
	            String leerBienvenida = in.readUTF();
	            System.out.println("El mensaje de bienvenida es: "+leerBienvenida);
	            String leerIpServidor = in.readUTF();
	            System.out.println("La IP del servidor es: "+leerIpServidor);
            
            }else{
            	String fechaHoraRecibida=in.readUTF();
            	System.out.println("La fecha y hora del servidor es: "+fechaHoraRecibida);
            }
            //se cierran el Scanner y el Socket
            entrada.close();
            sc.close();
        }catch (IOException e) {
        	System.out.println(e.getMessage());
        } 
    }
}
