package examen;
import java.io.*;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.*;

public class ClaseUnoUno {
	public static void main(String[] args) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException  {
		//se crea el cifrador RSA perteneciente a la clase Cipher
		Cipher cifradorRsa;
		//se generan el par de claves RSA
		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
		KeyPair keyPair = keyPairGenerator.generateKeyPair();
		//se guardan el par de claves pública y privada en variables
		PublicKey publicKey = keyPair.getPublic();
		PrivateKey privateKey = keyPair.getPrivate();
		//se imprimen por pantalla el formato de las dos claves
		System.out.println("La clave pública es "+publicKey.getFormat());
		System.out.println("La clave privada es "+privateKey.getFormat());
		//se establece el tipo de cifrado (por parámetro se establece el cifrado RSA)
	    cifradorRsa = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	    //se escribe la ruta del fichero cuyo contenido va a ser codificado
		String ficheroTexto="C:\\Users\\jimen\\Downloads\\mensaje texto.txt";
		String contenido=null;
		try {
			//se crea el objeto de tipo File que va a recoger por parámetro la ruta insertada
			File f=new File(ficheroTexto);
			//se crea el FileReader y BufferedReader encargados de leer el contenido del fichero
			FileReader fr=new FileReader(f);
			BufferedReader br=new BufferedReader(fr);
			//dentro del bucle que lee el contenido, se hará el cifrado y descifrado
			while((contenido=br.readLine())!=null) {
				//cada línea se almacena en otro String diferente
				String texto=contenido;
				cifradorRsa.init(Cipher.ENCRYPT_MODE, publicKey);
				//se almacena en un array de bytes la información del fichero
				byte[] encriptado = cifradorRsa.doFinal(texto.getBytes());
				System.out.print("Encriptado-> ");
				 //por cada byte guardado, se realiza una conversión hexadecimal
				for (byte b : encriptado) {
			    	System.out.print(Integer.toHexString(0xFF & b));
			    }
				//se imprime el texto encriptado (la colección de bytes)
			    System.out.println("\nEl texto encriptado es: "+encriptado.toString());
			    cifradorRsa.init(Cipher.DECRYPT_MODE, privateKey);
			    //en otro array de bytes, se almacena la información desencriptada
			    byte[] bytesDesencriptados = cifradorRsa.doFinal(encriptado);
			    //se muestra el array de bytes, convirtiéndose a String
			    String textoDesencripado = new String(bytesDesencriptados);
			  //se imprime por pantalla cada línea desencriptada del fichero
			    System.out.println("El texto desencriptado es: "+textoDesencripado);
			}
			br.close();
		}catch (FileNotFoundException e1) {
			System.out.println(e1.getMessage());
		}catch (IOException e2) {
			System.out.println(e2.getMessage());
		}
	}
}