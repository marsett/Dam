package examen;
import java.security.*;
import java.util.Scanner;
import org.apache.commons.codec.binary.Hex;

public class ClaseDosUno {
	public static void main(String[] args) {
		//se crean dos métodos: el primero, muestra el hash del fichero original
		//el segundo gestiona el hash del fichero insertado y el mensaje final
		System.out.print("ALGORITMO HASH SHA-512-> ");
		hash();
		hashNuevo(hash());
	}
	public static String hash() {
		//a partir de la clase MessageDigest, se gestiona la creación de hash
		MessageDigest md = null;
		String fichero="C:\\Users\\jimen\\Downloads\\mensaje texto.txt";
		char[] hash=null;
		try {
			//se llama al método getInstance, con el algoritmo elegido
			md=MessageDigest.getInstance("SHA-512");
			//se llama al método actualizar, consiguiendo los bytes del fichero
			md.update(fichero.getBytes());
			byte[] mb=md.digest(fichero.getBytes());
			hash=Hex.encodeHex(mb);
			//se imprime el hash finalmente creado
			System.out.println(Hex.encodeHex(mb));
		}catch(NoSuchAlgorithmException e) {
			System.out.println(e.getMessage());
		}
		return String.valueOf(hash);
	}
	public static void hashNuevo(String hash) {
		//se guarda en una variable el hash creado por el anterior método
		String hashTextoDado=hash;
		System.out.print("El hash original es-> ");
		System.out.println(hashTextoDado);
		//se siguen los mismos pasos que en el anterior método para crear el hash del fichero introducido
		char[] hashNuevo=null;
		Scanner entrada=new Scanner(System.in);
		System.out.println("Introduce el fichero, para saber si el hash es el mismo o no");
		MessageDigest md = null;
		String fichero=entrada.nextLine();
		try {
			md=MessageDigest.getInstance("SHA-512");
			md.update(fichero.getBytes());
			byte[] mb=md.digest(fichero.getBytes());
			hashNuevo=Hex.encodeHex(mb);
			System.out.print("El hash nuevo es-> ");
			System.out.println(Hex.encodeHex(mb));
			//lo único nuevo es que se comparan las cadenas (el hash original y el nuevo)
			//saldrá un mensaje u otro dependiendo de si es el mismo hash
			if(hashTextoDado.equals(String.valueOf(hashNuevo))) {
				System.out.println("Es el mismo fichero. Coinciden los hashs");
			}else {
				System.out.println("Son ficheros diferentes");
			}
		}catch(NoSuchAlgorithmException e) {
			System.out.println(e.getMessage());
		}
	}
}
