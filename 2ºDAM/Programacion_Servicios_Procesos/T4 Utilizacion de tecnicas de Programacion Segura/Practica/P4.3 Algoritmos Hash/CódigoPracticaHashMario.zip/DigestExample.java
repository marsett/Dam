package hash;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import org.apache.commons.codec.binary.Hex;

public class DigestExample {
	public static void main(String[] args) {
		//se crean las variables a utilizar en el programa
		//se crea un objeto MessageDigest, el cual permite "digerir" un mensaje
		MessageDigest md = null;
		//se crea un objeto Scanner, el cual permite escribir una contraseña en la variable String declarada
		Scanner entrada=new Scanner(System.in);
		System.out.println("Escribe una password cualquiera:");
		String password=entrada.nextLine();
		//bloque try-catch para el manejo de excepciones
		try {
			//en primer lugar, se crea el algoritmo hash SHA-512
			//se inicializa el objeto MessageDigest con el método getInstance, estableciendo como String el nombre del algoritmo hash
			md=MessageDigest.getInstance("SHA-512");
			//se actualiza este objeto con la cadena establecida por consola anteriormente
			md.update(password.getBytes());
			//el objeto MessageDigest se "digiere" dentro de un array de bytes
			byte[] mb=md.digest();
			//se imprime por pantalla cómo queda el algoritmo SHA-512
			System.out.print("ALGORITMO HASH SHA-512-> ");
			System.out.println(Hex.encodeHex(mb));
			//con el algoritmo SHA-1, al igual que en el anterior, se llama al método getInstance con el nombre del algoritmo
			md=MessageDigest.getInstance("SHA-1");
			//se actualiza el objeto MessageDigest con la cadena establecida por consola
			md.update(password.getBytes());
			//se digiere el objeto dentro del array de bytes
			mb=md.digest();
			//se imprime el resultado
			System.out.print("ALGORITMO HASH SHA-1-> ");
			System.out.println(Hex.encodeHex(mb));
			//con el algoritmo MD5 también se llama al método getInstance y se hace lo mismo que en los casos anteriores
			md=MessageDigest.getInstance("MD5");
			//se actualiza el objeto MessageDigest con la cadena establecida por consola
			md.update(password.getBytes());
			//se digiere el objeto dentro del array de bytes
			mb=md.digest();
			//se imprime el resultado
			System.out.print("ALGORITMO HASH MD5-> ");
			System.out.println(Hex.encodeHex(mb));
			//se realiza el mismo procedimiento que en el algoritmo SHA-256
			md=MessageDigest.getInstance("SHA-256");
			md.update(password.getBytes());
			byte[] mc=md.digest();
			//se imprime el resultado
			System.out.print("ALGORITMO HASH SHA-256-> ");
			System.out.println(Hex.encodeHex(mc));
		}catch(NoSuchAlgorithmException e) {
			System.out.println(e.getMessage());
		}
		entrada.close();
	}
}