package socketsSL;
import java.io.*;
import java.net.*;

public class Servidor {
	public static void main(String[] args) {
		try {
			//se crea el socket pasando en el constructor el puerto
			ServerSocket socket=new ServerSocket(5000);
			//bucle infinito
				while(true) {
					//se espera a recibir la peticion de un cliente
					Socket socketEnEspera = socket.accept();
					//se imprime quien se ha conectado
					System.out.println("Se ha conectado el usuario cuya direccion IP es "+socketEnEspera.getInetAddress());
					//se invoca e inicia el hilo que llama a la clase ClienteHiloMensajes
					Thread hilo=new Thread(new ClienteHiloMensajes(socketEnEspera));
					hilo.start();
				}
		}catch(IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
