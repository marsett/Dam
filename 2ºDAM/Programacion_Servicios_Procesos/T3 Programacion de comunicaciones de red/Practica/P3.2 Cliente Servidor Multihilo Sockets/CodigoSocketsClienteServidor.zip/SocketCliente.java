package socketsSL;
import java.io.*;
import java.net.*;
import java.util.*;

public class SocketCliente {
	//se declaran las variables a utilizar dentro del main
	static Scanner entrada;
	static String nombre, envio;
	public static void main(String[] args) {
		entrada=new Scanner(System.in);
		try {
			//a traves de scanner se introduce el nombre del Cliente
			System.out.println("Introduce tu Nombre");
			nombre=entrada.nextLine();
			//el socket se conecta al localhost con el mismo puerto que en el Servidor
			Socket socket=new Socket("127.0.0.1", 5000);
			while (socket.isConnected()) {
				//se escribe el mensaje y se envia a la clase Servidor
				DataOutputStream dos=new DataOutputStream(socket.getOutputStream());
				envio=entrada.nextLine();
				dos.writeUTF(nombre+": "+envio);
				//ademas se imprime para ver el contenido del mensaje
				DataInputStream dis = new DataInputStream(socket.getInputStream());
				String recibido = dis.readUTF();
				System.out.println("El mensaje enviado por "+nombre+" es: "+recibido);
			}
			//se cierran las conexiones
			socket.close();
			entrada.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
