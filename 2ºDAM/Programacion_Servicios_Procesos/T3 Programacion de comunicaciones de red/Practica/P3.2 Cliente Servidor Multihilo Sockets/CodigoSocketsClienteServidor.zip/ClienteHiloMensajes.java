package socketsSL;
import java.io.*;
import java.net.*;

public class ClienteHiloMensajes implements Runnable{
	//en primer lugar se declaran las variables a utilizar dentro del programa
	private boolean conexion=true;
	private Socket socket;
	private DataInputStream dis;
	private DataOutputStream dos;
	private String mensajeRecibido;
	//se crea el getter y setter perteneciente a la variable mensajeRecibido
	public String getMensajerecibido(){
		return mensajeRecibido;
	}
	public void setMensajeRecibido(String mensajeRecibido){
		this.mensajeRecibido=mensajeRecibido;
	}
	//se crea un método el cual permite leer el mensaje recibido
	public void leerMensaje() {
		try {
			//se lee con el DataInputStream
			mensajeRecibido = dis.readUTF();
			String mensaje="";
			//se crea un bucle for y un condicional if con el objetivo de que, si el usuario
			//inserta dos puntos, se cree un espacio
				for(int i=0;i<mensajeRecibido.length();i++) {
					if(mensajeRecibido.charAt(i)==':') {
						mensaje=mensajeRecibido.substring(i+1).trim() ;
					}
				}
			System.out.println("El mensaje recibido es: "+mensaje);
			//en el switch se indica que, si se recibe el mensaje Adios, en todas
			//sus formas posibles, se desconectara del servidor
				switch (mensaje) {
				case "ADIOS":
					conexion=false;
				break;
				case "Adios":
					conexion=false;
					break;
				case "adios":
					conexion=false;
					break;
				}
			System.out.println(mensajeRecibido);
		}catch (IOException e) {
			System.out.println(e.getMessage());
			cerrarSocket();
		}
	}
	//este metodo simplemente escribe en el DataOutputStream el texto recibido
	public void escribirLinea(String textoRecibido) {
		try {
			dos.writeUTF(textoRecibido);
		}catch (IOException e) {
			System.out.println(e.getMessage());
			cerrarSocket();
		}
	}
	//se invocan los dos metodos creados dentro de run
	//la linea escrita se recoge a traves del getter anteriormente creado
	public synchronized void run() {
		while(conexion) {
			this.leerMensaje();
			this.escribirLinea(getMensajerecibido());
		}
	}
	//este metodo recoge la informacion del socket
	public ClienteHiloMensajes(Socket socketParametro) {
		socket = socketParametro;
		try {
			dos = new DataOutputStream(socket.getOutputStream());
			dis = new DataInputStream(socket.getInputStream());
		}catch (IOException e) {
			System.out.println(e.getMessage());
			cerrarSocket();
		}
	}
	//este metodo simplemente cierra el Socket, el DataOutputStream y DataInputStream
	public void cerrarSocket() {
		try {
			conexion = false;
			socket.close();
			dis.close();
			dos.close();
		}catch (IOException e) {
			conexion = false;
			System.out.println(e.getMessage());
		}
	}
}