package udpejercicios;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.*;

public class ServidorEj1 {
	public static void main(String[] args) throws InterruptedException, IOException {
		//se crea la fecha del Servidor con la clase Date
		Date dateServidor = new Date();
		//se crea el socket pasándole el número de puerto
		DatagramSocket datagramSocket = new DatagramSocket(5001);
		System.out.println("El servidor esta en funcionamiento");
		//se crea el bufer que almacena la información
		byte[] bufer=new byte[1000];
		//bucle infinito
		while (true) {
			//se crea el DatagramPacket con la información del bufer, llamando al método receive
			DatagramPacket datagramPacketRecibido = new DatagramPacket(bufer, bufer.length);
			datagramSocket.receive(datagramPacketRecibido);
			System.out.println("Un cliente ha mandado una peticion de fecha y hora");
			//se crea la fecha del Cliente
			Date dateCliente = new Date();
			//se crea el formato de fecha
			String formato=new SimpleDateFormat("HH:mm:ss:SS dd/MM/yyy").format(dateCliente);
			String mensaje = new String(formato);
			//se pasa a bytes el mensaje
			bufer = mensaje.getBytes();
			//se crea el paquete y se envía con esta información
			DatagramPacket datagramPacketPaquete = new DatagramPacket(bufer, bufer.length, datagramPacketRecibido.getAddress(), datagramPacketRecibido.getPort());
			datagramSocket.send(datagramPacketPaquete); 
			//se consigue la hora del servidor y el cliente y se imprime la diferencia entre ellos
			long horaServidor = dateServidor.getTime();
			long horaCliente = dateCliente.getTime();
			long diferencia = horaCliente - horaServidor;
			System.out.println("Han pasado " + diferencia / 1000 + " segundos de tiempo de espera del servidor");
		}
	}
}
