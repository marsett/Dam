package udpejercicios;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.io.*;

public class ClienteEj1 {
	public static void main(String[] args) throws InterruptedException, ParseException {
		//se crea la fechaRemota perteneciente a la clase Date
		Date fechaRemota = new Date();
		try {
			//se crea el bufer que almacena la información recibida
			byte bufer[] = new byte[1000];
			//se crea el socket
			DatagramSocket datagramSocket = new DatagramSocket();
			//se llama al metodo setSoTimeout, el cual permite establecer un tiempo de espera límite
			datagramSocket.setSoTimeout(5000);
			//se recoge en una variable 'localhost', el cual es pasado por argumentos
			InetAddress ipDestino = InetAddress.getByName(args[0]);
			//se recoge con un DatagramPacket la información
			DatagramPacket datagramPacketRecibido = new DatagramPacket(bufer, bufer.length, ipDestino, 5001);
			//se envía esta información
			datagramSocket.send(datagramPacketRecibido);
			datagramPacketRecibido = new DatagramPacket(bufer, bufer.length);
			//se recibe la información del servidor
			datagramSocket.receive(datagramPacketRecibido);
			//con un String se recoge la información
			String mensajeRecibido = new String(datagramPacketRecibido.getData());
			//se imprime la hora Local y Remota
			System.out.println("Fecha y Hora -Local-: " + mensajeRecibido);
			SimpleDateFormat formato = new SimpleDateFormat("HH:mm:ss:SS dd/MM/yyy");
			System.out.println("Fecha y Hora -Remota-: " + formato.format(fechaRemota));
			//se parsea
			Date local = formato.parse(mensajeRecibido);
			Date remota = formato.parse(formato.format(fechaRemota));
			//se hace la operación para conseguir la diferencia de tiempos
			long diferenciaLocalRemota = Math.abs(remota.getTime() - local.getTime());
			long diferenciaMilisegundos = TimeUnit.MILLISECONDS.convert(diferenciaLocalRemota, TimeUnit.MILLISECONDS);
			//se imprime esta diferencia
			System.out.println("La diferencia entre Local y Remota en milisegundos es de " + diferenciaMilisegundos);
			//se cierra el socket
			datagramSocket.close();
		 }catch (SocketException e) {
			 System.out.println("Socket: " + e.getMessage());
		 }catch (IOException e) {
			 System.out.println("IO: " + e.getMessage());
		 }
	}
}
