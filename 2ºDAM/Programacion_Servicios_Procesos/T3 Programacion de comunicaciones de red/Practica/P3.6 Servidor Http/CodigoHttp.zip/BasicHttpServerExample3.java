package http;
//se importa el paquete especial requerido para este tipo de ejercicios
import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;

	public class BasicHttpServerExample3 {
		public static void main(String[] args) throws IOException {
			//el objeto server creado hace referencia a la direccion del InetSocket, en el puerto 8500, donde el 0 hace referencia al localhost
			HttpServer server = HttpServer.create(new InetSocketAddress(8500), 0);
			//el objeto context hace que el HttpServer cree el contexto a partir de la barra
			HttpContext context = server.createContext("/");
			//el metodo setHandler fija cual es el handler del context
			context.setHandler(BasicHttpServerExample3::handleRequest);
			//se comienza la ejecucion del servidor
			server.start();
		}
		private static void handleRequest(HttpExchange exchange) throws IOException {
			//el navegador, al introducir cualquier mensaje despues de la barra, devolverá el siguiente String
			String response = "Hi there!";
			exchange.sendResponseHeaders(200,
			response.getBytes().length);//response code and length
			//en el navegador se escribe el mensaje a través de OutputStream
			OutputStream os = exchange.getResponseBody();
			os.write(response.getBytes());
			os.close();
		}
	}
