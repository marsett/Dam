package http;
//se importa el paquete especial requerido para este tipo de ejercicios
import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;

public class BasicHttpServerExample2 {
	public static void main(String[] args) throws IOException {
		//el objeto server creado hace referencia a la direccion del InetSocket, en el puerto 8500, donde el 0 hace referencia al localhost
		HttpServer server = HttpServer.create(new InetSocketAddress(8500), 0);
		//el objeto context hace que el HttpServer cree el contexto a partir de la barra
		HttpContext context = server.createContext("/");
		//el metodo setHandler fija cual es el handler del context
		context.setHandler(BasicHttpServerExample2::handleRequest);
		//se comienza la ejecucion del servidor
		server.start();
	}
	private static void handleRequest(HttpExchange exchange) throws IOException {
		//este método que se ejecuta en el main manda la respuesta que se haya introducido despues de la barra de localhost:8500/
		//se consigue la URI a traves del exchange pasado por parametro y se imprime por pantalla
		URI requestURI = exchange.getRequestURI();
		printRequestInfo(exchange);
		String response = "Esta es la respuesta a " + requestURI;
		exchange.sendResponseHeaders(200,
		response.getBytes().length);
		//con un OutputStream se escribe esto en el navegador
		OutputStream os = exchange.getResponseBody();
		os.write(response.getBytes());
		os.close();
	}
	private static void printRequestInfo(HttpExchange exchange) {
		//en consola se imprime toda la información descrita: encabezados, el principio,
		//el metodo http y la consulta, imprimiendo finalmente la query
		System.out.println("-- encabezados --");
		Headers requestHeaders = exchange.getRequestHeaders();
		requestHeaders.entrySet().forEach(System.out::println);
		System.out.println("-- principio --");
		HttpPrincipal principal = exchange.getPrincipal();
		System.out.println(principal);
		System.out.println("-- método HTTP --");
		String requestMethod = exchange.getRequestMethod();
		System.out.println(requestMethod);
		System.out.println("-- consulta --");
		URI requestURI = exchange.getRequestURI();
		String query = requestURI.getQuery();
		System.out.println(query);
	}
}
