
/*
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import org.json.JSONObject;


import com.sun.net.httpserver.Request;

*/

import java.io.IOException;


import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

 
 

public class ApiTiempoMain {
    public static void main(String[] args) throws IOException {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("https://api.openweathermap.org/data/2.5/weather?q=London&appid=6d4fbb014215a8fa3ca4109d55165e32")
                .build(); // defaults to GET
        Response response = client.newCall(request).execute();
        
       System.out.println(response.body().string());
    }
}


