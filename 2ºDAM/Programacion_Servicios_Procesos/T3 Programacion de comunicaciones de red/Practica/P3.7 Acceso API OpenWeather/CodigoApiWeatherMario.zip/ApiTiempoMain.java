import java.io.IOException;
import org.json.JSONObject;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ApiTiempoMain {
    public static void main(String[] args) throws IOException {
    	//se crea una instancia de la clase OkHttpClient
        OkHttpClient client = new OkHttpClient();
        //se crea una instancia de la clase Request por cada ciudad a la que se quiere realizar consulta a través de la API
        //se introduce la url que llama a la web de la API OpenWeather
        //la diferencia entre las tres request es el nombre de la ciudad introducido
        //siempre se pone la API Key anteriormente generada por el usuario
        //se crean los objetos Response y finalmente el JSON que contendrá la información de cada ciudad
        Request requestMadrid = new Request.Builder()
                .url("https://api.openweathermap.org/data/2.5/weather?q=Madrid&appid=bc6be2702a2eccd46b1bfa695f00c037")
                .build();
        Response responseMadrid = client.newCall(requestMadrid).execute();
        JSONObject jsonMadrid=new JSONObject(responseMadrid.body().string());
        
        Request requestLondres = new Request.Builder()
                .url("https://api.openweathermap.org/data/2.5/weather?q=Londres&appid=bc6be2702a2eccd46b1bfa695f00c037")
                .build();
        Response responseLondres = client.newCall(requestLondres).execute();
        JSONObject jsonLondres=new JSONObject(responseLondres.body().string());
        
        Request requestParis = new Request.Builder()
                .url("https://api.openweathermap.org/data/2.5/weather?q=Paris&appid=bc6be2702a2eccd46b1bfa695f00c037")
                .build();
        Response responseParis = client.newCall(requestParis).execute();
        JSONObject jsonParis=new JSONObject(responseParis.body().string());
        
        //se han elegido unas variables específicas para mostrar (las que el usuario cree que son más importantes)
        //dependiendo de lo que devuelva cada una y donde esté ubicada, se creará un tipo de variable u otro
        //o se llamará al JSONObject, al JSONArray o simplemente al get dependiendo del tipo de variable
        //se imprimen estas variables
        //en las tres ciudades se ha realizado el mismo procedimiento: únicamente cambia el objeto JSON elegido para realizar
        //la obtención de las respuestas
        System.out.println("Variables Tiempo Madrid:");
        String mainMadrid=jsonMadrid.getJSONArray("weather").getJSONObject(0).getString("main");
        System.out.println("Main: "+mainMadrid);
        String descriptionMadrid=jsonMadrid.getJSONArray("weather").getJSONObject(0).getString("description");
        System.out.println("Description: "+descriptionMadrid);
        double temp_minMadrid=jsonMadrid.getJSONObject("main").getDouble("temp_min");
        System.out.println("Temp_Min: "+temp_minMadrid);
        double temp_maxMadrid=jsonMadrid.getJSONObject("main").getDouble("temp_max");
        System.out.println("Temp_Max: "+temp_maxMadrid);
        int humidityMadrid=jsonMadrid.getJSONObject("main").getInt("humidity");
        System.out.println("Humidity: "+humidityMadrid);
        int cloudsMadrid=jsonMadrid.getJSONObject("clouds").getInt("all");
        System.out.println("Clouds: "+cloudsMadrid);
        String countryMadrid=jsonMadrid.getJSONObject("sys").getString("country");
        System.out.println("Country: "+countryMadrid);
        String cityMadrid=jsonMadrid.getString("name");
        System.out.println("Name: "+cityMadrid);
        
        System.out.println("\nVariables Tiempo Londres:");
        String mainLondres=jsonLondres.getJSONArray("weather").getJSONObject(0).getString("main");
        System.out.println("Main: "+mainLondres);
        String descriptionLondres=jsonLondres.getJSONArray("weather").getJSONObject(0).getString("description");
        System.out.println("Description: "+descriptionLondres);
        double temp_minLondres=jsonLondres.getJSONObject("main").getDouble("temp_min");
        System.out.println("Temp_Min: "+temp_minLondres);
        double temp_maxLondres=jsonLondres.getJSONObject("main").getDouble("temp_max");
        System.out.println("Temp_Max: "+temp_maxLondres);
        int humidityLondres=jsonLondres.getJSONObject("main").getInt("humidity");
        System.out.println("Humidity: "+humidityLondres);
        int cloudsLondres=jsonLondres.getJSONObject("clouds").getInt("all");
        System.out.println("Clouds: "+cloudsLondres);
        String countryLondres=jsonLondres.getJSONObject("sys").getString("country");
        System.out.println("Country: "+countryLondres);
        String cityLondres=jsonLondres.getString("name");
        System.out.println("Name: "+cityLondres);
        
        System.out.println("\nVariables Tiempo Paris:");
        String mainParis=jsonParis.getJSONArray("weather").getJSONObject(0).getString("main");
        System.out.println("Main: "+mainParis);
        String descriptionParis=jsonParis.getJSONArray("weather").getJSONObject(0).getString("description");
        System.out.println("Description: "+descriptionParis);
        double temp_minParis=jsonParis.getJSONObject("main").getDouble("temp_min");
        System.out.println("Temp_Min: "+temp_minParis);
        double temp_maxParis=jsonParis.getJSONObject("main").getDouble("temp_max");
        System.out.println("Temp_Max: "+temp_maxParis);
        int humidityParis=jsonParis.getJSONObject("main").getInt("humidity");
        System.out.println("Humidity: "+humidityParis);
        int cloudsParis=jsonParis.getJSONObject("clouds").getInt("all");
        System.out.println("Clouds: "+cloudsParis);
        String countryParis=jsonParis.getJSONObject("sys").getString("country");
        System.out.println("Country: "+countryParis);
        String cityParis=jsonParis.getString("name");
        System.out.println("Name: "+cityParis);
    } 
}