package tictac;

public class MiNHilo implements Runnable{
	//se implementa Runnable, lo cual requiere insertar el metodo run, el cual se sobreescribira
	//se crea un objeto de la clase Thread y otro de la clase TicTac
	Thread hilo;
	TicTac ttob;
	//en el constructor se pasa por parametro el nombre y un objeto TicTac
	public MiNHilo(String nombre, TicTac tt) {
		//se igualan estas variables con las anteriormente creadas
		hilo=new Thread(this,nombre);
		ttob=tt;
	}
	//este metodo static que se llamara en la clase ComHilos, crea un nuevo hilo, llamando al metodo start
	public static MiNHilo crearEIniciar(String nombre, TicTac tt) {
		MiNHilo miNHilo=new MiNHilo(nombre, tt);
		miNHilo.hilo.start();
		return miNHilo;
	}
	//se sobrescribe el metodo, estableciendo los Tic y Tac que saldrán al ejecutar el programa
	public void run() {
		if(hilo.getName().compareTo("Tic")==0) {
			for(int i=0;i<8;i++) ttob.tic(true);
			ttob.tic(false);
		}else {
			for(int i=0;i<8;i++) ttob.tac(true);
			ttob.tac(false);
		}
	}
}
