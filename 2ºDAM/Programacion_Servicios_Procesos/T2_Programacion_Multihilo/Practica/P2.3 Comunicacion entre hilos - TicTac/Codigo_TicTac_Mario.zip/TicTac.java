package tictac;

public class TicTac {
	String estado;
	//metodo sincronizado que establece que, si el Tic no esta corriendo, que se ejecute el metodo notify
	//se imprime el Tic y la variable estado cambia
	//ademas, si el estado es diferente a tacmarcado, el hilo espera a que se ejecute el otro hilo
	synchronized void tic(boolean corriendo) {
		if(!corriendo) {
			estado="ticmarcado";
			notify();
			return;
		}
		System.out.print("Tic ");
		estado="ticmarcado";
		notify();
		try {
			while(!estado.equals("tacmarcado")) {
				wait();
			}
		}catch(InterruptedException e) {
			System.out.println("Hilo interrumpido");
		}
	}
	//mismo proceso que con el tic, cambiando por tac
	synchronized void tac(boolean corriendo) {
		if(!corriendo) {
			estado="tacmarcado";
			notify();
			return;
		}
		System.out.println("Tac");
		estado="tacmarcado";
		notify();
		try {
			while(!estado.equals("ticmarcado")) {
				wait();
			}
		}catch(InterruptedException e) {
			System.out.println("Hilo interrumpido");
		}
	}
}
