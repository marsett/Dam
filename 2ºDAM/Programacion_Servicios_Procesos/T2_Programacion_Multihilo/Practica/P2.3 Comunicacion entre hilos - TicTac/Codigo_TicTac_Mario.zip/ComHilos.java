package tictac;

public class ComHilos {
	public static void main(String[] args) {
		//en esta clase se crea un objeto de la clase TicTac
		TicTac tt=new TicTac();
		//se crean dos hilos para crear con el primero el Tic, pasando por parametro el objeto TicTac
		//y con el segundo el Tac
		//todo esto llamando al metodo static de la clase MiNHilo
		MiNHilo mh1=MiNHilo.crearEIniciar("Tic", tt);
		MiNHilo mh2=MiNHilo.crearEIniciar("Tac", tt);
		//try-catch donde se ejecutan los dos hilos, incluyendoles el metodo join
		try {
			mh1.hilo.join();
			mh2.hilo.join();
		}catch(InterruptedException exc){
			System.out.println("Hilo principal interrumpido");
		}
	}
}
