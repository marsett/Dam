package bolsas;

public class HiloEnvio extends Thread{
	//se crea un objeto de la clase Bolsa, el cual se referenciara a otro objeto
	//Bolsa dentro del constructor
	private Bolsa bolsa;
	public HiloEnvio(Bolsa bolsa) {
		super();//llama al constructor de la clase que hereda
		this.bolsa=bolsa;
	}
	//si la bolsa no esta llena, el bloque sincronizado pasa el objeto bolsa
	//por parametro, llamandole con el metodo wait
	//se imprime el tamano final de la bolsa
	@Override
	public void run() {
		if(bolsa.estaLlena()!=true) {
			try {
				synchronized(bolsa) {
					bolsa.wait();
				}
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("Enviando la bolsa con "+bolsa.getSize()+" elementos");
		}
	}
	//getter y setter del objeto bolsa
	public Bolsa getBolsa() {
		return bolsa;
	}
	public void setBolsa(Bolsa bolsa) {
		this.bolsa=bolsa;
	}
}
