package bolsas;
import java.util.ArrayList;

public class Bolsa {
	//se crea un ArrayList de la clase Producto, con su getter
	private ArrayList<Producto> listaProductos=new ArrayList<Producto>();
	//se pasa por parametro un objeto de la clase Producto, el cual sera añadido a 
	//la listaProductos si la bolsa no esta llena
	public void addProducto(Producto producto) {
		if(!estaLlena()) {
			listaProductos.add(producto);
		}
	}
	public ArrayList<Producto> getListaProductos(){
		return listaProductos;
	}
	//se recuperan el tamano de la bolsa y si esta llena con los siguientes metodos 
	//(se establece que 7 productos es la cantidad maxima a guardar en la bolsa)
	public int getSize() {
		return listaProductos.size();
	}
	public boolean estaLlena() {
		return listaProductos.size()>=7;
	}	
}
