package bolsas;

public class Producto {
	//se crea el nombre del producto
	//se crea su getter y setter
	private String nombre;
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre=nombre;
	}
}
