package bolsas;

public class Principal {
	public static void main(String[] args) {
		//se crea un objeto de la clase Bolsa
		Bolsa bolsa=new Bolsa();
		//se crea un hilo pasando por el constructor el objeto bolsa
		//empieza el hilo
		HiloEnvio hilo=new HiloEnvio(bolsa);
		hilo.start();
		//dentro de un for se crea un producto nuevo
		//en un bloque sincronizado, se mete el objeto bolsa, y notifica
		//si la bolsa esta llena
		for(int i=0;i<=10;i++) {
			Producto p=new Producto();
			try {
				synchronized (bolsa) {
					Thread.sleep(3000);
					if(bolsa.estaLlena()) {
						bolsa.notify();
					}
				}
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
			//hecho esto, se anade el producto al arraylist
			bolsa.addProducto(p);
			//se imprime el tamano final de la bolsa
			System.out.println(bolsa.getSize());
		}
	}
}
