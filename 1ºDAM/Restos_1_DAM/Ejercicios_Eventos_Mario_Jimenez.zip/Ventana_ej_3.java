package eventos_interfaces;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana_ej_3 extends JFrame{	//Marco
	
	private static final long serialVersionUID = 1L;
	private int anchoventana, alturaventana;
	
	public Ventana_ej_3(int ancho, int alto) {
		
		setTitle("Ventana Ejercicio 3");
		setResizable(true);
		
		anchoventana = ancho/3;
		alturaventana = alto/2;
		
		setBounds(ancho/2,(int)((alto/10)*0.99),anchoventana, alturaventana);
		
		VentEj3 lam_ej3 = new VentEj3(anchoventana, alturaventana);
		add(lam_ej3);
		setVisible(true);
	}
}

class VentEj3 extends JPanel implements ActionListener{	//Lamina
	
	private static final long serialVersionUID = 1L;
	private int anchov, altov;
	
	int numeros[];
	
	JTextField campo1 = new JTextField(5);
	JTextField campo2 = new JTextField(5);
	JTextField campo3 = new JTextField(5);
	JTextField campo4 = new JTextField(5);
	JTextField campo5 = new JTextField(5);
	
	JLabel texto1 = new JLabel("Complementario");
	JTextField campo6 = new JTextField(5);
	
	JButton botongenerar = new JButton("Generar");
	
	public VentEj3(int ancho, int alto) {
		
		setLayout(null);
		
		this.anchov = ancho;
		this.altov = alto;
		
		add(campo1);
		campo1.setBounds(60,40,35,20);
		
		add(campo2);
		campo2.setBounds(110,40,35,20);
		
		add(campo3);
		campo3.setBounds(160,40,35,20);
		
		add(campo4);
		campo4.setBounds(210,40,35,20);
		
		add(campo5);
		campo5.setBounds(260,40,35,20);
		
		add(texto1);
		texto1.setBounds(315,10,100,20);
		
		add(campo6);
		campo6.setBounds(330,40,35,20);
		
		add(botongenerar);
		botongenerar.setBounds(190,110,105,45);
		
		botongenerar.addActionListener(this);
		
		numeros = new int[9];
		
		for(int i=0; i<6; i++) {
			numeros[i] = (int)(Math.random()*(49-1+1)+1);
		}
		
	}
	
	public void actionPerformed(ActionEvent e) {
		
		campo1.setText(Integer.toString(numeros[0]));
		campo2.setText(Integer.toString(numeros[1]));
		campo3.setText(Integer.toString(numeros[2]));
		campo4.setText(Integer.toString(numeros[3]));
		campo5.setText(Integer.toString(numeros[4]));
		campo6.setText(Integer.toString(numeros[5]));
		
	}
}
