package eventos_interfaces;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana_ej_1 extends JFrame{	//Marco
	
	private static final long serialVersionUID = 1L;
	private int anchoventana, alturaventana;
	
	public Ventana_ej_1(int ancho, int alto) {
		
		setTitle("Ventana Ejercicio 1");
		setResizable(true);
		
		anchoventana = ancho/3;
		alturaventana = alto/2;
		
		setBounds(ancho/3,(int)((alto/2)*0.99),anchoventana, alturaventana);
		
		VentEj1 lam_ej1 = new VentEj1(anchoventana, alturaventana);
		add(lam_ej1);
		setVisible(true);
		
	}
}

class VentEj1 extends JPanel implements ActionListener{	//Lamina
	
	private static final long serialVersionUID = 1L;
	private int anchov, altov;
	
	JTextField campo1 = new JTextField(10);
	JTextField campo2 = new JTextField(10);
	
	JLabel texto1 = new JLabel("Texto a copiar");
	JLabel texto2 = new JLabel("Texto copiado");
	
	JButton botoncopiar = new JButton("Copiar");
	
	public VentEj1(int ancho, int alto) {
		
		setLayout(null);
		
		this.anchov = ancho;
		this.altov = alto;
		
		add(texto1);
		texto1.setBounds(80,-50,130,130);
		
		add(campo1);
		campo1.setBounds(80,37,85,20);
		
		add(texto2);
		texto2.setBounds(280,-50,130,130);
	
		add(campo2);
		campo2.setBounds(280,37,85,20);
		
		add(botoncopiar);
		botoncopiar.setBounds(158,90,130,50);
		
		botoncopiar.addActionListener(this);
		
	}
	
	public void actionPerformed(ActionEvent e) {
		
		campo2.setText(campo1.getText());
		campo1.setText("");
		
	}
	
}
