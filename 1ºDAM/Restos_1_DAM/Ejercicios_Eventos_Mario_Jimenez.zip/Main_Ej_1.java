package eventos_interfaces;

import javax.swing.*;

import java.awt.*;

public class Main_Ej_1 {

	public static void main(String[] args) {
		
		Toolkit mipantalla = Toolkit.getDefaultToolkit();
		Dimension tamanopantalla = mipantalla.getScreenSize();
		
		int anch = tamanopantalla.width;
		int alt = tamanopantalla.height;
		
		Ventana_ej_1 ej1 = new Ventana_ej_1(anch,alt);
		ej1.setVisible(true);
		ej1.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		Ventana_ej_2 ej2 = new Ventana_ej_2(anch,alt);
		ej2.setVisible(true);
		ej2.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		Ventana_ej_3 ej3 = new Ventana_ej_3(anch,alt);
		ej3.setVisible(true);
		ej3.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

	}

}
