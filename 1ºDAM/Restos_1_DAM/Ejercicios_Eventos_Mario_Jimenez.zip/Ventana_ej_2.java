package eventos_interfaces;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana_ej_2 extends JFrame{	//Marco
	
	private static final long serialVersionUID = 1L;
	private int anchoventana, alturaventana;
	
	public Ventana_ej_2(int ancho, int alto) {
		
		setTitle("Ventana Ejercicio 2");
		setResizable(true);
		
		anchoventana = ancho/3;
		alturaventana = alto/2;
		
		setBounds(ancho/2,(int)((alto/10)*0.99),anchoventana, alturaventana);
		
		VentEj2 lam_ej2 = new VentEj2(anchoventana, alturaventana);
		add(lam_ej2);
		setVisible(true);
		
	}
}

class VentEj2 extends JPanel implements ActionListener{	//Lamina
	
	private static final long serialVersionUID = 1L;
	private int anchov, altov;
	
	JTextField campo1 = new JTextField(10);
	JTextField campo2 = new JTextField(10);
	
	JLabel texto1 = new JLabel("Derecho");
	JLabel texto2 = new JLabel("Rev�s");
	
	JButton menor = new JButton("<");
	JButton mayor = new JButton(">");
	
	public VentEj2(int ancho, int alto) {
		
		setLayout(null);
		
		this.anchov = ancho;
		this.altov = alto;
		
		add(texto1);
		texto1.setBounds(80,15,130,130);

		add(campo1);
		campo1.setBounds(80,95,105,20);
		
		add(menor);
		menor.setBounds(220,63,50,30);
		
		menor.addActionListener(this);
		
		add(mayor);
		mayor.setBounds(220,105,50,30);
		
		mayor.addActionListener(this);
		
		add(texto2);
		texto2.setBounds(310,15,130,130);
		
		add(campo2);
		campo2.setBounds(310,95,105,20);
		
	}
	
	public void actionPerformed(ActionEvent e) {
		
		char normal[] = campo1.getText().toCharArray();
		
		String invertida = "";
		
		for(int i=normal.length-1;i>=0;i--) {
			invertida+=normal[i];
			campo2.setText(invertida);
		}
		
		char normal2[] = campo2.getText().toCharArray();
		
		String invertida2 = "";
		
		for(int i=normal2.length-1;i>=0;i--) {
			invertida2+=normal2[i];
			campo1.setText(invertida2);
		}
		
	}
	
}
