package examen1;

public final class City extends Tienda{
	int seccionesC;
    
    City(int seccsC){
    	this.empleados = getEmpleados()/2;
    	this.metros2 = getMetros2()/2;
    	this.seccionesC = seccsC;
    	numeroTiendas ++;
    }
    
    public int EmpleadosSeccion () {
    	int empleadosXsection =  (int) empleados/seccionesC;
    	System.out.println("Tienda tipo City. Empleados: " + empleados + " Secciones: " + seccionesC + " Empleados Por Seccion: " + empleadosXsection);
    	return empleadosXsection;
    }
   
}
