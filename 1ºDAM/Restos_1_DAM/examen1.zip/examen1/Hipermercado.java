package examen1;

public final class Hipermercado extends Tienda{
	int seccionesH;
    
    Hipermercado(int seccsH){
    	this.empleados = getEmpleados()*3;
    	this.metros2 = getMetros2()*3;
    	this.seccionesH = seccsH;
    	numeroTiendas ++;
    }
    
    public int EmpleadosSeccion () {
    	int empleadosXsection =  (int) empleados/seccionesH;
    	System.out.println("Tienda tipo Hipermercado. Empleados: " + empleados + " Secciones: " + seccionesH + " Empleados Por Seccion: " + empleadosXsection);
    	return empleadosXsection;
    }
}
