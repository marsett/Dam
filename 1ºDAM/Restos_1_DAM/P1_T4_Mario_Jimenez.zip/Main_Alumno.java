package p1_t4;

import java.util.Scanner;

public class Main_Alumno {

	public static void main(String[] args) {
		
		//Mario Jimenez Marset
		
		Scanner entrada = new Scanner (System.in);
		
		System.out.println("Nombre y apellido");
		
		Alumno objeto1 = new Alumno(entrada.nextLine(), entrada.nextLine());
		objeto1.getincrementar();
		objeto1.num();
		
		Alumno copia = new Alumno(objeto1);
		copia.getincrementar();
		copia.num();
		
		System.out.println("Valor objeto1 "+objeto1.getnombre()+" "+objeto1.getapellido());
		System.out.println("Valor copia "+copia.getnombre()+" "+copia.getapellido());
		
		Alumno objeto3 = new Alumno();
		objeto3.getincrementar();
		objeto3.num();
		
		objeto1 = objeto3;
		
		objeto1.setnombre("Juanin");
		
		if(objeto1.equals(objeto3)) {
			System.out.println("Los nombres son iguales");
		}else {
			System.out.println("Los nombre son distintos");
		}
		
		System.out.println("Resultado "+objeto1.imprimeresultado());
		
		System.out.println("Valor de numalumnos "+objeto1.num2());

	}

}
