package p1_t4;

public class Alumno {
	
	//Mario Jimenez Marset
	
	//Atributos
	
	protected String nombre, apellido;
	private static int numalumnos = 0;
	private double notamedia, resultado;
	
	//Constructores
	
	public Alumno() {
		this.nombre = "";
		this.apellido = "";
	}
	
	public Alumno(Alumno obj1) {
		this.nombre = obj1.nombre;
		this.apellido = obj1.apellido;
	}
	
	public Alumno(String nombre, String apellido) {
		this.nombre = nombre;
		this.apellido = apellido;
	}
	
	//Metodos
	
	public String getnombre() {
		return nombre;
	}
	
	public String getapellido() {
		return apellido;
	}
	
	public void setnombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setapellido(String apellido) {
		this.apellido = apellido;
	}
	
	public static void num() {
		numalumnos++;
	}
	
	public static double num2() {
		return numalumnos;
	}
	
	public void getincrementar() {
		resultado = notamedia += 5;
	}
	
	public double imprimeresultado() {
		return resultado;
	}

}
