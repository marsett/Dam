package graficos;

import javax.swing.*;
import java.awt.*;

public class Ventana2 extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private int anchoventana, alturaventana;

	public Ventana2(int ancho, int alto) {
		
		setTitle("Segunda ventana");
		setResizable(true);
		
		anchoventana = ancho/3;
		alturaventana = alto/2;
		
		setBounds(ancho/3,0,anchoventana, alturaventana);
		
		Vent2 milamina2 = new Vent2(anchoventana, alturaventana);
		add(milamina2);
		setVisible(true);
		
	}
}

class Vent2 extends JPanel{
	
	private static final long serialVersionUID = 1L;
	private int anchov, altov;
	
	JLabel texto1 = new JLabel("Ejemplo de Botones:");
	JButton boton1 = new JButton("Texto1");
	JCheckBox boton2 = new JCheckBox("Texto2");
	JRadioButton boton3 = new JRadioButton("Texto3");
	
	Vent2(int ancho, int alto){
		
		this.anchov = ancho;
		this.altov = alto;
		
		texto1.setLocation(10,10);
		setLayout(new BorderLayout());
		
		setBackground(Color.cyan);
		
		add(texto1, BorderLayout.NORTH);
		add(boton1, BorderLayout.WEST);
		add(boton2, BorderLayout.SOUTH);
		add(boton3, BorderLayout.EAST);
		
	}
	
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		g.drawString("ESTAMOS EN LA SEGUNDA VENTANA",(int)(this.anchov*20)/100,(int)(this.altov*80)/100);
		
	}
}