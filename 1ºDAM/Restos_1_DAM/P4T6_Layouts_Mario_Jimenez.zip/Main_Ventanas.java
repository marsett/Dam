package graficos;

import javax.swing.*;
import java.awt.*;

public class Main_Ventanas {

	public static void main(String[] args) {
		
		Toolkit mipantalla = Toolkit.getDefaultToolkit();
		Dimension tamanopantalla = mipantalla.getScreenSize();
		
		int anch = tamanopantalla.width;
		int alt = tamanopantalla.height;
		
		Ventana1 ventana1 = new Ventana1(anch,alt);
		ventana1.setVisible(true);
		ventana1.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		Ventana2 ventana2 = new Ventana2(anch,alt);
		ventana2.setVisible(true);
		ventana2.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		Ventana3 ventana3 = new Ventana3(anch, alt);
		ventana3.setVisible(true);
		ventana3.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		
		Ventana4 ventana4 = new Ventana4(anch,alt);
		ventana4.setVisible(true);
		ventana4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}

