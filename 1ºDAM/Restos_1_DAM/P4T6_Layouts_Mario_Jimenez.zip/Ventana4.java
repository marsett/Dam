package graficos;

import javax.swing.*;
import java.awt.*;

public class Ventana4 extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private int anchoventana, alturaventana;

	public Ventana4(int ancho, int alto) {
		
		setTitle("Cuarta ventana");
		setResizable(true);
		
		anchoventana = 2*ancho/3;
		alturaventana = alto/2;
		
		setBounds(ancho/3,(int)((alto/2)*0.99),anchoventana, alturaventana);
		
		Vent4 milamina4 = new Vent4(anchoventana, alturaventana);
		add(milamina4);
		setVisible(true);
	}
}

class Vent4 extends JPanel{
	
	private static final long serialVersionUID = 1L;
	private int anchov, altov;
	
	JLabel texto1 = new JLabel("Ejemplo de campo:");
	JTextField campo1 = new JTextField("Escribe tu nombre ...",20);
	JButton boton1 = new JButton("Pulsa");
	
	Vent4(int ancho, int alto){
		
		this.anchov = ancho;
		this.altov = alto;
		
		setLayout(new BorderLayout());
		
		add(texto1, BorderLayout.NORTH);
		add(campo1, BorderLayout.WEST);
		add(boton1, BorderLayout.EAST);
		
		setBackground(Color.pink);
		
	}
	
	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		g.drawString("��SI CIERRAS ESTA VENTANA, FINALIZA EL PROGRAMA!!",(int)(this.anchov*20)/100,(int)(this.altov*80)/100);
		
	}
}
