package graficos;

import javax.swing.*;
import java.awt.*;

public class Ventana3 extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private int anchoventana, alturaventana;

	public Ventana3(int ancho, int alto) {
		
		setTitle("Tercera ventana");
		setResizable(true);
		
		anchoventana = ancho/3;
		alturaventana = alto/2;
		
		setBounds(2*ancho/3,0,anchoventana, alturaventana);
		
		Vent3 milamina3 = new Vent3(anchoventana, alturaventana);
		add(milamina3);
		setVisible(true);
		
	}
}

class Vent3 extends JPanel{
	
	private static final long serialVersionUID = 1L;
	private int anchov, altov;
	
	JLabel texto1 = new JLabel("Ejemplo de ComboBox:");
	JComboBox <String> combo1;
	
	Vent3(int ancho, int alto){
		
		this.anchov = ancho;
		this.altov = alto;
		
		setLayout(new BorderLayout());
		
		setLayout(new GridLayout(4,4));
		
		combo1 = new JComboBox <String>();
		combo1.setModel(new DefaultComboBoxModel<>(new String[] {"Ana", "Pepe", "Juan", "Carmen"}));
		combo1.setSelectedIndex(1);
		
		add(texto1, BorderLayout.NORTH);
		add(combo1);
		
		setBackground(Color.green);
		
	}
	
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		g.drawString("ESTAMOS EN LA TERCERA VENTANA",(int)(this.anchov*20)/100,(this.altov*80)/100);
		
	}
	
}
