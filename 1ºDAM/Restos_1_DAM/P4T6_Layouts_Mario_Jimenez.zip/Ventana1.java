package graficos;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class Ventana1 extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private int anchoventana, alturaventana; 

	public Ventana1(int ancho, int alto) {
		
		setTitle("Primera ventana");
		setResizable(true);
		
		anchoventana = ancho/3;
		alturaventana = alto;
		
		setSize(anchoventana,alturaventana);
		setLocation(0,0);
		
		Vent1 milamina1 = new Vent1(anchoventana, alturaventana);
		add(milamina1);
		setVisible(true);
		
	}
}

class Vent1 extends JPanel{
	
	private static final long serialVersionUID = 1L;
	private int anchov, altov;
	
	JTextArea miarea = new JTextArea(30,30);
	
	String fileString = "Lorem.txt";
	
	File fr = new File (fileString);
	
	JLabel jl = new JLabel ("Texto le�do del fichero " + fileString);
	
	String cadena="";
	
	Vent1(int ancho, int alto){
		
		this.altov = alto;
		this.anchov = ancho;
		
		miarea.setLocation(120,100);
		miarea.setLineWrap(true);
		miarea.append("\n");
		
		Panel_Flow_1 lamina1 = new Panel_Flow_1();
		
		Panel_Flow_2 lamina2 = new Panel_Flow_2();
		
		setBackground(Color.ORANGE);
		
		try {
			
			FileReader fl = new FileReader(fr);
			BufferedReader br = new BufferedReader(fl);
			
			while((cadena = br.readLine())!=null) {
				
				miarea.append(cadena);
				miarea.append("\n");
				
			}
			
			br.close();
		
	} catch (IOException e) {
		
		miarea.setText("Error no se ha encontrado el archivo");
		miarea.append(e.getMessage()+"\n");
		
	}
		
		add(lamina1);
		add(lamina2);
		add(jl);
		add(miarea);
		
	}
	
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		g.drawString("TEXTAREA CON TEXTO DE FICHERO",(int)(this.anchov*20)/100,(int)(altov*80)/100);
		
	}
}

class Panel_Flow_1 extends JPanel{
	
	private static final long serialVersionUID = 1L;
	
	public Panel_Flow_1() {
		
		setLayout(new FlowLayout(FlowLayout.LEFT,7,18));
		
		add(new JLabel("Elige un texto:"));
		
		add(new JButton("Texto_1"));
		
		add(new JButton("Texto_2"));
		
		add(new JButton("Texto_3"));
		
		setBackground(Color.LIGHT_GRAY);
	
	}
}

class Panel_Flow_2 extends JPanel{
	
	private static final long serialVersionUID = 1L;
	
	public Panel_Flow_2() {
		
		setLayout(new FlowLayout(FlowLayout.RIGHT,20,15));
		
		add(new JLabel("Escribe tu c�digo de biblioteca:"));
		
		add(new JTextField(10));
		
		setBackground(Color.GREEN);
		
	}
}
