package interfaces;
import javax.swing.*;
import java.awt.*;
import java.io.*;

public class Ventana1 extends JFrame{
	
	private static final long serialVersionUID = 34L;

	public Ventana1() {
		setTitle("Primera ventana");
		setResizable(true);
		
		Toolkit screen = Toolkit.getDefaultToolkit();
		Dimension size = screen.getScreenSize();
		int altura1 = size.height;
		int ancho1 = size.width;
		setSize(ancho1/3,altura1);
		setLocation(ancho1-ancho1,altura1-altura1);
		
		Vent1 milamina1 = new Vent1();
		add(milamina1);
		setVisible(true);
		
		Lamina1 lam1 = new Lamina1();
		add(lam1);
		setVisible(true);
	}
}

class Vent1 extends JPanel{
	
	private static final long serialVersionUID = 1L;
	
	Vent1(){
		JLabel texto1 = new JLabel("Texto le�do del fichero ficheros/Lorem.txt");
		add(texto1);
		JTextField campo1 = new JTextField("Lorem.txt",20);
		add(campo1);
	}
	
	public void paintComponent1(Graphics g) {
		Toolkit mipantalla = Toolkit.getDefaultToolkit();
		Dimension tamanopantalla = mipantalla.getScreenSize();
		int altura = tamanopantalla.height;
		int ancho = tamanopantalla.width;
		
		super.paintComponent(g);
		g.drawString("TEXTAREA CON TEXTO DE FICHERO", (ancho*20)/100, (altura*80)/100);
		g.drawString("Hola",100,100);
		setVisible(true);
	}
}

class Lamina1 extends JPanel{
	
	private static final long serialVersionUID = 34L;
	
	Lamina1(){
		
		File fl = new File("C:\\Users\\IEUser\\eclipse-workspace\\Lorem.txt");
		try {
			FileWriter fw = new FileWriter(fl);
			FileReader fr = new FileReader(fl);
			BufferedReader br = new BufferedReader(fr);
			
			String linea="";
			
			while(linea!=null) {
				linea=br.readLine();
				
				if(linea!=null) {
					System.out.println(linea);
				}
			}
			
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JTextArea miarea = new JTextArea();
		miarea.setLineWrap(true);
		add(miarea);
		
	}
}
