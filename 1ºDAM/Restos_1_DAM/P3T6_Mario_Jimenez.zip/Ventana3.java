package interfaces;
import javax.swing.*;
import java.awt.*;

public class Ventana3 extends JFrame{

	public Ventana3() {
		//setSize(576,864);
		setTitle("Tercera ventana");
		setResizable(true);
		
		Toolkit screen = Toolkit.getDefaultToolkit();
		Dimension size = screen.getScreenSize();
		int altura3 = size.height;
		int ancho3 = size.width;
		setSize(ancho3/3,altura3/2);
		setLocation((ancho3/3)*2,altura3-altura3);	//x,y
		
		/*Vent2 lamina2 = new Vent2();
		add(lamina2);
		setVisible(true);*/
	}
}
