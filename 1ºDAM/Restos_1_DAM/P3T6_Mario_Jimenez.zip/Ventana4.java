package interfaces;
import javax.swing.*;
import java.awt.*;

public class Ventana4 extends JFrame{

	public Ventana4() {
		setTitle("Cuarta ventana");
		setResizable(true);
		
		Toolkit screen = Toolkit.getDefaultToolkit();
		Dimension size = screen.getScreenSize();
		int altura4 = size.height;
		int ancho4 = size.width;
		setSize((ancho4/3)*2,altura4/2);
		setLocation((ancho4/3),altura4/2);	//x,y
		
		/*Vent2 lamina2 = new Vent2();
		add(lamina2);
		setVisible(true);*/
	}
}
