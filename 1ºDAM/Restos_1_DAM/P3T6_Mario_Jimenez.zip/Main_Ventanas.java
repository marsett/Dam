package interfaces;

import javax.swing.*;

public class Main_Ventanas {

	public static void main(String[] args) {
		
		Ventana1 ventana1 = new Ventana1();
		ventana1.setVisible(true);
		ventana1.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		Ventana2 ventana2 = new Ventana2();
		ventana2.setVisible(true);
		ventana2.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		Ventana3 ventana3 = new Ventana3();
		ventana3.setVisible(true);
		ventana3.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		
		Ventana4 ventana4 = new Ventana4();
		ventana4.setVisible(true);
		ventana4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
