package interfaces;
import javax.swing.*;
import java.awt.*;

public class Ventana2 extends JFrame{

	public Ventana2() {
		//setSize(576,288);
		setTitle("Segunda ventana");
		setResizable(true);
		
		Toolkit screen = Toolkit.getDefaultToolkit();
		Dimension size = screen.getScreenSize();
		int altura2 = size.height;
		int ancho2 = size.width;
		setSize(ancho2/3,altura2/2);
		setLocation(ancho2/3,altura2-altura2);	//x,y
		
		Vent2 lamina2 = new Vent2();
		add(lamina2);
		setVisible(true);
	}
}

class Vent2 extends JPanel{
	
	Vent2(){
		JLabel texto1 = new JLabel("Ejemplo de botones:");
		add(texto1);
		JTextField campo1 = new JTextField("Texto 1",20);
		add(campo1);
		JTextField campo2 = new JTextField("Texto 2",20);
		add(campo2);
		JTextField campo3 = new JTextField("Texto 3",20);
		add(campo3);
	}
	
	public void paintComponent1(Graphics g) {
		super.paintComponent(g);
		g.drawString("Hola",100,100);
	}
}

