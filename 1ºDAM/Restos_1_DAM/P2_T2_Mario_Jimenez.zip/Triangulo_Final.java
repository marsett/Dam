package finalizacion;

public class Triangulo_Final {
	
	//Atributos del tri�ngulo (encapsulados, con el objetivo de tener mayor control sobre ellos)
	
	private double base;	//lado1
	private double altura;
	private double lado2;
	private double lado3;
	private double area;
	private double perimetro;
	
	//Constructor por defecto, el cual no tiene par�metros y no hace ninguna funci�n
	
	public Triangulo_Final() {
		
	}
	
	/*Se hacen Getters con el objetivo de recuperar el valor ya asignado a cada uno de los atributos. Posteriormente, con los Setters,
	se asigna un valor inicial a los atributos*/
	
	public double getBase() {
		return base;
	}
	
	public void setBase(double base) {
		this.base = base;
	}
	
	public double getAltura() {
		return altura;
	}
	
	public void setAltura(double altura) {
		this.altura = altura;
	}
	
	public double getLado2() {
		return lado2;
	}
	
	public void setLado2(double lado2) {
		this.lado2 = lado2;
	}
	
	public double getLado3() {
		return lado3;
	}
	
	public void setLado3(double lado3) {
		this.lado3 = lado3;
	}
	
	public double getArea() {
		return area;
	}
	
	public void setArea(double area) {
		this.area = area;
	}
	
	public double getPerimetro() {
		return perimetro;
	}
	
	public void setPerimetro(double perimetro) {
		this.perimetro = perimetro;
	}
	
	/*Finalmente, para realizar los c�lculos, se hacen dos Setters donde se establece el valor de �rea y per�metro, los cu�les se 
	devuelven (return) en dos Getters posteriores*/
	
	public void CalcularArea() {
		area = (base*altura)/2;
	}
	
	public void CalcularPerimetro() {
		perimetro = base +lado2 +lado3;
	}
	
	public double ImpresionArea() {
		return area;
	}
	
	public double ImpresionPerimetro() {
		return perimetro;
	}
}
