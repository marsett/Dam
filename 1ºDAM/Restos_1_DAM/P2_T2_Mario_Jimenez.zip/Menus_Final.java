package finalizacion;

public class Menus_Final {
	
	//Atributos de los men�s (encapsulados, con el objetivo de tener mayor control sobre ellos)
	
	private String menu1, menu2, menu3, menu4, menu5, menu6, menu7, menu8, menu9, menu10, menu11, menu12;
	
	//Constructor por defecto, el cual no tiene par�metros y no hace ninguna funci�n
	
	public Menus_Final() {
		
	}
	
	/*Se hacen Getters con el objetivo de recuperar el valor ya asignado a cada uno de los atributos. Posteriormente, con los Setters,
	se asigna un valor inicial a los atributos*/
	
	public String getmenu1() {
		return menu1;
	}
	
	public void setmenu1(String menu1) {
		this.menu1 = menu1;
	}
	
	public String getmenu2() {
		return menu2;
	}
	
	public void setmenu2(String menu2) {
		this.menu2 = menu2;
	}
	
	public String getmenu3() {
		return menu3;
	}
	
	public void setmenu3(String menu3) {
		this.menu3 = menu3;
	}
	
	public String getmenu4() {
		return menu4;
	}
	
	public void setmenu4(String menu4) {
		this.menu4 = menu4;
	}
	
	public String getmenu5() {
		return menu5;
	}
	
	public void setmenu5(String menu5) {
		this.menu5 = menu5;
	}
	
	public String getmenu6() {
		return menu6;
	}
	
	public void setmenu6(String menu6) {
		this.menu6 = menu6;
	}
	
	public String getmenu7() {
		return menu7;
	}
	
	public void setmenu7(String menu7) {
		this.menu7 = menu7;
	}
	
	public String getmenu8() {
		return menu8;
	}
	
	public void setmenu8(String menu8) {
		this.menu8 = menu8;
	}
	
	public String getmenu9() {
		return menu9;
	}
	
	public void setmenu9(String menu9) {
		this.menu9 = menu9;
	}
	
	public String getmenu10() {
		return menu10;
	}
	
	public void setmenu10(String menu10) {
		this.menu10 = menu10;
	}
	
	public String getmenu11() {
		return menu11;
	}
	
	public void setmenu11(String menu11) {
		this.menu11 = menu11;
	}
	
	public String getmenu12() {
		return menu12;
	}
	
	public void setmenu12(String menu12) {
		this.menu12 = menu12;
	}
	
	//Finalmente, con otros doce Setters, se inicializa cada variable, las cu�les se podr�n mostrar con los doce Getters al devolver los valores (return)
	
	public void mostrarmenu1() {
		menu1 = "Elige una de las siguientes opciones\n1)Figuras geom�tricas\n2)Operaciones matem�ticas";
	}
	
	public void mostrarmenu2() {
		menu2 = "Elige una de estas 3 opciones\n1-Cuadrado\n2-Tri�ngulo\n3-C�rculo";
	}
	
	public void mostrarmenu3() {
		menu3 = "C�lculo del �rea del CUADRADO\n�Lado?";
	}
	
	public void mostrarmenu4() {
		menu4 = "�Quieres calcular el per�metro tambi�n?\nElige 1 si lo deseas\nEn su defecto elige 2 si no quieres calcularlo";
	}
	
	public void mostrarmenu5() {
		menu5 = "C�lculo del per�metro del CUADRADO\n�Lado?";
	}
	
	public void mostrarmenu6() {
		menu6 = "C�lculo del �rea del TRI�NGULO\n�Base y Altura?";
	}
	
	public void mostrarmenu7() {
		menu7 = "C�lculo del per�metro del TRI�NGULO\nIntroduce los tres lados de la figura";
	}
	
	public void mostrarmenu8() {
		menu8 = "C�lculo del �rea del C�RCULO\n�Radio?";
	}
	
	public void mostrarmenu9() {
		menu9 = "C�lculo del per�metro del C�RCULO\n�Radio?";
	}
	
	public void mostrarmenu10() {
		menu10 = "Operaciones matem�ticas\nElige una de estas 2 opciones\n1-Mayor o menor\n2-Elevar un n�mero";
	}
	
	public void mostrarmenu11() {
		menu11 = "�Desea volver al men� principal?\n1) si\n2) no";
	}
	
	public void mostrarmenu12() {
		menu12 = "�Lados restantes de la figura?";
	}
	
	public String impresionmenu1() {
		return menu1;
	}
	
	public String impresionmenu2() {
		return menu2;
	}
	
	public String impresionmenu3() {
		return menu3;
	}
	
	public String impresionmenu4() {
		return menu4;
	}
	
	public String impresionmenu5() {
		return menu5;
	}
	
	public String impresionmenu6() {
		return menu6;
	}
	
	public String impresionmenu7() {
		return menu7;
	}
	
	public String impresionmenu8() {
		return menu8;
	}
	
	public String impresionmenu9() {
		return menu9;
	}
	
	public String impresionmenu10() {
		return menu10;
	}
	
	public String impresionmenu11() {
		return menu11;
	}
	
	public String impresionmenu12() {
		return menu12;
	}
}
