package finalizacion;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Operaciones_main_Final {

	public static void main(String[] args) {
		
		//Se declaran los atributos necesarios dentro del programa para el funcionamiento del mismo
		
		int opciones, alternativa, eleccion;
		double num1, num2, num3, num4, num5;
		String insertado = "";
		String respuesta = "si";
		
		//Se declara la clase Scanner, ya que ser� el pilar por el que se sostendr� el programa 
		
		Scanner entrada = new Scanner(System.in);
		
		/*Tambi�n se construyen los objetos de cada una de las clases que se van a "comunicar" con esta clase "Operaciones_main_Final"
		Tienen la siguiente sintaxis: nombre de la clase  nombre del objeto = new constructor*/
		
		Cuadrado_Final cuadr = new Cuadrado_Final();
		Circulo_Final circ = new Circulo_Final();
		Triangulo_Final tri = new Triangulo_Final();
		Mayor_menor_potencia_Final mmp= new Mayor_menor_potencia_Final();
		Menus_Final menu = new Menus_Final();
		
		/*El programa tiene la particularidad de poder repetirse indefinidamente a trav�s de un bucle "do while", 
		el cual tambi�n da la opci�n de finalizar el programa*/ 
		
		do {
			
		try {
			
		/*De la siguiente forma se comunica la clase "Menus_Final" con la actual: a trav�s del objeto creado,
		se introduce el m�todo y este imprime lo que se haya introducido en �l en la otra clase;
		Con "opciones", se elige la opci�n que se requiera seg�n el men� ya mostrado*/
		
		menu.mostrarmenu1();
		System.out.println(menu.impresionmenu1());
		opciones = entrada.nextInt();
		
		/*Con cada case del switch, se realizan acciones espec�ficas. Por ejemplo, en el primero se da a elegir entre
		 tres figuras geom�tricas, de las cu�les se puede calcular el �rea y el per�metro (todo esto hecho con "if, else if...")
		 Es el mismo mecanismo en todo el programa: se introduce el objeto y se llama al m�todo en cuesti�n*/
		
		switch (opciones) {
		case 1:
			menu.mostrarmenu2();
			System.out.println(menu.impresionmenu2());
			opciones = entrada.nextInt();
			if (opciones == 1) {
				menu.mostrarmenu3();
				System.out.println(menu.impresionmenu3());
				double lado = entrada.nextDouble();
				cuadr.setLado(lado);
				cuadr.CalcularArea();
				System.out.println("El resultado del �rea del Cuadrado es "+cuadr.ImpresionArea());
				System.out.println("");
				menu.mostrarmenu4();
				System.out.println(menu.impresionmenu4());
				alternativa = entrada.nextInt();
				if (alternativa == 1) {
					menu.mostrarmenu5();
					System.out.println(menu.impresionmenu5());
					lado = entrada.nextDouble();
					cuadr.setLado(lado);
					cuadr.CalcularPerimetro();
					System.out.println("El resultado del per�metro del Cuadrado es "+cuadr.ImpresionPerimetro());
				}else if (alternativa == 2) {
					System.out.println("Finalizando el programa");
				}
			}else if (opciones == 2) {
				menu.mostrarmenu6();
				System.out.println(menu.impresionmenu6());
				double base = entrada.nextDouble();
				double altura = entrada.nextDouble();
				menu.mostrarmenu12();
				tri.setBase(base);
				tri.setAltura(altura);
				tri.CalcularArea();
				System.out.println("El resultado del �rea del Tri�ngulo es "+tri.ImpresionArea());
				System.out.println("");
				menu.mostrarmenu4();
				System.out.println(menu.impresionmenu4());
				alternativa = entrada.nextInt();
				if (alternativa == 1) {
					menu.mostrarmenu7();
					System.out.println(menu.impresionmenu7());
					base = entrada.nextDouble();
					double lado2 = entrada.nextDouble();
					double lado3 = entrada.nextDouble();
					tri.setBase(base);
					tri.setLado2(lado2);
					tri.setLado3(lado3);
					tri.CalcularPerimetro();
					System.out.println("El resultado del per�metro del TRI�NGULO es "+tri.ImpresionPerimetro());
				}else if (alternativa == 2) {
					System.out.println("Finalizando el programa");
				}
			}else if (opciones == 3) {
				menu.mostrarmenu8();
				System.out.println(menu.impresionmenu8());
				double radio = entrada.nextDouble();
				circ.setRadio(radio);
				circ.CalcularArea();
				System.out.println("El �rea del C�rculo es: "+circ.ImpresionArea());
				System.out.println("");
				menu.mostrarmenu4();
				System.out.println(menu.impresionmenu4());
				alternativa = entrada.nextInt();
				if (alternativa == 1) {
					menu.mostrarmenu9();
					System.out.println(menu.impresionmenu9());
					radio = entrada.nextDouble();
					circ.setRadio(radio);
					circ.CalcularPerimetro();
					System.out.println("El resultado del per�metro del C�rculo es "+circ.ImpresionPerimetro());
				}else if (alternativa == 2) {
					System.out.println("Finalizando el programa");
				}
			}
		break;
		case 2:
			menu.mostrarmenu10();
			System.out.println(menu.impresionmenu10());
			eleccion = entrada.nextInt();
			if (eleccion == 1) {
				System.out.println("Introduce 3 n�meros por pantalla");
				num1 = entrada.nextDouble();
				num2 = entrada.nextDouble();
				num3 = entrada.nextDouble();
				
				mmp.setNum1(num1);
				mmp.setNum2(num2);
				mmp.setNum3(num3);
				
				mmp.CalcularCondicion_1();
				mmp.CalcularCondicion_2();
				mmp.CalcularCondicion_3();
				mmp.CalcularCondicion_4();
				mmp.CalcularCondicion_5();
				mmp.CalcularCondicion_6();
				
				if(num1>num2 && num1>num3 && num2>num3){
					System.out.println(mmp.ImpresionCondicion_1());
				}else if(num1>num3 && num1>num2 && num3>num2){
					System.out.println(mmp.ImpresionCondicion_2());
				}else if(num2>num1 && num2>num3 && num1>num3){
					System.out.println(mmp.ImpresionCondicion_3());
				}else if(num2>num3 && num2>num1 && num3>num1){
					System.out.println(mmp.ImpresionCondicion_4());
				}else if(num3>num1 && num3>num2 && num1>num2){
					System.out.println(mmp.ImpresionCondicion_5());
				}else if(num3>num2 && num3>num1 && num2>num1){
					System.out.println(mmp.ImpresionCondicion_6());
				}else if(num1 == num2 && num1 == num3 && num2 == num3) {
					System.out.println("Los n�meros son iguales, por lo que no se puede hacer la comparaci�n num�rica");
				}
			}else if (eleccion == 2) {
				System.out.println("Introduce un n�mero");
				num4 = entrada.nextDouble();
				mmp.setNum4(num4);
				System.out.println("Introduce el n�mero a elevar");
				num5 = entrada.nextDouble();
				mmp.setNum5(num5);
				mmp.CalcularPotencia();
				System.out.println("El resultado es "+mmp.ImpresionPotencia());
			}
		break;
		}
			menu.mostrarmenu11();
			System.out.println(menu.impresionmenu11());
			insertado = entrada.next();
			
			/*Finalmente, a la hora de poder encontrar errores, al tener el programa el mismo mecanismo de funcionamiento, s�lo se ha encontrado
			 un tipo de error, el cual es introducir caracteres no num�ricos, ya que todo se basa en introducir n�meros.
			 "Try Catch": en el "catch", se introduce el tipo de error y, por convenio, el objeto en el que se define se llama "e", aunque se podr�a
			 llamar de cualquier otra forma; con "e.printStackTrace()", se diagnostican las excepciones, y con "e.getMessage()" se muestra el error 
			 en cuesti�n*/
		
			}catch(InputMismatchException e) {
				e.printStackTrace();
				System.out.println("El error en cuesti�n es "+e.getMessage());
				System.out.println("Has introducido un valor no num�rico");
			}catch(Exception e) {
				System.out.println("Algo no est� bien hecho. Revisa el c�digo");
			}
	
		}while(respuesta.equals(insertado));	//se volver� a ejecutar el bucle si "respuesta" es igual a "si"
			entrada.close();	//se cierra el Scanner, ya que no se va utilizar m�s en el programa
	}
}
