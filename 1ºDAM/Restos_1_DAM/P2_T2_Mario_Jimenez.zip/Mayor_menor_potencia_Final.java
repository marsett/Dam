package finalizacion;

public class Mayor_menor_potencia_Final {
	
	//Atributos de las operaciones matem�ticas (encapsulados, con el objetivo de tener mayor control sobre ellos)
	
	private double num1, num2, num3, num4, num5, potencia;
	private String condicion1, condicion2, condicion3, condicion4, condicion5, condicion6;
	
	//Constructor por defecto, el cual no tiene par�metros y no hace ninguna funci�n
	
	public Mayor_menor_potencia_Final() {
		
	}
	
	/*Se hacen Getters con el objetivo de recuperar el valor ya asignado a cada uno de los atributos. Posteriormente, con los Setters,
	se asigna un valor inicial a los atributos*/
	
	public double getNum1() {
		return num1;
	}
	
	public void setNum1(double num1) {
		this.num1 = num1;
	}
	
	public double getNum2() {
		return num2;
	}
	
	public void setNum2(double num2) {
		this.num2 = num2;
	}
	
	public double getNum3() {
		return num3;
	}
	
	public void setNum3(double num3) {
		this.num3 = num3;
	}
	
	public double getNum4() {
		return num4;
	}
	
	public void setNum4(double num4) {
		this.num4 = num4;
	}
	
	public double getNum5() {
		return num5;
	}
	
	public void setNum5(double num5) {
		this.num5 = num5;
	}
	
	public String getCondicion1() {
		return condicion1;
	}
	
	public void setCondicion1(String condicion1) {
		this.condicion1 = condicion1;
	}
	
	public String getCondicion2() {
		return condicion2;
	}
	
	public void setCondicion2(String condicion2) {
		this.condicion2 = condicion2;
	}
	
	public String getCondicion3() {
		return condicion3;
	}
	
	public void setCondicion3(String condicion3) {
		this.condicion3 = condicion3;
	}
	
	public String getCondicion4() {
		return condicion4;
	}
	
	public void setCondicion4(String condicion4) {
		this.condicion4 = condicion4;
	}
	
	public String getCondicion5() {
		return condicion5;
	}
	
	public void setCondicion5(String condicion5) {
		this.condicion5 = condicion5;
	}
	
	public String getCondicion6() {
		return condicion6;
	}
	
	public void setCondicion6(String condicion6) {
		this.condicion6 = condicion6;
	}
	
	/*Finalmente, para realizar los c�lculos, se hacen seis Setters donde se establece el valor las condiciones, las cu�les se 
	devuelven (return) en seis Getters posteriores*/
	
	public void CalcularCondicion_1() {
		condicion1 = num1+" > "+num2+" > "+num3;
	}
	
	public void CalcularCondicion_2() {
		condicion2 = num1+" > "+num3+" > "+num2;
	}
	
	public void CalcularCondicion_3() {
		condicion3 = num2+" > "+num1+" > "+num3;
	}
	
	public void CalcularCondicion_4() {
		condicion4 = num2+" > "+num3+" > "+num1;
	}
	
	public void CalcularCondicion_5() {
		condicion5 = num3+" > "+num1+" > "+num2;
	}
	
	public void CalcularCondicion_6() {
		condicion6 = num3+" > "+num2+" > "+num1;
	}
	
	public String ImpresionCondicion_1() {
		return condicion1;
	}
	
	public String ImpresionCondicion_2() {
		return condicion2;
	}
	
	public String ImpresionCondicion_3() {
		return condicion3;
	}
	
	public String ImpresionCondicion_4() {
		return condicion4;
	}
	
	public String ImpresionCondicion_5() {
		return condicion5;
	}
	
	public String ImpresionCondicion_6() {
		return condicion6;
	}
	
	/*Con el Getter se recupera el valor ya asignado al atributo "potencia". Despu�s, con el Setter, se asigna su valor inicial.
	 Con otro Setter se inicializa esta variable y con otro Getter se devuelve (return) este valor inicializado*/
	
	public double getPotencia() {
		return potencia;
	}
	
	public void setPotencia(double potencia) {
		this.potencia = potencia;
	}
	
	public void CalcularPotencia() {
		potencia = Math.pow(num4,num5);
	}
	
	public double ImpresionPotencia() {
		return potencia;
	}
}
