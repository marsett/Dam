package ej_examen;

import java.util.Scanner;

public final class Supermercado extends Tienda{
	
	protected int seccionesS, empsec;
	
	Supermercado(){
		
	}
	
	public void setEmpleados(int empleados) {
		this.empleados = empleados;
	}
	
	public void inicalizacion(int seccionesS){
		
		Scanner entrada = new Scanner (System.in);
		
		this.seccionesS = seccionesS;
		
		System.out.println("Indica las secciones S");
		
		seccionesS = entrada.nextInt();
		
	}
	
	public int EmpleadosSeccion() {
		empsec = empleados / seccionesS;
		return empsec;
	}
	
	public void frasefinal() {
		System.out.println("Tienda tipo Supermercado. Empleados: "+empleados+" Secciones: "+seccionesS+" Empleados por Seccion: "+empsec);
	}
}
