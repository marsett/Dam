package ej_examen;

public abstract class Tienda {
	
	//Atributos
	
	protected int empleados;
	protected int metros2;
	private int numtiendas;
	
	//Constructores
	
	Tienda(){
		empleados = 50;
		metros2 = 200;
	}
	
	//M�todos
	
	public abstract int EmpleadosSeccion();
	
}
