package ej_examen;

import java.util.Scanner;

public final class City extends Tienda{
	
	protected int seccionesC, empsec;
	
	City(){
		
	}
	
	public void inicalizacion(int seccionesC){
		
		Scanner entrada = new Scanner (System.in);
		
		this.seccionesC = seccionesC;
		
		System.out.println("Indica las secciones C");
		
		seccionesC = entrada.nextInt();
		
	}
	
	public void setEmpleados(int empleados) {
		this.empleados = empleados / 2;
	}
	
	public void setM2(int metros2) {
		this.metros2 = metros2 / 2;
	}
	
	public int EmpleadosSeccion() {
		empsec = empleados / seccionesC;
		return empsec;
	}
	
	public void frasefinal() {
		System.out.println("Tienda tipo Hipermercado. Empleados: "+empleados+" Secciones: "+seccionesC+" Empleados por Seccion: "+empsec);
	}
}
