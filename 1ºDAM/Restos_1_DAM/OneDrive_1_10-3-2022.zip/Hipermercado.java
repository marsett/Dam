package ej_examen;

import java.util.Scanner;

public final class Hipermercado extends Tienda{
	
	protected int seccionesH, empsec;
	
	Hipermercado(){
		
	}
	
	public void inicalizacion(int seccionesH){
		
		Scanner entrada = new Scanner (System.in);
		
		this.seccionesH = seccionesH;
		
		System.out.println("Indica las secciones H");
		
		seccionesH = entrada.nextInt();
		
	}
	
	public void setEmpleados(int empleados) {
		this.empleados = empleados * 3;
	}
	
	public int EmpleadosSeccion() {
		empsec = empleados / seccionesH;
		return empsec;
	}
	
	public void setM2(int metros2) {
		this.metros2 = metros2 * 3;
	}
	
	public void frasefinal() {
		System.out.println("Tienda tipo Hipermercado. Empleados: "+empleados+" Secciones: "+seccionesH+" Empleados por Seccion: "+empsec);
	}
	
}
