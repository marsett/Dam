package ej_examen;

public class Tienda_Main {

	public static void main(String[] args) {
		
		boolean condicion = true;
		
		do {

			int opciones = 0;
			
			switch(opciones) {
				
			case 1:
				
				if(opciones == 1) {
				
					System.out.println("Hipermercado");
					
					
				
				}
				break;
				
			
			
			
			}
			
		}while(condicion == true);

	}

}
