#!/bin/bash

mkdir $1
echo "Carpeta $1 creada"
