#!/bin/bash

echo "Primera línea del fichero" > $1
cat $1
