package unit_test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Test_Numeros {
	
  //Mario Jim�nez Marset

	Numeros num;
	
	@BeforeAll 	//@Beforeclass se llamaba antes
	public static void beforeAll(){
		System.out.println("Este es el primer mensaje de todo el programa");
	}
	
	@AfterAll 	//@Afterclass se llamaba antes
	public static void afterAll(){
		System.out.println("Este es el �ltimo mensaje despu�s del programa");
	}
	
	@BeforeEach	//se ejecutar� antes que los @Test	(antes era @Before)	
	public void beforeEach() {
		System.out.println("Se ejecuta el Test");
		num = new Numeros();
	}
	
	@AfterEach	//se ejecutar� despu�s que los @Test (antes era @After)	
	public void afterEach() {
		System.out.println("Ejecuci�n del Test finalizada");
		num.clear();    //una manera de utilizar esto podr�a ser limpiando todo de una
	}
	
	@Test
	void testOperacion1() {
		System.out.println("Test de una operaci�n");
		double resultado = num.getOperacion(2, 2);
		double esperado = 4;
		
		assertEquals(esperado, resultado);
		
	}
	
	@Test
	void testOperacion2() {
		System.out.println("Test de una operaci�n");
		double resultado = num.getOperacion2(8, 2);
		double esperado = 4;
		
		assertEquals(esperado, resultado);
		
	}
	
	@Test
	void testOperacion3() {
		System.out.println("Test de una operaci�n");
		double resultado = num.getOperacion(8, 2);
		double esperado = 16;
		
		assertEquals(esperado, resultado);
		
	}
	
	@Test
	void testOperacion4() {
		System.out.println("Test de una operaci�n");
		double resultado = num.getOperacion2(16, 2);
		double esperado = 8;
		
		assertEquals(esperado, resultado);
		
	}
	
	@Test
	void testOperacion5() {
		System.out.println("Test de una operaci�n");
		double resultado = num.getOperacion3(4, 2, 4);
		double esperado = 2;
		
		assertEquals(esperado, resultado);
		
	}
	
	@Test
	void testOperacion6() {
		System.out.println("Test de una operaci�n");
		double resultado = num.getOperacion3(8, 4, 8);
		double esperado = 4;
		
		assertEquals(esperado, resultado);
		
	}

}
