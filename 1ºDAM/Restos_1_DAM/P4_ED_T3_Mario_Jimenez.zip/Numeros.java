package unit_test;

public class Numeros {
	
	//Mario Jim�nez Marset
	
		//Atributos
		private double operacion;
		private double operacion2;
		private double operacion3;
		
		//Constructor
		public Numeros() {
			
		}
		
		//M�todos
		public double getOperacion(int numero, int b) {
			operacion = numero*b;
			return operacion;
		}
		
		public double getOperacion2(int numero, int b) {
			operacion2 = numero/b;
			return operacion2;
		}
		
		public double getOperacion3(int numero, int a, int b) {
			operacion3 = (numero*a)/b;
			return operacion3;
		}
		
		public void clear() {
			
		}
}
