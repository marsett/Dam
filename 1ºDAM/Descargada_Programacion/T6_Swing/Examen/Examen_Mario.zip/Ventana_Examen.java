package examen_interfaces;

import javax.swing.*;



import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class Ventana_Examen extends JFrame{		//Marco
	
	private static final long serialVersionUID = 1L;
	private int anchoventana, alturaventana; 
	
	public Ventana_Examen(int ancho, int alto) {
		
		setTitle("Primera ventana");
		setResizable(true);
		
		anchoventana = ancho*5/10;
		alturaventana = alto*8/10;
		
		setSize(anchoventana, alturaventana);
		setLocation(100,100);
		
		Lamina_Examen lamina = new Lamina_Examen(anchoventana, alturaventana);
		add(lamina);
		setVisible(true);
	}
}

class Lamina_Examen extends JPanel implements ActionListener{		//L�mina
	
	private static final long serialVersionUID = 1L;
	private int anchov, altov;
	
	JLabel jl = new JLabel ("Frase:");
	
	JTextField campo = new JTextField(30);
	
	JButton esc = new JButton("Escribir");
	JButton fin = new JButton("Finalizar");
	
	JTextArea miarea = new JTextArea(30,45);
	
	String cadena = "";
	
	
	
	public Lamina_Examen(int ancho, int alto) {
		
		//setLayout(null);
		
		this.altov = alto*8;
		this.anchov = ancho*5;
		
		
		
		//miarea.setLocation(120,100);
		miarea.setLineWrap(true);
		//miarea.append("\n");
		
		add(jl);
		//jl.setBounds(20,20,50,50);
		
		add(campo);
		//campo.setBounds(90,33,530,25);
		
		add(esc);
		//esc.setBounds(650,33,80,25);
		esc.addActionListener(this);
		
		add(miarea);
		//miarea.setBounds(20,50,30,45);
		
		add(fin);
		//fin.setBounds(350,450,100,25);
		fin.addActionListener(this);
		
		
			
			
		
	}
	
	public void actionPerformed(ActionEvent e) {
		
		miarea.setText(campo.getText());
		campo.setText("");
		add(miarea);
		
		File fich1 = new File("examen.txt");
		
		try {
			
			FileWriter fl = new FileWriter(fich1);
			BufferedWriter br = new BufferedWriter(fl);
			
			for(int i=0;i<campo.getText().length();i++) {
				fl.write(campo.getText().charAt(i));
				
			}
			
			
			
			fl.close();
			
			
		
	} catch (IOException f) {
		
		miarea.setText("Error no se ha encontrado el archivo");
		miarea.append(f.getMessage()+"\n");
		
	}
		
		//miarea.setLineWrap(true);
		
		//miarea.setText();
		
	
		
		try {
			
			FileReader fl = new FileReader(fich1);
			BufferedReader br = new BufferedReader(fl);
			
			while((cadena = br.readLine())!=null) {
				
				miarea.append(campo.getText());
				
			}
			
			br.close();
		
	} catch (IOException g) {
		
		miarea.setText("Error no se ha encontrado el archivo");
		miarea.append(g.getMessage()+"\n");
		
	}
		
		
		
		
		
		
	}
	
	
}
