package examen_interfaces;

import javax.swing.*;

import interfaces.Ventana1;

import java.awt.*;

public class Main_Examen {

	public static void main(String[] args) {
		
		Toolkit mipantalla = Toolkit.getDefaultToolkit();
		Dimension tamanopantalla = mipantalla.getScreenSize();
		
		int anch = tamanopantalla.width;
		int alt = tamanopantalla.height;
		
		Ventana_Examen ventana = new Ventana_Examen(anch,alt);
		ventana.setVisible(true);
		ventana.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

	}

}
