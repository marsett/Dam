package practica_bbdd;

import javax.swing.*;

public class Main{

	public static void main(String[] args) {
		
		Ventana vent = new Ventana();
		vent.setVisible(true);
		vent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}