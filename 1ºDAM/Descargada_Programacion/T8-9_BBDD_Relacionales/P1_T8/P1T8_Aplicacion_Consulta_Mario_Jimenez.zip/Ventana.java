package practica_bbdd;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;

public class Ventana extends JFrame{
	
	private static final long serialVersionUID = 1L;
	
	public Ventana(){
		
		setTitle("Aplicaci�n de Consulta");
		
		setBounds(50,50,400,400);
		
		Lamina lam = new Lamina();
		add(lam);
		setVisible(true);
		
	}

}

class Lamina extends JPanel implements ActionListener{
		
		private static final long serialVersionUID = 1L;
		
		protected JPanel laminaMenu;
		protected JTextArea areaResultado;
		protected JLabel cur;
		protected JComboBox jcb_curso;
		protected JLabel eda;
		protected JComboBox jcb_edad;
		protected JButton botonConsulta;
		Connection miConexion = null;
		Connection miConexion2 = null;
		Statement miStatement = null;
		Statement miStatement2 = null;
		Statement miStatement3 = null;
		ResultSet miResultSet = null;
		ResultSet miResultSet2 = null;
		ResultSet miResultSet3 = null;
		
		public Lamina() {
			
			setLayout(new BorderLayout());
			
			laminaMenu = new JPanel();
			areaResultado = new JTextArea(4,50);
			cur = new JLabel("Curso: ");
			jcb_curso = new JComboBox();
			eda = new JLabel("Edad: ");
			jcb_edad = new JComboBox();
			botonConsulta = new JButton("Consulta");
			
			areaResultado.setEditable(false);
			
			laminaMenu.setLayout(new FlowLayout());
			laminaMenu.add(cur);
			
			jcb_curso.setEditable(false);
			jcb_curso.addItem("Todos");
			
			laminaMenu.add(jcb_curso);
			laminaMenu.add(eda);
			
			jcb_edad.setEditable(false);
			jcb_edad.addItem("Todos");
			
			laminaMenu.add(jcb_edad);
			
			add(laminaMenu,BorderLayout.NORTH);
			add(areaResultado,BorderLayout.CENTER);
			add(botonConsulta,BorderLayout.SOUTH);
			botonConsulta.addActionListener(this);
			
			Select(miConexion, miStatement, miResultSet, miResultSet2, jcb_curso, jcb_edad, miStatement2);
			
}
		
		public static void Select(Connection miConexion,Statement miStatement, ResultSet miResultSet , ResultSet miResultSet2, JComboBox jcb_curso, JComboBox jcb_edad, Statement miStatement2) {
			
		try {
			
			miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/COLEGIO","root","" );
			miStatement = miConexion.createStatement();
			miStatement2 = miConexion.createStatement();
			
			miResultSet = miStatement.executeQuery("SELECT DISTINCT CURSO FROM ALUMNOS");
			miResultSet2 = miStatement2.executeQuery("SELECT DISTINCT EDAD FROM ALUMNOS");
			
			while(miResultSet.next()) {
				//System.out.println(miResultSet1.getString("CURSO"));
				jcb_curso.addItem(miResultSet.getString("CURSO"));
			}
			
			while(miResultSet2.next()) {
				//System.out.println(miResultSet1.getString("EDAD"));
				jcb_edad.addItem(miResultSet2.getInt("EDAD"));
			}
			
		}
		
		catch (SQLException e) {
			printSQLException(e);
		}
			finally {
				
				try {
					miStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
				
		}
		
		public static void printSQLException (SQLException ex) {
			ex.printStackTrace(System.err);
			System.err.println("SQLState : " + ex.getSQLState());
			System.err.println("Error Code : " + ex.getErrorCode());
			System.err.println("Message : " + ex.getMessage());
			Throwable t = ex.getCause();
			while (t != null) {
			System.err.println("Cause :" + t);
			t = t.getCause();
			}
			}

		@Override
		public void actionPerformed(ActionEvent e){
			
			String consulta ="SELECT NOMBRE FROM ALUMNOS";
			
			try {
				
				miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/COLEGIO","root","" );
				miStatement3 = miConexion.createStatement();
				
				miResultSet3 = miStatement3.executeQuery(consulta);
				//miConexion.close();
				
				if(jcb_curso.getSelectedItem() == "TODOS" && jcb_edad.getSelectedItem() == "TODOS") {
					String sentencia = "SELECT * FROM ALUMNOS ORDER BY IDALUMNO";
					while(miResultSet3.next()) {
						areaResultado.setText(miResultSet3.getString(sentencia));
						areaResultado.append("\n");
					}
				}
				
				
			}catch (SQLException a) {
					printSQLException(a);
			}
			
		}
		
}


