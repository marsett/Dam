package juego;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

public class Mago extends Personaje{
	
	 private int magia;
     private Date fechamag;
	 
	    Mago (){
	    	this.magia = 10;
	    	GregorianCalendar calendar = new GregorianCalendar(2003, 11, 20);
	    	fechamag = calendar.getTime();
	    	SimpleDateFormat format = new SimpleDateFormat("dd/MM/YYYY");
	    	System.out.println("Mago--> Constructor");
	    	System.out.println("Fecha de nacimiento del mago: "+ format.format(fechamag));
	    	vida = ((int)(getVida()*0.1)+getVida());
	    	setVida(vida);
	    	super.setVida(vida);
	    }
	         
	    public int movimientoLucha() {
	     int golpe;
	     golpe = (int)(Math.random() * this.magia);
	     System.out.println("*****Hechizo: "+golpe+" *****");
	     return golpe;
	    }
	    public String getPersonaje() {
	        return "Mago";
	    }
	    
}
