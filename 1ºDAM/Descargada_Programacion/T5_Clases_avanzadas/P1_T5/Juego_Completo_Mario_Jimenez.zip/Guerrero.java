package juego;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

public class Guerrero extends Personaje{
	
	  protected int ataque;
	  private Date hora;
	  
	  Guerrero (){
	      this.ataque = 10;
	      GregorianCalendar calendar = new GregorianCalendar();
	    	hora = calendar.getTime();
	    	SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
	    	System.out.println("Guerrero--> Constructor");
	    	System.out.println("Hora de creaci�n: "+ format.format(hora));
	  }
	 
	  public int movimientoLucha() {
	    int golpe;
	    golpe = (int)(Math.random() * this.ataque);
	    System.out.println("*****Espadazo: "+golpe+" *****");
	    return golpe;

	  }
	  
	  public String getPersonaje() {
	       return "Guerrero";
	  }
	  
}
