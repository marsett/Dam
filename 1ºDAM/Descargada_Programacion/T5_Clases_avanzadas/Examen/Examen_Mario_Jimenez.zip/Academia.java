package examen_prog;

import java.util.Scanner;

public class Academia {
	
	public static void capacidad(Aulas_Academia acad) {
	
		if(acad.limiteCapacidad() == false) {
			acad.avisoExcesoCapacidad();
			
			acad.eliminados();
			
		}
		
	}
	
	public static void main(String[] args) {
		
		Scanner entrada = new Scanner (System.in);
		
		int opcion;
		
		System.out.println("�Qu� tipo de aula deseas crear?");
		System.out.println("Opci�n 1 - Aula de Docencia");
		System.out.println("Opci�n 2 - Aula de Inform�tica");
		
		opcion = entrada.nextInt();
		
		if(opcion == 1) {
			System.out.println("Aula Docente");
			Aulas_Docencia doc1 = new Aulas_Docencia();
					//problema de ejecuci�n al leer Java las l�neas 32 y 33
			
			System.out.println("�Cu�ntos usuarios se desean asignar en este aula?");
			doc1.setUsuarios(entrada.nextInt());
			System.out.println("Docencia --> magnitud: "+doc1.getMagnitud()+" usuarios: "+doc1.getUsuarios());
			
			System.out.println(doc1.avisoExcesoCapacidad());
			
			System.out.println("Vamos a eliminar usuarios. Usuarios iniciales en Aula: "+doc1.getUsuarios());
			
			System.out.println("El n�mero de usuarios eliminados es: "+doc1.eliminados());
			
			Academia.capacidad(doc1);
			
		}else if (opcion == 2) {
			System.out.println("Aula Inform�tica");
			Aulas_Informatica inf1 = new Aulas_Informatica();
			Academia.capacidad(inf1);
			System.out.println("�Cu�ntos usuarios se desean asignar en este aula?");
			inf1.setUsuarios(entrada.nextInt());
			System.out.println("Introduce el n�mero de PCs para tu Aula de Inform�tica o bien 0 para mantener la cantidad por defecto");
			inf1.setPcs(entrada.nextInt());
			
			System.out.println("Inform�tica --> magnitud: "+inf1.getMagnitud()+" usuarios: "+inf1.getUsuarios());
			
			System.out.println(inf1.avisoExcesoCapacidad());
			
			System.out.println("Vamos a eliminar usuarios. Usuarios iniciales en Aula: "+inf1.getUsuarios());
		
			System.out.println("El n�mero de usuarios eliminados es: "+inf1.eliminados());
			
		}else if(opcion <1 || opcion >2) {
			Aulas_Academia fin = new Aulas_Docencia();
			System.out.println("N�mero de usuarios a realojar en otras aulas: "+fin.getUsuarios());
			System.out.println("Fin del programa");
		}
		
		
		
	}		
		

	

}
