package examen_prog;

public class Aulas_Docencia extends Aulas_Academia{

	//Atributos
	
	//Constructores
	
	Aulas_Docencia(){
		this.magnitud = ((getMagnitud()*20)/100)+getMagnitud();
	}
	
	
	
	/*public boolean limiteCapacidad() {
		boolean condicion = true;
		int operacion = magnitud/usuarios;
		if(operacion >= 1) {
			condicion = false;
		}else if(operacion <1) {
			condicion = true;
		}
		return condicion;
	}*/
	
	
	public String avisoExcesoCapacidad() {
		String texto = "";
		if(limiteCapacidad() == true) {
			texto = "***Cuidado, ha superado la capacidad m�xima del aula***";
		}
		return texto;
	}
	
	public int eliminados() {
		int usuariosnuevos = getUsuarios();
		int usuariosEliminados = usuariosnuevos;
		while(usuariosnuevos >1) {
			usuariosnuevos--;
		}
		
		return usuariosEliminados;
	}
	
}
