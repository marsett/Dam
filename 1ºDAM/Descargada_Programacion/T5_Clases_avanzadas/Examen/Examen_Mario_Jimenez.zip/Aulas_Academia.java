package examen_prog;

public abstract class Aulas_Academia {
	
	//Atributos
	
	protected int magnitud = 60;	//m2
	protected int usuarios;	//n�mero alumnos
	
	//Constructores
	
	Aulas_Academia(){
		usuarios = 0;
	}
	
	//M�todos
	
	public int getMagnitud() {
		return magnitud;
	}
	
	public void setMagnitud(int magnitud) {
		this.magnitud = magnitud;
	}
	
	public int getUsuarios() {
		return usuarios;
	}
	
	public void setUsuarios(int usuarios) {
		this.usuarios = usuarios;
	}
	
	//public abstract boolean limiteCapacidad();
	
	public boolean limiteCapacidad() {
		boolean condicion = true;
		int operacion = magnitud/usuarios;
		if(operacion >= 1) {
			condicion = false;
		}else if(operacion <1) {
			condicion = true;
		}
		return condicion;
	}
	
	public abstract String avisoExcesoCapacidad();
	
	public abstract int eliminados();
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
