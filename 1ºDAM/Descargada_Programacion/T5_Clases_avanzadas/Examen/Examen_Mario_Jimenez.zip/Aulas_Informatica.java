package examen_prog;

public class Aulas_Informatica extends Aulas_Academia{
	
	//Atributos
	
	protected int pcs = 0;
	
	//Constructores
	
	Aulas_Informatica(){
		this.magnitud = getMagnitud()-((getMagnitud()*20)/100);
		pcs = magnitud*2;
	}
	
	//M�todos
	
	public int getPcs() {
		return pcs;
	}
	
	public void setPcs(int pcs) {
		this.pcs = pcs;
	}
	
	public boolean limiteCapacidad() {
		boolean condicion = true;
		if(pcs >= usuarios) {
			condicion = false;
		}else if(pcs < usuarios) {
			condicion = true;
		}
		return condicion;
	}
	
	public String avisoExcesoCapacidad() {
		String texto = "";
		if(limiteCapacidad() == true) {
			texto = "***Cuidado, ha superado la capacidad m�xima del aula***";
		}
		return texto;
	}
	
	public int eliminados() {
		int usuariosnuevos = getUsuarios();
		int usuariosEliminados = usuariosnuevos;
		while(usuariosnuevos >1) {
			usuariosnuevos--;
		}
		
		return usuariosEliminados;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
