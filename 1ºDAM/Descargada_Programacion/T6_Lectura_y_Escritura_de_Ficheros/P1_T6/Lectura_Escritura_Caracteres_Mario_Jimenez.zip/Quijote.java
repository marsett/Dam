package ficheros;

import java.io.IOException;

public class Quijote {
	
	public static void main(String[] args) {
		
		//Mario Jim�nez Marset
		
		//Llamadas a los m�todos de la clase OperacionesFicheros (para que salga por pantalla el resultado deseado)
				
		OperacionesFicheros accede_esc = new OperacionesFicheros();
		
		try {
			accede_esc.escritura();
		} catch (IOException e) {
			System.out.println("Error impresi�n 1");
			e.printStackTrace();
		}
		
		OperacionesFicheros accede_lec = new OperacionesFicheros();
		
		try {
			accede_lec.lectura_y_escritura();
		} catch (IOException e) {
			System.out.println("Error impresi�n 2");
			e.printStackTrace();
		}
		
		OperacionesFicheros accede_lec_esc = new OperacionesFicheros();
		
		try {
			accede_lec_esc.lectura();
		} catch (IOException e) {
			System.out.println("Error impresi�n 3");
			e.printStackTrace();
		}
		
	}

}
