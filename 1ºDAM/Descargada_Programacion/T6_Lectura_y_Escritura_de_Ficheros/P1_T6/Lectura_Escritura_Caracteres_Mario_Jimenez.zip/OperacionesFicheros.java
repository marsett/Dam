package ficheros;

import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.IOException;

public class OperacionesFicheros {
	
	//Mario Jim�nez Marset
	
	String texto = "En un lugar de la Mancha, de cuyo nombre no quiero acordarme, no ha mucho tiempo que viv�a un hidalgo de los de lanza en astillero, adarga antigua, roc�n flaco y galgo corredor. Una olla de algo m�s vaca que carnero, salpic�n las m�s noches, duelos y quebrantos los s�bados, lentejas los viernes, alg�n palomino de a�adidura los domingos, consum�an las tres partes de su hacienda. El resto della conclu�an sayo de velarte, calzas de velludo para las fiestas con sus pantuflos de lo mismo, los d�as de entre semana se honraba con su vellori de lo m�s fino. Ten�a en su casa una ama que pasaba de los cuarenta, y una sobrina que no llegaba a los veinte, y un mozo de campo y plaza, que as� ensillaba el roc�n como tomaba la podadera. Frisaba la edad de nuestro hidalgo con los cincuenta a�os, era de complexi�n recia, seco de carnes, enjuto de rostro; gran madrugador y amigo de la caza. Quieren decir que ten�a el sobrenombre de Quijada o Quesada (que en esto hay alguna diferencia en los autores que deste caso escriben), aunque por conjeturas veros�miles se deja entender que se llama Quijana; pero esto importa poco a nuestro cuento; basta que en la narraci�n d�l no se salga un punto de la verdad.";
	
	//m�todo que escrive el fichero Quijote.txt car�cter a car�cter
	
	public void escritura() throws IOException{
		
		File fich1 = new File("Quijote.txt");
		
		try {
			
			FileWriter escribe = new FileWriter(fich1);
			
			for(int i=0;i<texto.length();i++) {
				escribe.write(texto.charAt(i));
			}
			
			escribe.close();
			
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error 1 --> Escritura");
		}
		
	}
	
	//m�todo que lee el fichero Quijote.txt car�cter a car�cter y graba en el fichero Quijote_lineas.txt (despu�s de cada . , o ;) un salto de l�nea (escrito con buffer)
	
	public void lectura_y_escritura() throws IOException{
	
			File fl = new File("Quijote.txt");
			File fe = new File("Quijote_lineas.txt");
			
			FileWriter fw = new FileWriter(fe);
			
			BufferedWriter bw = new BufferedWriter(fw);
			
			if(fl.exists()){
				
				try {
					
					FileReader fr = new FileReader(fl);
					
					int caracter = 0;
					
					String frase = "";
			
					while(caracter!=-1) {
						
						caracter = fr.read();
				
						char letra = (char) caracter;
						System.out.print(letra);
						
						frase = frase + (char) caracter;
					}
				
				System.out.println("");
				fr.close();
				
				
				for(int i=0;i<frase.length();i++) {
					char car = frase.charAt(i);
					
					if((char)car == ',' || (char) car == '.' || (char) car == ';') {
						bw.write(car);
						bw.newLine();
					}else {
						bw.write(car);
					}
				}
				
				bw.flush();
				
			}catch (IOException e) {
				e.printStackTrace();
				System.out.println("Error 2 --> Lectura y Escritura");
			}
			
		} 
	}
	
	//m�todo que lee el fichero Quijote_lineas.txt con un buffer

	public void lectura() throws IOException{
		
		File fe = new File("Quijote_lineas.txt");
				
			try {
				
				FileReader fl = new FileReader(fe);
				BufferedReader br = new BufferedReader(fl);
				
				String line;
				
				while((line = br.readLine())!=null) {
					System.out.println(line);
				}
				
				br.close();
			
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Error 3  --> Lectura");
		}
			
	}	
		
}
