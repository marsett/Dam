package serializacion;

public class Contacto implements java.io.Serializable{
	
	//Mario Jim�nez Marset
	
	protected String nombre, email;
	protected long telefono_movil;
	protected transient long telefono_fijo = 0000;
	
	private static final long serialVersionUID = 8799656478674716638L;
	
	public Contacto(String nom, long tel, String em) {
		nombre = nom;
		telefono_movil = tel;
		email = em;
		telefono_fijo = 9999; 
	}
	
	public String toString() {
		return "Nombre: "+nombre+"\n"+"Email: "+email+"\n"+"Telefono movil: "+telefono_movil+"\n"+"Telefono fijo: "+telefono_fijo;
	}
	
}
