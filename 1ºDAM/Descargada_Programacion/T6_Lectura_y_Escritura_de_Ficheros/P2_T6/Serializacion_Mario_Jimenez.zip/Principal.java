package serializacion;

import java.io.*;

public class Principal {

	public static void main(String[] args) {
		
		//Mario Jim�nez Marset
		
		Contacto[] contact;
		
		contact = new Contacto[4];
		
		contact[0] = new Contacto("Mario", 6666, "jimenezmarset@gmail.com");
		
		contact[1] = new Contacto("Winston", 7777, "alcapahuecawins@gmail.com");
		
		contact[2] = new Contacto("Nestor", 4444, "rodrigueznest@gmail.com");
		
		contact[3] = new Contacto("Mati", 1111, "elmati@gmail.com");
		
		File f = new File("contactos.dat");
		
		try {
			
			FileOutputStream fs = new FileOutputStream(f);
			
			ObjectOutputStream oos = new ObjectOutputStream(fs);
			
			for(int i=0; i<4; i++) {
				
				oos.writeObject(contact[i]);
				
			}
			
			if(oos != null) {
				
				oos.close();
				fs.close();
				
			}
			
			FileInputStream fe = null;
			
			ObjectInputStream ois = null;
			
			if(f.exists()) {
				
				fe = new FileInputStream(f);
				ois = new ObjectInputStream(fe);
			
				try {
					
					while(true) {
						
					Contacto a = null;
					a = (Contacto)ois.readObject();
					System.out.println(a.toString());
					
				} 
					
				}catch (ClassNotFoundException e) {
					
					e.printStackTrace();
					
				}catch(EOFException e){
					
					System.out.println("----------------------------");
					
				}finally {
					
					fe.close();
					ois.close();
					
				}
			}
			
		}catch(IOException e) {
			
			e.printStackTrace();
			
		}

	}

}
