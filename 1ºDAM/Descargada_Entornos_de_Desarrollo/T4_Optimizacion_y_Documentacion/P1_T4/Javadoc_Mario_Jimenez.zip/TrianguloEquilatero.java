package javadoc;


/**
 * @author Mario
 * @version 2021-12 (4.22.0)
 */
public class TrianguloEquilatero {
	
	private double lado;
	private double altura;
	
	/**
	 * Este es el constructor (con variables) del programa
	 * @param lado El parametro lado muestra el valor que tendra el lado del triangulo equilatero
	 * @param altura El parametro altura muestra el valor que tendra la altura del triangulo equilatero
	 */
	TrianguloEquilatero (double lado, double altura){
		this.lado = lado;
		this.altura = altura;
	}
	
	/**
	 * Metodo que devuelve el valor del lado del triangulo equilatero
	 * @return El valor del lado
	 */
	public double getLado() {
		return lado;
	}

	/**
	 * Metodo que establece el valor del lado del triangulo equilatero 
	 * @param lado Se establece el valor del lado
	 */
	public void setLado(double lado) {
		this.lado = lado;
	}

	/**
	 * Metodo que devuelve el valor de la altura del triangulo equilatero
	 * @return El valor de la altura
	 */
	public double getAltura() {
		return altura;
	}

	/**
	 * Metodo que establece el valor de la altura del triangulo equilatero
	 * @param altura Se establece el valor de la altura
	 */
	public void setAltura(double altura) {
		this.altura = altura;
	}
	
	/**
	 * Metodo que devuelve el valor del area de un triangulo equilatero,
	 * siempre y cuando la altura no sea igual a 0
	 * @return El valor de la formula del area seg�n lo que valgan el lado y altura del triangulo
	 * @throws Si se da la circunstancia de que la altura sea igual a 0, muestra un mensaje en especifico
	 */
	double calculaArea() {
		double area = 0;
		if (altura==0){
			throw new ArithmeticException("No es posible que la altura sea cero");
		} else {
			area = (lado * 2)/altura;
		}
		return area;
	}
	
	/**
	 * Metodo que devuelve el valor del perimetro de un triangulo equilatero
	 * @return El valor de la formula del perimetro segun lo que valga el lado del triangulo
	 */
	double calculaPerimetro() {
		double perimetro = lado*3;
		return perimetro;
	}
}
